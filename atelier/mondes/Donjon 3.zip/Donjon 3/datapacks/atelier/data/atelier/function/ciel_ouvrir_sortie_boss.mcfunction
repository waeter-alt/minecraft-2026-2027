# [claude-build] Ouvre la sortie du boss (a relier a la mort du boss).
fill 239 10 224 241 12 224 minecraft:air
playsound minecraft:block.iron_door.open master @a 239 10 224 2 0.6
