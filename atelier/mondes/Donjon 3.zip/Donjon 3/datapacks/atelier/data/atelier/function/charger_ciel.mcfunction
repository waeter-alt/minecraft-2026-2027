# [claude-build] Pose automatique, une seule fois (drapeau #ciel).
scoreboard objectives add atelier dummy
execute unless score #ciel atelier matches 1 run schedule function atelier:ciel_pose 100t
scoreboard players set #ciel atelier 1
