# [claude-build] Remet l'archipel a zero : herses refermees, leviers rabaisses, dalles des salles cachees remises, cle et variables remises.
fill 329 -6 141 329 -5 141 minecraft:iron_bars
fill 337 4 143 337 5 143 minecraft:iron_bars
fill 339 14 135 339 15 135 minecraft:iron_bars
fill 119 37 136 121 37 136 minecraft:polished_andesite
fill 323 -16 138 325 -16 138 minecraft:polished_andesite
fill 141 -17 346 143 -17 346 minecraft:polished_andesite
fill 331 -16 341 333 -14 341 minecraft:iron_bars
fill 160 -16 345 160 -14 347 minecraft:iron_bars
fill 149 -16 340 151 -14 340 minecraft:iron_bars
fill 239 10 224 241 12 224 minecraft:iron_bars
fill 328 -15 137 328 -13 139 minecraft:iron_bars
fill 212 -16 349 212 -14 351 minecraft:iron_bars
setblock 339 -14 140 minecraft:lever[face=wall,facing=west,powered=false]
setblock 336 -4 133 minecraft:lever[face=wall,facing=south,powered=false]
setblock 329 6 136 minecraft:lever[face=wall,facing=east,powered=false]
setblock 341 9 196 minecraft:lever[face=wall,facing=south,powered=false]
setblock 336 5 243 minecraft:lever[face=wall,facing=south,powered=false]
setblock 342 1 291 minecraft:lever[face=wall,facing=south,powered=false]
setblock 133 -15 346 minecraft:lever[face=wall,facing=east,powered=false]
setblock 220 -16 347 minecraft:lever[face=wall,facing=west,powered=false]
setblock 232 12 142 minecraft:lever[face=wall,facing=east,powered=false]
setblock 262 -9 349 minecraft:lever[face=wall,facing=west,powered=false]
setblock 168 -1 292 minecraft:lever[face=wall,facing=south,powered=false]
setblock 222 10 246 minecraft:lever[face=wall,facing=west,powered=false]
scoreboard objectives add ciel dummy
scoreboard players set #l1 ciel 0
scoreboard players set #l2 ciel 0
scoreboard players set #l3 ciel 0
scoreboard players set #kp ciel 0
scoreboard players set #cle ciel 0
scoreboard players set #gl ciel 0
scoreboard players set #an ciel 0
scoreboard players set #sm ciel 0
scoreboard players set #sq ciel 0
scoreboard players set #e1 ciel 0
scoreboard players set #e2 ciel 0
scoreboard players set #e3 ciel 0
scoreboard players set #ec ciel 0
fill 168 -14 344 168 -14 348 minecraft:gray_concrete
fill 250 -8 340 250 2 350 minecraft:ochre_froglight replace minecraft:verdant_froglight
fill 240 -13 350 240 -3 360 minecraft:ochre_froglight replace minecraft:verdant_froglight
fill 230 -18 340 230 -8 350 minecraft:ochre_froglight replace minecraft:verdant_froglight
tag @a remove ciel_e1
tag @a remove ciel_e2
tag @a remove ciel_e3
clear @a minecraft:tripwire_hook[minecraft:custom_name='"Clé des Nuées"']
clear @a minecraft:amethyst_shard
tellraw @a {"text":"Archipel remis a zero.","color":"gray"}
