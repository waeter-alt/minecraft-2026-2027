# [claude-build] Pose l'Archipel des Nuees (sans pause).
forceload add 100 100 379 239
forceload add 100 240 379 379
tellraw @a {"text":"Archipel : 30 secondes de chargement, puis le jeu va se figer un moment. Ne mets pas en pause.","color":"gold"}
schedule function atelier:ciel_pose_2 600t
