# [claude-build] Referme la sortie du boss.
fill 239 10 224 241 12 224 minecraft:iron_bars
