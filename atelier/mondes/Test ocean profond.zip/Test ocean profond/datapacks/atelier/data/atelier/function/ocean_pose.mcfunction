# [claude-build] accueil du monde de test de l'ocean profond (une seule fois, a la premiere ouverture)
gamerule doMobSpawning false
gamerule doDaylightCycle false
gamerule doWeatherCycle false
time set day
weather clear
function atelier:ocean_kit
tellraw @a [{"text":"Monde de test : ocean profond vanilla. Equipe la cape lestee (emplacement cape d'Accessories) puis plonge : plus de brouillard ni de voile bleu, et la vue reste claire jusqu'au fond.","color":"yellow"}]
tellraw @a [{"text":"Fosse la plus profonde : ","color":"gray"},{"text":"[/tp @s 1200 62 -1232]","color":"aqua","underlined":true,"clickEvent":{"action":"run_command","value":"/tp @s 1200 62 -1232"},"hoverEvent":{"action":"show_text","contents":"Cliquer pour y aller (38 blocs d'eau)"}}]
tellraw @a [{"text":"Comparer : ","color":"gray"},{"text":"retire la cape (touche de l'inventaire), le brouillard bleu revient.","color":"white"}]
