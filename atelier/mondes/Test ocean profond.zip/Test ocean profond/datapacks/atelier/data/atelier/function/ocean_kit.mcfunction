# [claude-build] equipement de test
execute as @a run function atelier:ocean_kit_un
