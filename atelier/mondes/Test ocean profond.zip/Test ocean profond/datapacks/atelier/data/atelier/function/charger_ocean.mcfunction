# [claude-build] Pose automatique, une seule fois (drapeau #ocean).
scoreboard objectives add atelier dummy
execute unless score #ocean atelier matches 1 run schedule function atelier:ocean_pose 100t
scoreboard players set #ocean atelier 1
