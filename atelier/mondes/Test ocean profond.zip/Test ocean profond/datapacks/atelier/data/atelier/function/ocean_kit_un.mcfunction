# [claude-build]
gamemode survival @s
give @s grappin:cape_lestee
give @s grappin:grappin
give @s minecraft:cooked_beef 16
