# [claude-build] Pose le Sanctuaire des Marees (sans pause).
forceload add 150 260 299 429
tellraw @a {"text":"Sanctuaire : 15 secondes de chargement, puis le jeu va se figer un moment. Ne mets pas en pause.","color":"gold"}
schedule function atelier:aqua_pose_2 300t
