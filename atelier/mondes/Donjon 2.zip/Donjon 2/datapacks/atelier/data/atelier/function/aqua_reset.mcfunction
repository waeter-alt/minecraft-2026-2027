# [claude-build] Remet le sanctuaire a zero : portes fermees, vannes refermees et cle remise.
fill 176 -24 294 178 -22 294 minecraft:iron_bars[waterlogged=true]
fill 223 -17 320 223 -14 322 minecraft:iron_bars[waterlogged=true]
fill 280 -23 333 282 -23 335 minecraft:iron_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=true]
fill 248 -17 360 248 -14 362 minecraft:iron_bars[waterlogged=true]
fill 215 -27 359 217 -27 361 minecraft:iron_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=true]
fill 189 -23 367 191 -23 369 minecraft:iron_trapdoor[facing=north,half=bottom,open=false,powered=false,waterlogged=true]
fill 200 -17 395 200 -14 397 minecraft:iron_bars[waterlogged=true]
fill 196 -17 273 196 -15 275 minecraft:prismarine_bricks
fill 245 -17 303 247 -15 303 minecraft:prismarine_bricks
fill 265 -17 303 267 -15 303 minecraft:prismarine_bricks
fill 209 -17 357 209 -15 359 minecraft:prismarine_bricks
fill 291 -17 402 291 -14 404 minecraft:iron_bars[waterlogged=false]
setblock 178 -24 281 minecraft:oak_trapdoor[half=bottom,facing=north,open=false,powered=false,waterlogged=true]
setblock 190 -14 322 minecraft:oak_trapdoor[half=bottom,facing=north,open=false,powered=false,waterlogged=true]
setblock 238 -17 322 minecraft:oak_trapdoor[half=bottom,facing=north,open=false,powered=false,waterlogged=true]
setblock 260 -17 322 minecraft:oak_trapdoor[half=bottom,facing=north,open=false,powered=false,waterlogged=true]
setblock 260 -16 346 minecraft:oak_trapdoor[half=bottom,facing=south,open=false,powered=false,waterlogged=true]
setblock 266 -16 346 minecraft:oak_trapdoor[half=bottom,facing=south,open=false,powered=false,waterlogged=true]
setblock 272 -16 346 minecraft:oak_trapdoor[half=bottom,facing=south,open=false,powered=false,waterlogged=true]
setblock 278 -16 346 minecraft:oak_trapdoor[half=bottom,facing=south,open=false,powered=false,waterlogged=true]
setblock 238 -17 361 minecraft:oak_trapdoor[half=bottom,facing=north,open=false,powered=false,waterlogged=true]
setblock 170 -16 346 minecraft:oak_trapdoor[half=bottom,facing=south,open=false,powered=false,waterlogged=true]
setblock 174 -16 346 minecraft:oak_trapdoor[half=bottom,facing=south,open=false,powered=false,waterlogged=true]
setblock 178 -16 346 minecraft:oak_trapdoor[half=bottom,facing=south,open=false,powered=false,waterlogged=true]
setblock 242 -16 304 minecraft:oak_trapdoor[half=bottom,facing=south,open=false,powered=false,waterlogged=true]
setblock 262 -16 304 minecraft:oak_trapdoor[half=bottom,facing=south,open=false,powered=false,waterlogged=true]
setblock 210 -16 362 minecraft:oak_trapdoor[half=bottom,facing=east,open=false,powered=false,waterlogged=true]
scoreboard objectives add aqua dummy
scoreboard players set #s4 aqua 0
scoreboard players set #cle aqua 0
scoreboard players set #kp aqua 0
scoreboard players set #t aqua 0
clear @a minecraft:tripwire_hook[minecraft:custom_name='"Clé du Récif"']
tellraw @a {"text":"Sanctuaire remis a zero.","color":"gray"}
