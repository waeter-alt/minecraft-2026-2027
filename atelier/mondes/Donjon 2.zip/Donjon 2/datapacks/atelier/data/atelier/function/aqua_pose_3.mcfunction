# [claude-build] Nettoie et decharge.
kill @e[type=item]
forceload remove all
tellraw @a [{"text":"Le sanctuaire est prêt. Entrée : ","color":"green"},{"text":"[/tp @s 178 -17 272 0 0]","color":"aqua","underlined":true,"clickEvent":{"action":"run_command","value":"/tp @s 178 -17 272 0 0"},"hoverEvent":{"action":"show_text","contents":"Cliquer pour y aller"}}]
