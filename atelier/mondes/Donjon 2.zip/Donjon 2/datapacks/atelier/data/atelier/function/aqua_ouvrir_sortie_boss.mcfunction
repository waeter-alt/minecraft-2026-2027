# [claude-build] Ouvre la sortie du boss (a relier a la mort du boss).
fill 291 -17 402 291 -14 404 minecraft:air
playsound minecraft:block.iron_door.open master @a 291 -17 402 2 0.6
