# [claude-build] Pose automatique, une seule fois (drapeau #aqua).
scoreboard objectives add atelier dummy
execute unless score #aqua atelier matches 1 run schedule function atelier:aqua_pose 100t
scoreboard players set #aqua atelier 1
