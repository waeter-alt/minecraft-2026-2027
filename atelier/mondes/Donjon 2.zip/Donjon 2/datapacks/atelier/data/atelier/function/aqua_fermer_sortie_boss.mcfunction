# [claude-build] Referme la sortie du boss.
fill 291 -17 402 291 -14 404 minecraft:iron_bars[waterlogged=false]
