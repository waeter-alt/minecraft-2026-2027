# [claude-build] Supprime le crochet du grappin du joueur dont l identifiant est passe en parametre.
$kill @e[type=grappin:crochet,nbt={Owner:$(uuid)}]
