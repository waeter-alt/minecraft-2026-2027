# [claude-build] Pose automatique, une seule fois (drapeau #temple).
scoreboard objectives add atelier dummy
execute unless score #temple atelier matches 1 run schedule function atelier:temple_pose 100t
scoreboard players set #temple atelier 1
