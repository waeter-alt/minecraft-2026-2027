# [claude-build] Remet le temple a zero : portes fermees, leviers baisses, enigmes et cle remises, pieges rearmes.
fill 194 0 -29 196 3 -29 minecraft:iron_bars[waterlogged=false]
fill 195 -20 27 197 -17 27 minecraft:iron_bars[waterlogged=false]
fill 189 10 134 191 13 134 minecraft:iron_bars[waterlogged=false]
fill 197 2 -53 199 4 -53 minecraft:cracked_stone_bricks
fill 253 2 -24 255 4 -24 minecraft:bookshelf
fill 245 -14 41 245 -12 43 minecraft:rooted_dirt
setblock 158 4 -41 minecraft:lever[face=wall,facing=east,powered=false]
setblock 190 4 -47 minecraft:lever[face=wall,facing=east,powered=false]
setblock 218 -13 12 minecraft:dripstone_block
setblock 218 -14 12 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock 218 -15 12 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 229 -13 12 minecraft:dripstone_block
setblock 229 -14 12 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock 229 -15 12 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
fill 220 -21 11 223 -21 13 minecraft:spruce_planks
fill 240 -21 11 243 -21 13 minecraft:spruce_planks
setblock 191 9 -42 minecraft:chiseled_stone_bricks
setblock 239 9 -42 minecraft:chiseled_stone_bricks
setblock 223 9 -31 minecraft:chiseled_stone_bricks
scoreboard objectives add temple dummy
scoreboard players set #se temple 0
scoreboard players set #ss temple 0
scoreboard players set #porte temple 0
scoreboard players set #t1 temple 0
scoreboard players set #t2 temple 0
scoreboard players set #fe temple 0
scoreboard players set #fw temple 0
scoreboard players set #fp temple 0
clear @a minecraft:tripwire_hook[minecraft:custom_name='"Clé de racine"']
tellraw @a {"text":"Temple remis a zero.","color":"gray"}
