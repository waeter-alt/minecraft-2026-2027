# [claude-build] Pose le Temple des Mille Racines (une seule fois, sans pause).
forceload add 150 -65 279 150
tellraw @a {"text":"Temple : 15 secondes de chargement, puis le jeu va se figer un moment. Ne mets pas en pause.","color":"gold"}
schedule function atelier:temple_pose_2 300t
