# [claude-build] Referme la sortie du boss (remise a zero de la salle).
fill 189 10 134 191 13 134 minecraft:iron_bars[waterlogged=false]
