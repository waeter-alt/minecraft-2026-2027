# [claude-build] Nettoie et decharge.
kill @e[type=item]
forceload remove all
tellraw @a [{"text":"Le temple est prêt. Entrée : ","color":"green"},{"text":"[/tp @s 215 22 -3 0 0]","color":"aqua","underlined":true,"clickEvent":{"action":"run_command","value":"/tp @s 215 22 -3 0 0"},"hoverEvent":{"action":"show_text","contents":"Cliquer pour y aller"}}]
