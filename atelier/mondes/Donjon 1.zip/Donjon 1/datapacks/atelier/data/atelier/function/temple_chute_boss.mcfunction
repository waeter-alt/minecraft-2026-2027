# [claude-build] Un joueur est tombe dans le gouffre du boss : on decroche son grappin, chute lente (pas de degats), retour sur la plateforme de depart.
data modify storage atelier:temple chute.uuid set from entity @s UUID
function atelier:temple_decrocher with storage atelier:temple chute
effect give @s minecraft:slow_falling 3 0 true
tp @s 197.5 -20 74.5 0 0
title @s actionbar {"text":"Tu es tombé !","color":"red"}
