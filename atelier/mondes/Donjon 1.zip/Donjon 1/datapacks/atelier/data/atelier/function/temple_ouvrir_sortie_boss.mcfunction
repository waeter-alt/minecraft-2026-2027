# [claude-build] Ouvre la sortie du boss (a relier a la mort du boss).
fill 189 10 134 191 13 134 minecraft:air
playsound minecraft:block.iron_door.open master @a 189 10 134 2 0.6
