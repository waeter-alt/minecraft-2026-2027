# [claude-build] Le mauvais bloc : la serie repart de zero (on peut relancer la melodie avec le bouton).
scoreboard players set #mq suspendu 0
execute positioned 3 14 -40 run playsound minecraft:entity.villager.no master @a[distance=..30] ~ ~ ~ 1 0.9
execute positioned 3 14 -40 run title @a[distance=..30] actionbar {"text":"Faux : la série recommence","color":"red"}
