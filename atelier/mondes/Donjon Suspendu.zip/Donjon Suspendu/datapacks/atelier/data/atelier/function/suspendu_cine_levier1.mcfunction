# [claude-build] Cinematique « levier1 » : une image par tick (la camera), et ses evenements (sons, effets).
execute if score #t cine matches 1 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.776 -12.000 -41.798 53.435 33.690
execute if score #t cine matches 2 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.771 -12.005 -41.794 53.435 33.690
execute if score #t cine matches 3 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.755 -12.018 -41.782 53.435 33.690
execute if score #t cine matches 4 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.728 -12.040 -41.762 53.435 33.690
execute if score #t cine matches 5 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.692 -12.070 -41.735 53.435 33.690
execute if score #t cine matches 6 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.646 -12.108 -41.701 53.435 33.690
execute if score #t cine matches 7 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.592 -12.153 -41.661 53.435 33.690
execute if score #t cine matches 8 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.529 -12.206 -41.614 53.435 33.690
execute if score #t cine matches 9 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.457 -12.265 -41.561 53.435 33.690
execute if score #t cine matches 10 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.378 -12.330 -41.503 53.435 33.690
execute if score #t cine matches 11 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.292 -12.402 -41.439 53.435 33.690
execute if score #t cine matches 12 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.199 -12.479 -41.370 53.435 33.690
execute if score #t cine matches 13 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.100 -12.562 -41.296 53.435 33.690
execute if score #t cine matches 14 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.994 -12.649 -41.217 53.435 33.690
execute if score #t cine matches 15 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.883 -12.742 -41.135 53.435 33.690
execute if score #t cine matches 16 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.767 -12.838 -41.049 53.435 33.690
execute if score #t cine matches 17 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.646 -12.938 -40.959 53.435 33.690
execute if score #t cine matches 18 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.520 -13.042 -40.866 53.435 33.690
execute if score #t cine matches 19 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.391 -13.150 -40.770 53.435 33.690
execute if score #t cine matches 20 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.259 -13.260 -40.672 53.435 33.690
execute if score #t cine matches 21 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.123 -13.372 -40.571 53.435 33.690
execute if score #t cine matches 22 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.985 -13.487 -40.469 53.435 33.690
execute if score #t cine matches 23 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.844 -13.604 -40.365 53.435 33.690
execute if score #t cine matches 24 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.702 -13.722 -40.259 53.435 33.690
execute if score #t cine matches 25 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.559 -13.841 -40.153 53.435 33.690
execute if score #t cine matches 26 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.414 -13.961 -40.046 53.435 33.690
execute if score #t cine matches 27 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.269 -14.081 -39.938 53.435 33.690
execute if score #t cine matches 28 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.124 -14.201 -39.831 53.435 33.690
execute if score #t cine matches 29 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.980 -14.321 -39.723 53.435 33.690
execute if score #t cine matches 30 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.836 -14.440 -39.617 53.435 33.690
execute if score #t cine matches 31 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.694 -14.559 -39.511 53.435 33.690
execute if score #t cine matches 32 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.553 -14.676 -39.407 53.435 33.690
execute if score #t cine matches 33 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.414 -14.791 -39.304 53.435 33.690
execute if score #t cine matches 34 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.277 -14.904 -39.202 53.435 33.690
execute if score #t cine matches 35 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.144 -15.015 -39.103 53.435 33.690
execute if score #t cine matches 36 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.014 -15.123 -39.007 53.435 33.690
execute if score #t cine matches 37 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.888 -15.228 -38.913 53.435 33.690
execute if score #t cine matches 38 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.766 -15.329 -38.823 53.435 33.690
execute if score #t cine matches 39 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.648 -15.427 -38.736 53.435 33.690
execute if score #t cine matches 40 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.536 -15.520 -38.652 53.435 33.690
execute if score #t cine matches 41 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.425 -15.612 -38.570 53.435 33.690
execute if score #t cine matches 42 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.314 -15.704 -38.488 53.435 33.690
execute if score #t cine matches 43 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.202 -15.797 -38.404 53.435 33.690
execute if score #t cine matches 44 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.088 -15.891 -38.320 53.435 33.690
execute if score #t cine matches 45 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.974 -15.986 -38.236 53.435 33.690
execute if score #t cine matches 46 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.860 -16.081 -38.151 53.435 33.690
execute if score #t cine matches 47 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.744 -16.177 -38.065 53.435 33.690
execute if score #t cine matches 48 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.629 -16.273 -37.979 53.435 33.690
execute if score #t cine matches 49 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.512 -16.369 -37.893 53.435 33.690
execute if score #t cine matches 50 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.396 -16.466 -37.807 53.435 33.690
execute if score #t cine matches 51 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.279 -16.563 -37.720 53.435 33.690
execute if score #t cine matches 52 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.161 -16.661 -37.633 53.435 33.690
execute if score #t cine matches 53 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.044 -16.758 -37.546 53.435 33.690
execute if score #t cine matches 54 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 103.926 -16.856 -37.459 53.435 33.690
execute if score #t cine matches 55 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 103.809 -16.953 -37.371 53.435 33.690
execute if score #t cine matches 56 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 103.691 -17.051 -37.284 53.435 33.690
execute if score #t cine matches 57 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 103.574 -17.148 -37.197 53.435 33.690
execute if score #t cine matches 58 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 103.457 -17.245 -37.111 53.435 33.690
execute if score #t cine matches 59 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 103.340 -17.342 -37.024 53.435 33.690
execute if score #t cine matches 60 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 103.224 -17.439 -36.938 53.435 33.690
execute if score #t cine matches 61 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 103.108 -17.535 -36.852 53.435 33.690
execute if score #t cine matches 62 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 102.993 -17.630 -36.766 53.435 33.690
execute if score #t cine matches 63 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 102.878 -17.726 -36.681 53.435 33.690
execute if score #t cine matches 64 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 102.764 -17.820 -36.597 53.435 33.690
execute if score #t cine matches 65 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 102.651 -17.914 -36.513 53.435 33.690
execute if score #t cine matches 66 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 102.539 -18.007 -36.430 53.435 33.690
execute if score #t cine matches 67 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 102.428 -18.100 -36.347 53.435 33.690
execute if score #t cine matches 68 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 102.317 -18.191 -36.265 53.435 33.690
execute if score #t cine matches 69 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 102.208 -18.282 -36.184 53.435 33.690
execute if score #t cine matches 70 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 102.100 -18.372 -36.104 53.435 33.690
execute if score #t cine matches 71 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 101.993 -18.460 -36.025 53.435 33.690
execute if score #t cine matches 72 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 101.888 -18.548 -35.947 53.435 33.690
execute if score #t cine matches 73 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 101.784 -18.634 -35.869 53.435 33.690
execute if score #t cine matches 74 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 101.681 -18.719 -35.793 53.435 33.690
execute if score #t cine matches 75 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 101.580 -18.803 -35.718 53.435 33.690
execute if score #t cine matches 76 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 101.481 -18.885 -35.645 53.435 33.690
execute if score #t cine matches 77 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 101.383 -18.966 -35.572 53.435 33.690
execute if score #t cine matches 78 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 101.288 -19.046 -35.501 53.435 33.690
execute if score #t cine matches 79 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 101.194 -19.124 -35.432 53.435 33.690
execute if score #t cine matches 80 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 101.102 -19.200 -35.364 53.435 33.690
execute if score #t cine matches 81 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 101.011 -19.276 -35.296 53.435 33.690
execute if score #t cine matches 82 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 100.919 -19.352 -35.228 53.435 33.690
execute if score #t cine matches 83 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 100.827 -19.428 -35.160 53.435 33.690
execute if score #t cine matches 84 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 100.735 -19.504 -35.092 53.435 33.690
execute if score #t cine matches 85 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 100.644 -19.580 -35.024 53.435 33.690
execute if score #t cine matches 86 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 100.553 -19.656 -34.956 53.435 33.690
execute if score #t cine matches 87 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 100.462 -19.731 -34.889 53.435 33.690
execute if score #t cine matches 88 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 100.373 -19.805 -34.823 53.435 33.690
execute if score #t cine matches 89 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 100.285 -19.878 -34.758 53.435 33.690
execute if score #t cine matches 90 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 100.198 -19.950 -34.693 53.435 33.690
execute if score #t cine matches 91 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 100.114 -20.020 -34.631 53.435 33.690
execute if score #t cine matches 92 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 100.031 -20.089 -34.569 53.435 33.690
execute if score #t cine matches 93 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.950 -20.156 -34.510 53.435 33.690
execute if score #t cine matches 94 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.873 -20.220 -34.452 53.435 33.690
execute if score #t cine matches 95 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.797 -20.283 -34.396 53.435 33.690
execute if score #t cine matches 96 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.725 -20.343 -34.343 53.435 33.690
execute if score #t cine matches 97 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.656 -20.400 -34.292 53.435 33.690
execute if score #t cine matches 98 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.591 -20.454 -34.243 53.435 33.690
execute if score #t cine matches 99 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.530 -20.505 -34.197 53.435 33.690
execute if score #t cine matches 100 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.472 -20.553 -34.155 53.435 33.690
execute if score #t cine matches 101 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.419 -20.597 -34.115 53.435 33.690
execute if score #t cine matches 102 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.370 -20.637 -34.079 53.435 33.690
execute if score #t cine matches 103 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.326 -20.674 -34.047 53.435 33.690
execute if score #t cine matches 104 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.288 -20.706 -34.018 53.435 33.690
execute if score #t cine matches 105 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.254 -20.734 -33.993 53.435 33.690
execute if score #t cine matches 106 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.226 -20.757 -33.972 53.435 33.690
execute if score #t cine matches 107 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.204 -20.776 -33.956 53.435 33.690
execute if score #t cine matches 108 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.188 -20.789 -33.944 53.435 33.690
execute if score #t cine matches 109 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.178 -20.797 -33.936 53.435 33.690
execute if score #t cine matches 110 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.174 -20.800 -33.934 53.435 33.690
execute if score #t cine matches 2 run title @a[tag=cine] actionbar {"text":"Un pilier sort de l'abîme…","color":"gray"}
execute if score #t cine matches 12 run fill 89 -61 -30 91 -61 -30 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 88 -61 -29 92 -61 -29 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 88 -61 -28 92 -61 -28 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 88 -61 -27 92 -61 -27 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 89 -61 -26 91 -61 -26 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 89 -60 -30 91 -60 -30 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 88 -60 -29 92 -60 -29 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 88 -60 -28 92 -60 -28 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 88 -60 -27 92 -60 -27 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 89 -60 -26 91 -60 -26 minecraft:stone_bricks
execute if score #t cine matches 12 run particle minecraft:campfire_cosy_smoke 90.500 -60.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 12 run particle minecraft:dust_plume 90.500 -60.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 12 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 12 run execute as @a[tag=cine] at @s run playsound minecraft:block.piston.extend master @s ~ ~ ~ 0.8 0.5
execute if score #t cine matches 13 run fill 89 -59 -30 91 -59 -30 minecraft:stone_bricks
execute if score #t cine matches 13 run fill 88 -59 -29 92 -59 -29 minecraft:stone_bricks
execute if score #t cine matches 13 run fill 88 -59 -28 92 -59 -28 minecraft:stone_bricks
execute if score #t cine matches 13 run fill 88 -59 -27 92 -59 -27 minecraft:stone_bricks
execute if score #t cine matches 13 run fill 89 -59 -26 91 -59 -26 minecraft:stone_bricks
execute if score #t cine matches 14 run fill 89 -58 -30 91 -58 -30 minecraft:chiseled_stone_bricks
execute if score #t cine matches 14 run fill 88 -58 -29 92 -58 -29 minecraft:chiseled_stone_bricks
execute if score #t cine matches 14 run fill 88 -58 -28 92 -58 -28 minecraft:chiseled_stone_bricks
execute if score #t cine matches 14 run fill 88 -58 -27 92 -58 -27 minecraft:chiseled_stone_bricks
execute if score #t cine matches 14 run fill 89 -58 -26 91 -58 -26 minecraft:chiseled_stone_bricks
execute if score #t cine matches 15 run fill 89 -57 -30 91 -57 -30 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 88 -57 -29 92 -57 -29 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 88 -57 -28 92 -57 -28 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 88 -57 -27 92 -57 -27 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 89 -57 -26 91 -57 -26 minecraft:stone_bricks
execute if score #t cine matches 15 run particle minecraft:campfire_cosy_smoke 90.500 -57.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 15 run particle minecraft:dust_plume 90.500 -57.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 16 run fill 89 -56 -30 91 -56 -30 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 88 -56 -29 92 -56 -29 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 88 -56 -28 92 -56 -28 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 88 -56 -27 92 -56 -27 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 89 -56 -26 91 -56 -26 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 89 -55 -30 91 -55 -30 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 88 -55 -29 92 -55 -29 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 88 -55 -28 92 -55 -28 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 88 -55 -27 92 -55 -27 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 89 -55 -26 91 -55 -26 minecraft:stone_bricks
execute if score #t cine matches 18 run fill 89 -54 -30 91 -54 -30 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run fill 88 -54 -29 92 -54 -29 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run fill 88 -54 -28 92 -54 -28 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run fill 88 -54 -27 92 -54 -27 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run fill 89 -54 -26 91 -54 -26 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run particle minecraft:campfire_cosy_smoke 90.500 -54.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 18 run particle minecraft:dust_plume 90.500 -54.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 18 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 19 run fill 89 -53 -30 91 -53 -30 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 88 -53 -29 92 -53 -29 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 88 -53 -28 92 -53 -28 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 88 -53 -27 92 -53 -27 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 89 -53 -26 91 -53 -26 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 89 -52 -30 91 -52 -30 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 88 -52 -29 92 -52 -29 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 88 -52 -28 92 -52 -28 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 88 -52 -27 92 -52 -27 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 89 -52 -26 91 -52 -26 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 89 -51 -30 91 -51 -30 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 88 -51 -29 92 -51 -29 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 88 -51 -28 92 -51 -28 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 88 -51 -27 92 -51 -27 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 89 -51 -26 91 -51 -26 minecraft:stone_bricks
execute if score #t cine matches 21 run particle minecraft:campfire_cosy_smoke 90.500 -51.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 21 run particle minecraft:dust_plume 90.500 -51.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 22 run fill 89 -50 -30 91 -50 -30 minecraft:chiseled_stone_bricks
execute if score #t cine matches 22 run fill 88 -50 -29 92 -50 -29 minecraft:chiseled_stone_bricks
execute if score #t cine matches 22 run fill 88 -50 -28 92 -50 -28 minecraft:chiseled_stone_bricks
execute if score #t cine matches 22 run fill 88 -50 -27 92 -50 -27 minecraft:chiseled_stone_bricks
execute if score #t cine matches 22 run fill 89 -50 -26 91 -50 -26 minecraft:chiseled_stone_bricks
execute if score #t cine matches 23 run fill 89 -49 -30 91 -49 -30 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 88 -49 -29 92 -49 -29 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 88 -49 -28 92 -49 -28 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 88 -49 -27 92 -49 -27 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 89 -49 -26 91 -49 -26 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 89 -48 -30 91 -48 -30 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 88 -48 -29 92 -48 -29 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 88 -48 -28 92 -48 -28 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 88 -48 -27 92 -48 -27 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 89 -48 -26 91 -48 -26 minecraft:stone_bricks
execute if score #t cine matches 24 run particle minecraft:campfire_cosy_smoke 90.500 -48.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 24 run particle minecraft:dust_plume 90.500 -48.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 24 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 25 run fill 89 -47 -30 91 -47 -30 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 88 -47 -29 92 -47 -29 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 88 -47 -28 92 -47 -28 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 88 -47 -27 92 -47 -27 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 89 -47 -26 91 -47 -26 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 89 -46 -30 91 -46 -30 minecraft:chiseled_stone_bricks
execute if score #t cine matches 25 run fill 88 -46 -29 92 -46 -29 minecraft:chiseled_stone_bricks
execute if score #t cine matches 25 run fill 88 -46 -28 92 -46 -28 minecraft:chiseled_stone_bricks
execute if score #t cine matches 25 run fill 88 -46 -27 92 -46 -27 minecraft:chiseled_stone_bricks
execute if score #t cine matches 25 run fill 89 -46 -26 91 -46 -26 minecraft:chiseled_stone_bricks
execute if score #t cine matches 26 run fill 89 -45 -30 91 -45 -30 minecraft:stone_bricks
execute if score #t cine matches 26 run fill 88 -45 -29 92 -45 -29 minecraft:stone_bricks
execute if score #t cine matches 26 run fill 88 -45 -28 92 -45 -28 minecraft:stone_bricks
execute if score #t cine matches 26 run fill 88 -45 -27 92 -45 -27 minecraft:stone_bricks
execute if score #t cine matches 26 run fill 89 -45 -26 91 -45 -26 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 89 -44 -30 91 -44 -30 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 88 -44 -29 92 -44 -29 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 88 -44 -28 92 -44 -28 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 88 -44 -27 92 -44 -27 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 89 -44 -26 91 -44 -26 minecraft:stone_bricks
execute if score #t cine matches 27 run particle minecraft:campfire_cosy_smoke 90.500 -44.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 27 run particle minecraft:dust_plume 90.500 -44.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 28 run fill 89 -43 -30 91 -43 -30 minecraft:stone_bricks
execute if score #t cine matches 28 run fill 88 -43 -29 92 -43 -29 minecraft:stone_bricks
execute if score #t cine matches 28 run fill 88 -43 -28 92 -43 -28 minecraft:stone_bricks
execute if score #t cine matches 28 run fill 88 -43 -27 92 -43 -27 minecraft:stone_bricks
execute if score #t cine matches 28 run fill 89 -43 -26 91 -43 -26 minecraft:stone_bricks
execute if score #t cine matches 29 run fill 89 -42 -30 91 -42 -30 minecraft:chiseled_stone_bricks
execute if score #t cine matches 29 run fill 88 -42 -29 92 -42 -29 minecraft:chiseled_stone_bricks
execute if score #t cine matches 29 run fill 88 -42 -28 92 -42 -28 minecraft:chiseled_stone_bricks
execute if score #t cine matches 29 run fill 88 -42 -27 92 -42 -27 minecraft:chiseled_stone_bricks
execute if score #t cine matches 29 run fill 89 -42 -26 91 -42 -26 minecraft:chiseled_stone_bricks
execute if score #t cine matches 30 run fill 89 -41 -30 91 -41 -30 minecraft:stone_bricks
execute if score #t cine matches 30 run fill 88 -41 -29 92 -41 -29 minecraft:stone_bricks
execute if score #t cine matches 30 run fill 88 -41 -28 92 -41 -28 minecraft:stone_bricks
execute if score #t cine matches 30 run fill 88 -41 -27 92 -41 -27 minecraft:stone_bricks
execute if score #t cine matches 30 run fill 89 -41 -26 91 -41 -26 minecraft:stone_bricks
execute if score #t cine matches 30 run particle minecraft:campfire_cosy_smoke 90.500 -41.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 30 run particle minecraft:dust_plume 90.500 -41.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 30 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 31 run fill 89 -40 -30 91 -40 -30 minecraft:stone_bricks
execute if score #t cine matches 31 run fill 88 -40 -29 92 -40 -29 minecraft:stone_bricks
execute if score #t cine matches 31 run fill 88 -40 -28 92 -40 -28 minecraft:stone_bricks
execute if score #t cine matches 31 run fill 88 -40 -27 92 -40 -27 minecraft:stone_bricks
execute if score #t cine matches 31 run fill 89 -40 -26 91 -40 -26 minecraft:stone_bricks
execute if score #t cine matches 32 run fill 89 -39 -30 91 -39 -30 minecraft:stone_bricks
execute if score #t cine matches 32 run fill 88 -39 -29 92 -39 -29 minecraft:stone_bricks
execute if score #t cine matches 32 run fill 88 -39 -28 92 -39 -28 minecraft:stone_bricks
execute if score #t cine matches 32 run fill 88 -39 -27 92 -39 -27 minecraft:stone_bricks
execute if score #t cine matches 32 run fill 89 -39 -26 91 -39 -26 minecraft:stone_bricks
execute if score #t cine matches 33 run fill 89 -38 -30 91 -38 -30 minecraft:chiseled_stone_bricks
execute if score #t cine matches 33 run fill 88 -38 -29 92 -38 -29 minecraft:chiseled_stone_bricks
execute if score #t cine matches 33 run fill 88 -38 -28 92 -38 -28 minecraft:chiseled_stone_bricks
execute if score #t cine matches 33 run fill 88 -38 -27 92 -38 -27 minecraft:chiseled_stone_bricks
execute if score #t cine matches 33 run fill 89 -38 -26 91 -38 -26 minecraft:chiseled_stone_bricks
execute if score #t cine matches 33 run particle minecraft:campfire_cosy_smoke 90.500 -38.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 33 run particle minecraft:dust_plume 90.500 -38.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 34 run fill 89 -37 -30 91 -37 -30 minecraft:stone_bricks
execute if score #t cine matches 34 run fill 88 -37 -29 92 -37 -29 minecraft:stone_bricks
execute if score #t cine matches 34 run fill 88 -37 -28 92 -37 -28 minecraft:stone_bricks
execute if score #t cine matches 34 run fill 88 -37 -27 92 -37 -27 minecraft:stone_bricks
execute if score #t cine matches 34 run fill 89 -37 -26 91 -37 -26 minecraft:stone_bricks
execute if score #t cine matches 34 run setblock 82 -6 -22 minecraft:chain[axis=y]
execute if score #t cine matches 34 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 35 run fill 89 -36 -30 91 -36 -30 minecraft:stone_bricks
execute if score #t cine matches 35 run fill 88 -36 -29 92 -36 -29 minecraft:stone_bricks
execute if score #t cine matches 35 run fill 88 -36 -28 92 -36 -28 minecraft:stone_bricks
execute if score #t cine matches 35 run fill 88 -36 -27 92 -36 -27 minecraft:stone_bricks
execute if score #t cine matches 35 run fill 89 -36 -26 91 -36 -26 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 89 -35 -30 91 -35 -30 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 88 -35 -29 92 -35 -29 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 88 -35 -28 92 -35 -28 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 88 -35 -27 92 -35 -27 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 89 -35 -26 91 -35 -26 minecraft:stone_bricks
execute if score #t cine matches 36 run particle minecraft:campfire_cosy_smoke 90.500 -35.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 36 run particle minecraft:dust_plume 90.500 -35.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 36 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 36 run setblock 82 -7 -22 minecraft:chain[axis=y]
execute if score #t cine matches 36 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 37 run fill 89 -34 -30 91 -34 -30 minecraft:chiseled_stone_bricks
execute if score #t cine matches 37 run fill 88 -34 -29 92 -34 -29 minecraft:chiseled_stone_bricks
execute if score #t cine matches 37 run fill 88 -34 -28 92 -34 -28 minecraft:chiseled_stone_bricks
execute if score #t cine matches 37 run fill 88 -34 -27 92 -34 -27 minecraft:chiseled_stone_bricks
execute if score #t cine matches 37 run fill 89 -34 -26 91 -34 -26 minecraft:chiseled_stone_bricks
execute if score #t cine matches 38 run fill 89 -33 -30 91 -33 -30 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 88 -33 -29 92 -33 -29 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 88 -33 -28 92 -33 -28 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 88 -33 -27 92 -33 -27 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 89 -33 -26 91 -33 -26 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 89 -32 -30 91 -32 -30 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 88 -32 -29 92 -32 -29 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 88 -32 -28 92 -32 -28 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 88 -32 -27 92 -32 -27 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 89 -32 -26 91 -32 -26 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 89 -31 -30 91 -31 -30 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 88 -31 -29 92 -31 -29 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 88 -31 -28 92 -31 -28 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 88 -31 -27 92 -31 -27 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 89 -31 -26 91 -31 -26 minecraft:stone_bricks
execute if score #t cine matches 39 run particle minecraft:campfire_cosy_smoke 90.500 -31.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 39 run particle minecraft:dust_plume 90.500 -31.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 39 run setblock 82 -8 -22 minecraft:chain[axis=y]
execute if score #t cine matches 39 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 40 run fill 89 -30 -30 91 -30 -30 minecraft:chiseled_stone_bricks
execute if score #t cine matches 40 run fill 88 -30 -29 92 -30 -29 minecraft:chiseled_stone_bricks
execute if score #t cine matches 40 run fill 88 -30 -28 92 -30 -28 minecraft:chiseled_stone_bricks
execute if score #t cine matches 40 run fill 88 -30 -27 92 -30 -27 minecraft:chiseled_stone_bricks
execute if score #t cine matches 40 run fill 89 -30 -26 91 -30 -26 minecraft:chiseled_stone_bricks
execute if score #t cine matches 41 run fill 89 -29 -30 91 -29 -30 minecraft:stone_bricks
execute if score #t cine matches 41 run fill 88 -29 -29 92 -29 -29 minecraft:stone_bricks
execute if score #t cine matches 41 run fill 88 -29 -28 92 -29 -28 minecraft:stone_bricks
execute if score #t cine matches 41 run fill 88 -29 -27 92 -29 -27 minecraft:stone_bricks
execute if score #t cine matches 41 run fill 89 -29 -26 91 -29 -26 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 89 -28 -30 91 -28 -30 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 88 -28 -29 92 -28 -29 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 88 -28 -28 92 -28 -28 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 88 -28 -27 92 -28 -27 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 89 -28 -26 91 -28 -26 minecraft:stone_bricks
execute if score #t cine matches 42 run particle minecraft:campfire_cosy_smoke 90.500 -28.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 42 run particle minecraft:dust_plume 90.500 -28.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 42 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 42 run setblock 82 -9 -22 minecraft:chain[axis=y]
execute if score #t cine matches 42 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 43 run fill 89 -27 -30 91 -27 -30 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 88 -27 -29 92 -27 -29 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 88 -27 -28 92 -27 -28 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 88 -27 -27 92 -27 -27 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 89 -27 -26 91 -27 -26 minecraft:stone_bricks
execute if score #t cine matches 44 run fill 89 -26 -30 91 -26 -30 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run fill 88 -26 -29 92 -26 -29 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run fill 88 -26 -28 92 -26 -28 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run fill 88 -26 -27 92 -26 -27 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run fill 89 -26 -26 91 -26 -26 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run setblock 82 -10 -22 minecraft:chain[axis=y]
execute if score #t cine matches 44 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 45 run fill 89 -25 -30 91 -25 -30 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 88 -25 -29 92 -25 -29 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 88 -25 -28 92 -25 -28 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 88 -25 -27 92 -25 -27 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 89 -25 -26 91 -25 -26 minecraft:stone_bricks
execute if score #t cine matches 45 run particle minecraft:campfire_cosy_smoke 90.500 -25.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 45 run particle minecraft:dust_plume 90.500 -25.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 46 run fill 89 -24 -30 91 -24 -30 minecraft:stone_bricks
execute if score #t cine matches 46 run fill 88 -24 -29 92 -24 -29 minecraft:stone_bricks
execute if score #t cine matches 46 run fill 88 -24 -28 92 -24 -28 minecraft:stone_bricks
execute if score #t cine matches 46 run fill 88 -24 -27 92 -24 -27 minecraft:stone_bricks
execute if score #t cine matches 46 run fill 89 -24 -26 91 -24 -26 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 89 -23 -30 91 -23 -30 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 88 -23 -29 92 -23 -29 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 88 -23 -28 92 -23 -28 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 88 -23 -27 92 -23 -27 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 89 -23 -26 91 -23 -26 minecraft:stone_bricks
execute if score #t cine matches 47 run setblock 82 -11 -22 minecraft:chain[axis=y]
execute if score #t cine matches 47 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 48 run fill 89 -22 -30 91 -22 -30 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run fill 88 -22 -29 92 -22 -29 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run fill 88 -22 -28 92 -22 -28 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run fill 88 -22 -27 92 -22 -27 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run fill 89 -22 -26 91 -22 -26 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run particle minecraft:campfire_cosy_smoke 90.500 -22.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 48 run particle minecraft:dust_plume 90.500 -22.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 48 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 49 run fill 89 -21 -30 91 -21 -30 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 88 -21 -29 92 -21 -29 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 88 -21 -28 92 -21 -28 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 88 -21 -27 92 -21 -27 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 89 -21 -26 91 -21 -26 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 89 -20 -30 91 -20 -30 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 88 -20 -29 92 -20 -29 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 88 -20 -28 92 -20 -28 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 88 -20 -27 92 -20 -27 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 89 -20 -26 91 -20 -26 minecraft:stone_bricks
execute if score #t cine matches 50 run setblock 82 -12 -22 minecraft:chain[axis=y]
execute if score #t cine matches 50 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 51 run fill 89 -19 -30 91 -19 -30 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 88 -19 -29 92 -19 -29 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 88 -19 -28 92 -19 -28 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 88 -19 -27 92 -19 -27 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 89 -19 -26 91 -19 -26 minecraft:stone_bricks
execute if score #t cine matches 51 run particle minecraft:campfire_cosy_smoke 90.500 -19.000 -27.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 51 run particle minecraft:dust_plume 90.500 -19.000 -27.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 52 run setblock 82 -13 -22 minecraft:chain[axis=y]
execute if score #t cine matches 52 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 55 run setblock 82 -14 -22 minecraft:chain[axis=y]
execute if score #t cine matches 55 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 56 run function atelier:suspendu_ss2_l1_a1
execute if score #t cine matches 56 run execute as @a[tag=cine] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1 1.4
execute if score #t cine matches 62 run function atelier:suspendu_ss2_l1_a2
execute if score #t cine matches 62 run execute as @a[tag=cine] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1 1.4
execute if score #t cine matches 70 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.0
execute if score #t cine matches 74 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.26
execute if score #t cine matches 78 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
execute if score #t cine matches 78 run title @a[tag=cine] actionbar {"text":"Levier 1 : un point d'ancrage est apparu","color":"aqua"}
