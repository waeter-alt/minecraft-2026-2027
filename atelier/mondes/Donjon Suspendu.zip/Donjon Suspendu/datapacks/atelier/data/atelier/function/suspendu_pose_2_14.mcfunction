# [claude-build] Pose du donjon, etape 15 sur 18 (le terrain du gabarit : pierre, terre, herbe, air ; puis les salles ; puis la remise a zero).
place template atelier:suspendu_salle1 -65 -17 -68
schedule function atelier:suspendu_pose_2_15 2t
