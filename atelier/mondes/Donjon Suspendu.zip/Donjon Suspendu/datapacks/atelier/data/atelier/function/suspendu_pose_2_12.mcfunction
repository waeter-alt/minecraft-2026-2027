# [claude-build] Pose du donjon, etape 13 sur 13 (le terrain du gabarit : pierre, terre, herbe, air ; puis les salles ; puis la remise a zero).
place template atelier:suspendu_ss2 -65 -63 -64
kill @e[type=item]
function atelier:suspendu_reset
schedule function atelier:suspendu_pose_3 100t
