# [claude-build] Pose du donjon, etape 16 sur 18 (le terrain du gabarit : pierre, terre, herbe, air ; puis les salles ; puis la remise a zero).
place template atelier:suspendu_ss1 -50 -33 -65
schedule function atelier:suspendu_pose_2_16 2t
