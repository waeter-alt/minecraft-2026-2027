# [claude-build] Le levier 5 est tire : une cinematique montre les ancrages qui apparaissent un a un vers l'ile de la cle, puis le coffre de la cle de la derniere porte (ou tout apparait tout de suite si une autre cinematique est en cours).
scoreboard players set #l5 suspendu 1
execute positioned 27 -17 100 run playsound minecraft:block.beacon.activate master @a[distance=..40] ~ ~ ~ 1 1.4
scoreboard players operation #libre cine = #t cine
execute if score #libre cine matches 0 run function atelier:suspendu_cine_debut_cle
execute unless score #libre cine matches 0 run function atelier:suspendu_ss2_cle_tout
