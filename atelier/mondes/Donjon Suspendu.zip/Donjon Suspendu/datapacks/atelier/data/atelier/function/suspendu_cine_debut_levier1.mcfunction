# [claude-build] Lance la cinematique « levier1 » : la camera, puis les joueurs de la salle (en spectateur, tournes vers la camera).
scoreboard players set #id cine 61
scoreboard players set #t cine 1
scoreboard players set #nb cine 0
summon minecraft:armor_stand 109.776 -12.000 -41.798 {Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["cine_cam"],Rotation:[53.435f,33.690f]}
execute positioned 122 -17 -44 as @a[distance=..45,gamemode=!spectator] at @s run function atelier:suspendu_cine_joueur
