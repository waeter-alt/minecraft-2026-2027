# [claude-build] Un joueur s'approche de l'ile B : ses 2 ennemi(s) apparaissent (une seule fois).
scoreboard players set #e_B suspendu 1
summon minecraft:zombie 112 -17 -38 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
summon minecraft:skeleton 127 -17 -37 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
