# [claude-build] Le levier 4 est tire : une cinematique montre son pilier qui monte de la fosse (ou sa chaine qui descend du plafond) puis son ancrage (ou tout apparait tout de suite si une autre cinematique est en cours).
scoreboard players set #l4 suspendu 1
execute positioned 47 -17 61 run playsound minecraft:block.beacon.activate master @a[distance=..40] ~ ~ ~ 1 1.4
scoreboard players operation #libre cine = #t cine
execute if score #libre cine matches 0 run function atelier:suspendu_cine_debut_levier4
execute unless score #libre cine matches 0 run function atelier:suspendu_ss2_l4_tout
