# [claude-build] Le levier 4 est tire : ses ancrages apparaissent (un bloc d'ancrage et sa chaine, du plafond), avec un son et des particules.
scoreboard players set #l4 suspendu 1
fill 45 -14 92 45 -6 92 minecraft:chain[axis=y]
setblock 45 -15 92 grappin:ancrage
execute positioned 45 -15 92 run particle minecraft:end_rod ~ ~ ~ 0.3 0.6 0.3 0.05 30
execute positioned 45 -15 92 run playsound minecraft:block.chain.place master @a[distance=..60] ~ ~ ~ 2 0.8
execute positioned 47 -17 61 run playsound minecraft:block.beacon.activate master @a[distance=..40] ~ ~ ~ 1 1.4
execute positioned 47 -17 61 run title @a[distance=..40] actionbar {"text":"Levier 4 : un point d'ancrage est apparu","color":"aqua"}
