# [claude-build] Pose le donjon (sans pause).
forceload add -74 -86 93 121
forceload add 94 -86 261 121
tellraw @a {"text":"Donjon Suspendu : 30 secondes de chargement, puis la pose par morceaux (environ une minute, le jeu peut ralentir). Ne mets pas en pause.","color":"gold"}
schedule function atelier:suspendu_pose_2 600t
