# [claude-build] Remise a zero du donjon : cinematique arretee, monstres retires, coffres remis, portes refermees, scores a zero, cles retirees.
scoreboard objectives add suspendu dummy
scoreboard objectives add cine dummy
scoreboard objectives add cine_mode dummy
execute if score #t cine matches 1.. run function atelier:suspendu_cine_fin
gamerule doMobSpawning false
scoreboard players set #s1 suspendu 0
scoreboard players set #s2 suspendu 0
scoreboard players set #s3 suspendu 0
scoreboard players set #s4 suspendu 0
scoreboard players set #p1 suspendu 0
scoreboard players set #p2 suspendu 0
scoreboard players set #p3 suspendu 0
scoreboard players set #pm1 suspendu 0
kill @e[type=minecraft:zombie,tag=suspendu_s1]
kill @e[tag=suspendu_ss1a]
kill @e[tag=suspendu_ss1b]
kill @e[tag=suspendu_ss1m]
setblock 0 30 -32 minecraft:air
schedule clear atelier:suspendu_p1_glisse
schedule clear atelier:suspendu_p1_fin
schedule clear atelier:suspendu_p2_glisse
schedule clear atelier:suspendu_p2_fin
schedule clear atelier:suspendu_p3_glisse
schedule clear atelier:suspendu_p3_fin
schedule clear atelier:suspendu_pm1_glisse
schedule clear atelier:suspendu_pm1_fin
kill @e[type=minecraft:block_display,tag=porte1_dalle]
kill @e[type=minecraft:block_display,tag=porte2_dalle]
kill @e[type=minecraft:block_display,tag=porte3_dalle]
kill @e[type=minecraft:block_display,tag=portem1_dalle]
place template atelier:suspendu_porte1 9 30 -43
place template atelier:suspendu_porte2 -15 30 -45
place template atelier:suspendu_porte3 -7 30 -48
place template atelier:suspendu_portem1 2 2 -10
setblock -19 -5 14 minecraft:air
setblock 12 13 -36 minecraft:air
scoreboard players set #mt suspendu 0
scoreboard players set #mq suspendu 0
scoreboard players set #mok suspendu 0
setblock 3 16 -37 minecraft:red_concrete
setblock 3 16 -35 minecraft:blue_concrete
setblock 3 16 -33 minecraft:lime_concrete
setblock 3 16 -31 minecraft:yellow_concrete
setblock 3 16 -29 minecraft:purple_concrete
setblock 3 14 -37 minecraft:note_block[instrument=bell,note=5,powered=false]
setblock 3 14 -35 minecraft:note_block[instrument=chime,note=8,powered=false]
setblock 3 14 -33 minecraft:note_block[instrument=bit,note=10,powered=false]
setblock 3 14 -31 minecraft:note_block[instrument=iron_xylophone,note=12,powered=false]
setblock 3 14 -29 minecraft:note_block[instrument=xylophone,note=15,powered=false]
clear @a minecraft:tripwire_hook[minecraft:custom_name='"Clé bleu"']
clear @a minecraft:tripwire_hook[minecraft:custom_name='"Clé jaune"']
clear @a minecraft:tripwire_hook[minecraft:custom_name='"Clé rouge"']
tellraw @a {"text":"Donjon remis à zéro.","color":"gray"}
scoreboard players set #l1 suspendu 0
setblock 122 -17 -44 minecraft:lever[face=floor,facing=north,powered=false]
fill 90 -15 -28 90 -6 -28 minecraft:air
fill 82 -15 -22 82 -6 -22 minecraft:air
fill 89 -61 -30 91 -18 -30 minecraft:air
fill 88 -61 -29 92 -18 -29 minecraft:air
fill 88 -61 -28 92 -18 -28 minecraft:air
fill 88 -61 -27 92 -18 -27 minecraft:air
fill 89 -61 -26 91 -18 -26 minecraft:air
setblock 90 -16 -28 minecraft:air
scoreboard players set #l2 suspendu 0
setblock 62 -16 -16 minecraft:lever[face=floor,facing=north,powered=false]
fill 88 -15 -56 88 -6 -56 minecraft:air
scoreboard players set #l3 suspendu 0
setblock 87 -17 -60 minecraft:lever[face=floor,facing=north,powered=false]
fill 112 -15 14 112 -6 14 minecraft:air
fill 119 -15 41 119 -6 41 minecraft:air
fill 111 -61 12 113 -18 12 minecraft:air
fill 110 -61 13 114 -18 13 minecraft:air
fill 110 -61 14 114 -18 14 minecraft:air
fill 110 -61 15 114 -18 15 minecraft:air
fill 111 -61 16 113 -18 16 minecraft:air
setblock 112 -16 14 minecraft:air
scoreboard players set #l4 suspendu 0
setblock 47 -17 61 minecraft:lever[face=floor,facing=north,powered=false]
fill 45 -15 92 45 -6 92 minecraft:air
scoreboard players set #l5 suspendu 0
setblock 27 -17 100 minecraft:lever[face=floor,facing=north,powered=false]
fill 75 -15 93 75 -6 93 minecraft:air
fill 97 -15 91 97 -6 91 minecraft:air
fill 119 -15 89 119 -6 89 minecraft:air
fill 141 -15 86 141 -6 86 minecraft:air
fill 74 -61 91 76 -18 91 minecraft:air
fill 73 -61 92 77 -18 92 minecraft:air
fill 73 -61 93 77 -18 93 minecraft:air
fill 73 -61 94 77 -18 94 minecraft:air
fill 74 -61 95 76 -18 95 minecraft:air
setblock 75 -16 93 minecraft:air
fill 96 -61 89 98 -18 89 minecraft:air
fill 95 -61 90 99 -18 90 minecraft:air
fill 95 -61 91 99 -18 91 minecraft:air
fill 95 -61 92 99 -18 92 minecraft:air
fill 96 -61 93 98 -18 93 minecraft:air
setblock 97 -16 91 minecraft:air
fill 118 -61 87 120 -18 87 minecraft:air
fill 117 -61 88 121 -18 88 minecraft:air
fill 117 -61 89 121 -18 89 minecraft:air
fill 117 -61 90 121 -18 90 minecraft:air
fill 118 -61 91 120 -18 91 minecraft:air
setblock 119 -16 89 minecraft:air
scoreboard players set #e_B suspendu 0
scoreboard players set #e_C suspendu 0
scoreboard players set #e_A suspendu 0
scoreboard players set #e_F suspendu 0
scoreboard players set #e_PONT suspendu 0
scoreboard players set #e_G suspendu 0
scoreboard players set #e_H suspendu 0
scoreboard players set #e_I suspendu 0
kill @e[tag=suspendu_ss2e]
setblock 153 -17 100 minecraft:air
