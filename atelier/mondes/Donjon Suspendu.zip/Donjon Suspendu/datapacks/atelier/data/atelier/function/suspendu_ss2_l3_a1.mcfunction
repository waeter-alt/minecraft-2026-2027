# [claude-build] Levier 3 : l'ancrage 1 sur 2 apparait (avec son pilier s'il est au dessus du vide).
fill 111 -61 12 113 -19 12 minecraft:stone_bricks
fill 110 -61 13 114 -19 13 minecraft:stone_bricks
fill 110 -61 14 114 -19 14 minecraft:stone_bricks
fill 110 -61 15 114 -19 15 minecraft:stone_bricks
fill 111 -61 16 113 -19 16 minecraft:stone_bricks
fill 111 -22 12 113 -22 12 minecraft:chiseled_stone_bricks
fill 110 -22 13 114 -22 13 minecraft:chiseled_stone_bricks
fill 110 -22 14 114 -22 14 minecraft:chiseled_stone_bricks
fill 110 -22 15 114 -22 15 minecraft:chiseled_stone_bricks
fill 111 -22 16 113 -22 16 minecraft:chiseled_stone_bricks
fill 111 -26 12 113 -26 12 minecraft:chiseled_stone_bricks
fill 110 -26 13 114 -26 13 minecraft:chiseled_stone_bricks
fill 110 -26 14 114 -26 14 minecraft:chiseled_stone_bricks
fill 110 -26 15 114 -26 15 minecraft:chiseled_stone_bricks
fill 111 -26 16 113 -26 16 minecraft:chiseled_stone_bricks
fill 111 -30 12 113 -30 12 minecraft:chiseled_stone_bricks
fill 110 -30 13 114 -30 13 minecraft:chiseled_stone_bricks
fill 110 -30 14 114 -30 14 minecraft:chiseled_stone_bricks
fill 110 -30 15 114 -30 15 minecraft:chiseled_stone_bricks
fill 111 -30 16 113 -30 16 minecraft:chiseled_stone_bricks
fill 111 -34 12 113 -34 12 minecraft:chiseled_stone_bricks
fill 110 -34 13 114 -34 13 minecraft:chiseled_stone_bricks
fill 110 -34 14 114 -34 14 minecraft:chiseled_stone_bricks
fill 110 -34 15 114 -34 15 minecraft:chiseled_stone_bricks
fill 111 -34 16 113 -34 16 minecraft:chiseled_stone_bricks
fill 111 -38 12 113 -38 12 minecraft:chiseled_stone_bricks
fill 110 -38 13 114 -38 13 minecraft:chiseled_stone_bricks
fill 110 -38 14 114 -38 14 minecraft:chiseled_stone_bricks
fill 110 -38 15 114 -38 15 minecraft:chiseled_stone_bricks
fill 111 -38 16 113 -38 16 minecraft:chiseled_stone_bricks
fill 111 -42 12 113 -42 12 minecraft:chiseled_stone_bricks
fill 110 -42 13 114 -42 13 minecraft:chiseled_stone_bricks
fill 110 -42 14 114 -42 14 minecraft:chiseled_stone_bricks
fill 110 -42 15 114 -42 15 minecraft:chiseled_stone_bricks
fill 111 -42 16 113 -42 16 minecraft:chiseled_stone_bricks
fill 111 -46 12 113 -46 12 minecraft:chiseled_stone_bricks
fill 110 -46 13 114 -46 13 minecraft:chiseled_stone_bricks
fill 110 -46 14 114 -46 14 minecraft:chiseled_stone_bricks
fill 110 -46 15 114 -46 15 minecraft:chiseled_stone_bricks
fill 111 -46 16 113 -46 16 minecraft:chiseled_stone_bricks
fill 111 -50 12 113 -50 12 minecraft:chiseled_stone_bricks
fill 110 -50 13 114 -50 13 minecraft:chiseled_stone_bricks
fill 110 -50 14 114 -50 14 minecraft:chiseled_stone_bricks
fill 110 -50 15 114 -50 15 minecraft:chiseled_stone_bricks
fill 111 -50 16 113 -50 16 minecraft:chiseled_stone_bricks
fill 111 -54 12 113 -54 12 minecraft:chiseled_stone_bricks
fill 110 -54 13 114 -54 13 minecraft:chiseled_stone_bricks
fill 110 -54 14 114 -54 14 minecraft:chiseled_stone_bricks
fill 110 -54 15 114 -54 15 minecraft:chiseled_stone_bricks
fill 111 -54 16 113 -54 16 minecraft:chiseled_stone_bricks
fill 111 -58 12 113 -58 12 minecraft:chiseled_stone_bricks
fill 110 -58 13 114 -58 13 minecraft:chiseled_stone_bricks
fill 110 -58 14 114 -58 14 minecraft:chiseled_stone_bricks
fill 110 -58 15 114 -58 15 minecraft:chiseled_stone_bricks
fill 111 -58 16 113 -58 16 minecraft:chiseled_stone_bricks
setblock 110 -18 13 minecraft:tuff
setblock 110 -18 14 minecraft:andesite
setblock 110 -18 15 minecraft:mossy_cobblestone
setblock 111 -18 12 minecraft:stone
setblock 111 -18 13 minecraft:stone
setblock 111 -18 14 minecraft:tuff
setblock 111 -18 15 minecraft:andesite
setblock 111 -18 16 minecraft:andesite
setblock 112 -18 12 minecraft:mossy_cobblestone
setblock 112 -18 13 minecraft:stone
setblock 112 -18 14 minecraft:stone
setblock 112 -18 15 minecraft:stone
setblock 112 -18 16 minecraft:andesite
setblock 113 -18 12 minecraft:stone
setblock 113 -18 13 minecraft:stone
setblock 113 -18 14 minecraft:tuff
setblock 113 -18 15 minecraft:stone
setblock 113 -18 16 minecraft:stone
setblock 114 -18 13 minecraft:stone
setblock 114 -18 14 minecraft:stone
setblock 114 -18 15 minecraft:stone
setblock 112 -16 14 minecraft:light[level=13]
execute positioned 112 -17 14 run particle minecraft:poof ~ ~ ~ 1.2 0.2 1.2 0.05 40
execute positioned 112 -18 14 run playsound minecraft:block.stone.place master @a[distance=..60] ~ ~ ~ 3 0.6
fill 112 -14 14 112 -6 14 minecraft:chain[axis=y]
setblock 112 -15 14 grappin:ancrage
execute positioned 112 -15 14 run particle minecraft:end_rod ~ ~ ~ 0.3 0.6 0.3 0.05 30
execute positioned 112 -15 14 run playsound minecraft:block.chain.place master @a[distance=..60] ~ ~ ~ 2 0.8
