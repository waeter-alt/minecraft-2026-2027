# [claude-build] A chaque chargement : les objectifs de scores du donjon et des cinematiques, la regle des monstres.
scoreboard objectives add suspendu dummy
scoreboard objectives add cine dummy
scoreboard objectives add cine_mode dummy
execute unless score #t cine matches 0.. run scoreboard players set #t cine 0
gamerule doMobSpawning false
