# [claude-build] Cinematique « levier4 » : une image par tick (la camera), et ses evenements (sons, effets).
execute if score #t cine matches 1 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 47.045 -12.000 68.550 3.691 3.576
execute if score #t cine matches 2 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 47.045 -12.000 68.557 3.691 3.576
execute if score #t cine matches 3 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 47.043 -12.002 68.577 3.691 3.576
execute if score #t cine matches 4 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 47.041 -12.004 68.609 3.691 3.576
execute if score #t cine matches 5 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 47.038 -12.007 68.654 3.691 3.576
execute if score #t cine matches 6 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 47.035 -12.010 68.711 3.691 3.576
execute if score #t cine matches 7 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 47.030 -12.014 68.779 3.691 3.576
execute if score #t cine matches 8 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 47.025 -12.019 68.857 3.691 3.576
execute if score #t cine matches 9 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 47.020 -12.025 68.946 3.691 3.576
execute if score #t cine matches 10 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 47.013 -12.031 69.044 3.691 3.576
execute if score #t cine matches 11 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 47.006 -12.038 69.151 3.691 3.576
execute if score #t cine matches 12 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.999 -12.045 69.267 3.691 3.576
execute if score #t cine matches 13 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.991 -12.053 69.391 3.691 3.576
execute if score #t cine matches 14 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.982 -12.061 69.522 3.691 3.576
execute if score #t cine matches 15 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.974 -12.070 69.660 3.691 3.576
execute if score #t cine matches 16 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.964 -12.079 69.804 3.691 3.576
execute if score #t cine matches 17 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.955 -12.088 69.955 3.691 3.576
execute if score #t cine matches 18 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.945 -12.098 70.110 3.691 3.576
execute if score #t cine matches 19 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.934 -12.108 70.271 3.691 3.576
execute if score #t cine matches 20 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.924 -12.118 70.435 3.691 3.576
execute if score #t cine matches 21 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.913 -12.129 70.604 3.691 3.576
execute if score #t cine matches 22 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.902 -12.139 70.776 3.691 3.576
execute if score #t cine matches 23 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.890 -12.150 70.950 3.691 3.576
execute if score #t cine matches 24 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.879 -12.161 71.127 3.691 3.576
execute if score #t cine matches 25 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.867 -12.173 71.305 3.691 3.576
execute if score #t cine matches 26 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.856 -12.184 71.485 3.691 3.576
execute if score #t cine matches 27 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.844 -12.195 71.665 3.691 3.576
execute if score #t cine matches 28 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.833 -12.206 71.845 3.691 3.576
execute if score #t cine matches 29 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.821 -12.218 72.024 3.691 3.576
execute if score #t cine matches 30 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.809 -12.229 72.203 3.691 3.576
execute if score #t cine matches 31 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.798 -12.240 72.380 3.691 3.576
execute if score #t cine matches 32 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.787 -12.251 72.555 3.691 3.576
execute if score #t cine matches 33 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.776 -12.262 72.728 3.691 3.576
execute if score #t cine matches 34 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.765 -12.272 72.897 3.691 3.576
execute if score #t cine matches 35 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.754 -12.283 73.063 3.691 3.576
execute if score #t cine matches 36 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.744 -12.293 73.224 3.691 3.576
execute if score #t cine matches 37 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.733 -12.303 73.381 3.691 3.576
execute if score #t cine matches 38 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.724 -12.312 73.533 3.691 3.576
execute if score #t cine matches 39 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.714 -12.321 73.679 3.691 3.576
execute if score #t cine matches 40 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.705 -12.330 73.819 3.691 3.576
execute if score #t cine matches 41 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.696 -12.339 73.956 3.691 3.576
execute if score #t cine matches 42 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.687 -12.347 74.094 3.691 3.576
execute if score #t cine matches 43 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.678 -12.356 74.234 3.691 3.576
execute if score #t cine matches 44 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.669 -12.365 74.374 3.691 3.576
execute if score #t cine matches 45 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.660 -12.374 74.516 3.691 3.576
execute if score #t cine matches 46 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.651 -12.383 74.659 3.691 3.576
execute if score #t cine matches 47 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.642 -12.392 74.802 3.691 3.576
execute if score #t cine matches 48 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.633 -12.401 74.946 3.691 3.576
execute if score #t cine matches 49 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.623 -12.410 75.090 3.691 3.576
execute if score #t cine matches 50 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.614 -12.419 75.235 3.691 3.576
execute if score #t cine matches 51 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.604 -12.428 75.381 3.691 3.576
execute if score #t cine matches 52 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.595 -12.437 75.526 3.691 3.576
execute if score #t cine matches 53 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.586 -12.446 75.672 3.691 3.576
execute if score #t cine matches 54 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.576 -12.455 75.818 3.691 3.576
execute if score #t cine matches 55 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.567 -12.464 75.964 3.691 3.576
execute if score #t cine matches 56 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.557 -12.474 76.110 3.691 3.576
execute if score #t cine matches 57 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.548 -12.483 76.256 3.691 3.576
execute if score #t cine matches 58 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.539 -12.492 76.401 3.691 3.576
execute if score #t cine matches 59 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.529 -12.501 76.546 3.691 3.576
execute if score #t cine matches 60 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.520 -12.510 76.691 3.691 3.576
execute if score #t cine matches 61 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.511 -12.519 76.835 3.691 3.576
execute if score #t cine matches 62 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.501 -12.528 76.978 3.691 3.576
execute if score #t cine matches 63 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.492 -12.537 77.120 3.691 3.576
execute if score #t cine matches 64 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.483 -12.546 77.262 3.691 3.576
execute if score #t cine matches 65 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.474 -12.554 77.402 3.691 3.576
execute if score #t cine matches 66 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.465 -12.563 77.542 3.691 3.576
execute if score #t cine matches 67 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.456 -12.572 77.680 3.691 3.576
execute if score #t cine matches 68 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.447 -12.580 77.817 3.691 3.576
execute if score #t cine matches 69 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.439 -12.589 77.953 3.691 3.576
execute if score #t cine matches 70 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.430 -12.597 78.087 3.691 3.576
execute if score #t cine matches 71 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.421 -12.606 78.220 3.691 3.576
execute if score #t cine matches 72 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.413 -12.614 78.351 3.691 3.576
execute if score #t cine matches 73 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.404 -12.622 78.480 3.691 3.576
execute if score #t cine matches 74 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.396 -12.630 78.608 3.691 3.576
execute if score #t cine matches 75 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.388 -12.638 78.733 3.691 3.576
execute if score #t cine matches 76 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.380 -12.646 78.856 3.691 3.576
execute if score #t cine matches 77 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.372 -12.653 78.978 3.691 3.576
execute if score #t cine matches 78 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.365 -12.661 79.097 3.691 3.576
execute if score #t cine matches 79 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.357 -12.668 79.213 3.691 3.576
execute if score #t cine matches 80 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.350 -12.675 79.327 3.691 3.576
execute if score #t cine matches 81 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.343 -12.682 79.441 3.691 3.576
execute if score #t cine matches 82 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.335 -12.689 79.555 3.691 3.576
execute if score #t cine matches 83 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.328 -12.696 79.669 3.691 3.576
execute if score #t cine matches 84 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.320 -12.704 79.783 3.691 3.576
execute if score #t cine matches 85 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.313 -12.711 79.897 3.691 3.576
execute if score #t cine matches 86 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.306 -12.718 80.010 3.691 3.576
execute if score #t cine matches 87 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.299 -12.725 80.122 3.691 3.576
execute if score #t cine matches 88 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.291 -12.732 80.233 3.691 3.576
execute if score #t cine matches 89 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.284 -12.739 80.343 3.691 3.576
execute if score #t cine matches 90 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.277 -12.745 80.450 3.691 3.576
execute if score #t cine matches 91 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.271 -12.752 80.555 3.691 3.576
execute if score #t cine matches 92 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.264 -12.758 80.658 3.691 3.576
execute if score #t cine matches 93 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.258 -12.765 80.758 3.691 3.576
execute if score #t cine matches 94 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.251 -12.771 80.855 3.691 3.576
execute if score #t cine matches 95 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.245 -12.777 80.948 3.691 3.576
execute if score #t cine matches 96 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.239 -12.782 81.038 3.691 3.576
execute if score #t cine matches 97 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.234 -12.787 81.123 3.691 3.576
execute if score #t cine matches 98 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.229 -12.793 81.205 3.691 3.576
execute if score #t cine matches 99 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.224 -12.797 81.281 3.691 3.576
execute if score #t cine matches 100 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.219 -12.802 81.352 3.691 3.576
execute if score #t cine matches 101 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.215 -12.806 81.418 3.691 3.576
execute if score #t cine matches 102 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.211 -12.810 81.479 3.691 3.576
execute if score #t cine matches 103 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.208 -12.813 81.533 3.691 3.576
execute if score #t cine matches 104 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.204 -12.816 81.582 3.691 3.576
execute if score #t cine matches 105 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.202 -12.819 81.623 3.691 3.576
execute if score #t cine matches 106 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.199 -12.821 81.658 3.691 3.576
execute if score #t cine matches 107 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.198 -12.823 81.686 3.691 3.576
execute if score #t cine matches 108 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.196 -12.824 81.706 3.691 3.576
execute if score #t cine matches 109 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.196 -12.825 81.718 3.691 3.576
execute if score #t cine matches 110 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 46.195 -12.825 81.722 3.691 3.576
execute if score #t cine matches 2 run title @a[tag=cine] actionbar {"text":"…","color":"gray"}
execute if score #t cine matches 28 run setblock 45 -6 92 minecraft:chain[axis=y]
execute if score #t cine matches 28 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 30 run setblock 45 -7 92 minecraft:chain[axis=y]
execute if score #t cine matches 30 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 33 run setblock 45 -8 92 minecraft:chain[axis=y]
execute if score #t cine matches 33 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 36 run setblock 45 -9 92 minecraft:chain[axis=y]
execute if score #t cine matches 36 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 38 run setblock 45 -10 92 minecraft:chain[axis=y]
execute if score #t cine matches 38 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 41 run setblock 45 -11 92 minecraft:chain[axis=y]
execute if score #t cine matches 41 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 44 run setblock 45 -12 92 minecraft:chain[axis=y]
execute if score #t cine matches 44 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 46 run setblock 45 -13 92 minecraft:chain[axis=y]
execute if score #t cine matches 46 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 49 run setblock 45 -14 92 minecraft:chain[axis=y]
execute if score #t cine matches 49 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 56 run function atelier:suspendu_ss2_l4_a1
execute if score #t cine matches 56 run execute as @a[tag=cine] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1 1.4
execute if score #t cine matches 64 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.0
execute if score #t cine matches 68 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.26
execute if score #t cine matches 72 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
execute if score #t cine matches 72 run title @a[tag=cine] actionbar {"text":"Levier 4 : un point d'ancrage est apparu","color":"aqua"}
