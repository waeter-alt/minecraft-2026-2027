# [claude-build] Le bloc musical 4 est frappe : bon si c'est le suivant de la melodie, faux sinon. On teste une COPIE de la serie (#mp) : bon l'incremente, et les lignes suivantes ne doivent pas relire le nouveau score.
scoreboard players operation #mp suspendu = #mq suspendu
execute if score #mp suspendu matches 0 run function atelier:suspendu_mus_faux
execute if score #mp suspendu matches 1 run function atelier:suspendu_mus_bon
execute if score #mp suspendu matches 2 run function atelier:suspendu_mus_faux
execute if score #mp suspendu matches 3 run function atelier:suspendu_mus_faux
execute if score #mp suspendu matches 4 run function atelier:suspendu_mus_faux
