# [claude-build] Ouvre la porte 2 (jaune) : une cinematique montre la porte qui se leve (ou elle se leve tout de suite si une cinematique est en cours).
clear @s minecraft:tripwire_hook[minecraft:custom_name='"Clé jaune"'] 1
scoreboard players set #p2 suspendu 1
scoreboard players operation #libre cine = #t cine
execute if score #libre cine matches 0 run function atelier:suspendu_cine_debut_porte2
execute unless score #libre cine matches 0 run function atelier:suspendu_p2_lever
