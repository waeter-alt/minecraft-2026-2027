# [claude-build] Ouvre la porte 2 (jaune) avec sa cle : la cle est consommee et la dalle se leve tout de suite, sans cinematique.
clear @s minecraft:tripwire_hook[minecraft:custom_name='"Clé jaune"'] 1
scoreboard players set #p2 suspendu 1
function atelier:suspendu_p2_lever
