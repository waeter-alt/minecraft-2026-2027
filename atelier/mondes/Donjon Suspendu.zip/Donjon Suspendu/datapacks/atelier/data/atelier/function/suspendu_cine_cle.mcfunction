# [claude-build] Cinematique « cle » : une image par tick (la camera), et ses evenements (sons, effets).
execute if score #t cine matches 1 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 58.500 -11.500 106.500 -93.614 2.106
execute if score #t cine matches 2 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 58.509 -11.500 106.499 -93.614 2.106
execute if score #t cine matches 3 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 58.535 -11.501 106.498 -93.614 2.106
execute if score #t cine matches 4 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 58.578 -11.503 106.495 -93.614 2.106
execute if score #t cine matches 5 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 58.638 -11.505 106.491 -93.614 2.106
execute if score #t cine matches 6 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 58.715 -11.508 106.486 -93.614 2.106
execute if score #t cine matches 7 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 58.807 -11.511 106.481 -93.614 2.106
execute if score #t cine matches 8 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 58.915 -11.515 106.474 -93.614 2.106
execute if score #t cine matches 9 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 59.039 -11.520 106.466 -93.614 2.106
execute if score #t cine matches 10 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 59.177 -11.525 106.457 -93.614 2.106
execute if score #t cine matches 11 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 59.330 -11.531 106.448 -93.614 2.106
execute if score #t cine matches 12 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 59.498 -11.537 106.437 -93.614 2.106
execute if score #t cine matches 13 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 59.679 -11.543 106.426 -93.614 2.106
execute if score #t cine matches 14 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 59.874 -11.551 106.413 -93.614 2.106
execute if score #t cine matches 15 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 60.082 -11.558 106.400 -93.614 2.106
execute if score #t cine matches 16 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 60.303 -11.566 106.386 -93.614 2.106
execute if score #t cine matches 17 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 60.537 -11.575 106.371 -93.614 2.106
execute if score #t cine matches 18 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 60.783 -11.584 106.356 -93.614 2.106
execute if score #t cine matches 19 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 61.040 -11.594 106.340 -93.614 2.106
execute if score #t cine matches 20 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 61.309 -11.603 106.323 -93.614 2.106
execute if score #t cine matches 21 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 61.589 -11.614 106.305 -93.614 2.106
execute if score #t cine matches 22 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 61.881 -11.625 106.286 -93.614 2.106
execute if score #t cine matches 23 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 62.182 -11.636 106.267 -93.614 2.106
execute if score #t cine matches 24 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 62.494 -11.647 106.248 -93.614 2.106
execute if score #t cine matches 25 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 62.815 -11.659 106.227 -93.614 2.106
execute if score #t cine matches 26 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 63.146 -11.671 106.207 -93.614 2.106
execute if score #t cine matches 27 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 63.486 -11.684 106.185 -93.614 2.106
execute if score #t cine matches 28 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 63.834 -11.697 106.163 -93.614 2.106
execute if score #t cine matches 29 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 64.191 -11.710 106.141 -93.614 2.106
execute if score #t cine matches 30 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 64.556 -11.723 106.118 -93.614 2.106
execute if score #t cine matches 31 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 64.929 -11.737 106.094 -93.614 2.106
execute if score #t cine matches 32 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 65.308 -11.751 106.070 -93.614 2.106
execute if score #t cine matches 33 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 65.695 -11.765 106.046 -93.614 2.106
execute if score #t cine matches 34 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 66.089 -11.780 106.021 -93.614 2.106
execute if score #t cine matches 35 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 66.488 -11.794 105.995 -93.614 2.106
execute if score #t cine matches 36 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 66.894 -11.809 105.970 -93.614 2.106
execute if score #t cine matches 37 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 67.305 -11.824 105.944 -93.614 2.106
execute if score #t cine matches 38 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 67.722 -11.840 105.918 -93.614 2.106
execute if score #t cine matches 39 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 68.143 -11.855 105.891 -93.614 2.106
execute if score #t cine matches 40 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 68.569 -11.871 105.864 -93.614 2.106
execute if score #t cine matches 41 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 68.999 -11.887 105.837 -93.614 2.106
execute if score #t cine matches 42 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 69.433 -11.903 105.810 -93.614 2.106
execute if score #t cine matches 43 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 69.870 -11.919 105.782 -93.614 2.106
execute if score #t cine matches 44 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 70.311 -11.935 105.754 -93.614 2.106
execute if score #t cine matches 45 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 70.754 -11.951 105.726 -93.614 2.106
execute if score #t cine matches 46 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 71.200 -11.968 105.698 -93.614 2.106
execute if score #t cine matches 47 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 71.647 -11.984 105.670 -93.614 2.106
execute if score #t cine matches 48 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 72.097 -12.001 105.641 -93.614 2.106
execute if score #t cine matches 49 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 72.548 -12.018 105.613 -93.614 2.106
execute if score #t cine matches 50 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 73.000 -12.034 105.584 -93.614 2.106
execute if score #t cine matches 51 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 73.453 -12.051 105.556 -93.614 2.106
execute if score #t cine matches 52 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 73.905 -12.068 105.527 -93.614 2.106
execute if score #t cine matches 53 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 74.358 -12.084 105.498 -93.614 2.106
execute if score #t cine matches 54 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 74.811 -12.101 105.470 -93.614 2.106
execute if score #t cine matches 55 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.263 -12.118 105.441 -93.614 2.106
execute if score #t cine matches 56 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.714 -12.134 105.413 -93.614 2.106
execute if score #t cine matches 57 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 76.163 -12.151 105.384 -93.614 2.106
execute if score #t cine matches 58 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 76.611 -12.167 105.356 -93.614 2.106
execute if score #t cine matches 59 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.057 -12.184 105.328 -93.614 2.106
execute if score #t cine matches 60 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.500 -12.200 105.300 -93.614 2.106
execute if score #t cine matches 61 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.946 -12.216 105.272 -93.614 2.106
execute if score #t cine matches 62 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.400 -12.233 105.243 -93.614 2.106
execute if score #t cine matches 63 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.861 -12.250 105.214 -93.614 2.106
execute if score #t cine matches 64 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.330 -12.267 105.184 -93.614 2.106
execute if score #t cine matches 65 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.807 -12.285 105.154 -93.614 2.106
execute if score #t cine matches 66 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.290 -12.303 105.124 -93.614 2.106
execute if score #t cine matches 67 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.780 -12.321 105.093 -93.614 2.106
execute if score #t cine matches 68 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.277 -12.339 105.061 -93.614 2.106
execute if score #t cine matches 69 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.780 -12.358 105.030 -93.614 2.106
execute if score #t cine matches 70 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.289 -12.376 104.998 -93.614 2.106
execute if score #t cine matches 71 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.804 -12.395 104.965 -93.614 2.106
execute if score #t cine matches 72 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 83.325 -12.415 104.932 -93.614 2.106
execute if score #t cine matches 73 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 83.851 -12.434 104.899 -93.614 2.106
execute if score #t cine matches 74 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 84.383 -12.454 104.865 -93.614 2.106
execute if score #t cine matches 75 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 84.919 -12.473 104.831 -93.614 2.106
execute if score #t cine matches 76 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 85.460 -12.493 104.797 -93.614 2.106
execute if score #t cine matches 77 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 86.006 -12.513 104.763 -93.614 2.106
execute if score #t cine matches 78 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 86.556 -12.534 104.728 -93.614 2.106
execute if score #t cine matches 79 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 87.110 -12.554 104.693 -93.614 2.106
execute if score #t cine matches 80 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 87.668 -12.575 104.658 -93.614 2.106
execute if score #t cine matches 81 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 88.230 -12.595 104.622 -93.614 2.106
execute if score #t cine matches 82 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 88.795 -12.616 104.587 -93.614 2.106
execute if score #t cine matches 83 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 89.363 -12.637 104.551 -93.614 2.106
execute if score #t cine matches 84 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 89.934 -12.658 104.515 -93.614 2.106
execute if score #t cine matches 85 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 90.508 -12.679 104.478 -93.614 2.106
execute if score #t cine matches 86 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 91.085 -12.700 104.442 -93.614 2.106
execute if score #t cine matches 87 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 91.664 -12.722 104.405 -93.614 2.106
execute if score #t cine matches 88 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 92.244 -12.743 104.369 -93.614 2.106
execute if score #t cine matches 89 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 92.827 -12.765 104.332 -93.614 2.106
execute if score #t cine matches 90 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 93.411 -12.786 104.295 -93.614 2.106
execute if score #t cine matches 91 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 93.997 -12.808 104.258 -93.614 2.106
execute if score #t cine matches 92 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 94.584 -12.829 104.221 -93.614 2.106
execute if score #t cine matches 93 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 95.171 -12.851 104.184 -93.614 2.106
execute if score #t cine matches 94 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 95.760 -12.873 104.147 -93.614 2.106
execute if score #t cine matches 95 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 96.349 -12.894 104.110 -93.614 2.106
execute if score #t cine matches 96 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 96.938 -12.916 104.072 -93.614 2.106
execute if score #t cine matches 97 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 97.527 -12.938 104.035 -93.614 2.106
execute if score #t cine matches 98 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 98.116 -12.960 103.998 -93.614 2.106
execute if score #t cine matches 99 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 98.704 -12.981 103.961 -93.614 2.106
execute if score #t cine matches 100 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.292 -13.003 103.924 -93.614 2.106
execute if score #t cine matches 101 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 99.879 -13.024 103.887 -93.614 2.106
execute if score #t cine matches 102 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 100.465 -13.046 103.850 -93.614 2.106
execute if score #t cine matches 103 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 101.049 -13.068 103.813 -93.614 2.106
execute if score #t cine matches 104 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 101.632 -13.089 103.776 -93.614 2.106
execute if score #t cine matches 105 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 102.214 -13.110 103.739 -93.614 2.106
execute if score #t cine matches 106 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 102.793 -13.132 103.703 -93.614 2.106
execute if score #t cine matches 107 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 103.370 -13.153 103.666 -93.614 2.106
execute if score #t cine matches 108 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 103.944 -13.174 103.630 -93.614 2.106
execute if score #t cine matches 109 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.516 -13.195 103.594 -93.614 2.106
execute if score #t cine matches 110 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.085 -13.216 103.558 -93.614 2.106
execute if score #t cine matches 111 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.650 -13.237 103.522 -93.614 2.106
execute if score #t cine matches 112 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.213 -13.258 103.487 -93.614 2.106
execute if score #t cine matches 113 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.771 -13.278 103.451 -93.614 2.106
execute if score #t cine matches 114 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.326 -13.299 103.416 -93.614 2.106
execute if score #t cine matches 115 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.877 -13.319 103.381 -93.614 2.106
execute if score #t cine matches 116 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.424 -13.339 103.347 -93.614 2.106
execute if score #t cine matches 117 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.966 -13.359 103.313 -93.614 2.106
execute if score #t cine matches 118 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.503 -13.379 103.279 -93.614 2.106
execute if score #t cine matches 119 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 110.035 -13.399 103.245 -93.614 2.106
execute if score #t cine matches 120 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 110.563 -13.418 103.212 -93.614 2.106
execute if score #t cine matches 121 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 111.084 -13.437 103.179 -93.614 2.106
execute if score #t cine matches 122 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 111.601 -13.456 103.146 -93.614 2.106
execute if score #t cine matches 123 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 112.111 -13.475 103.114 -93.614 2.106
execute if score #t cine matches 124 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 112.615 -13.494 103.082 -93.614 2.106
execute if score #t cine matches 125 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 113.113 -13.512 103.051 -93.614 2.106
execute if score #t cine matches 126 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 113.604 -13.530 103.020 -93.614 2.106
execute if score #t cine matches 127 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 114.089 -13.548 102.989 -93.614 2.106
execute if score #t cine matches 128 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 114.567 -13.566 102.959 -93.614 2.106
execute if score #t cine matches 129 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 115.037 -13.583 102.929 -93.614 2.106
execute if score #t cine matches 130 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 115.500 -13.600 102.900 -93.614 2.106
execute if score #t cine matches 131 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 115.956 -13.617 102.871 -93.614 2.106
execute if score #t cine matches 132 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 116.405 -13.633 102.843 -93.614 2.106
execute if score #t cine matches 133 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 116.848 -13.650 102.815 -93.614 2.106
execute if score #t cine matches 134 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 117.285 -13.666 102.787 -93.614 2.106
execute if score #t cine matches 135 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 117.716 -13.682 102.760 -93.614 2.106
execute if score #t cine matches 136 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 118.140 -13.697 102.733 -93.614 2.106
execute if score #t cine matches 137 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 118.559 -13.713 102.707 -93.614 2.106
execute if score #t cine matches 138 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 118.971 -13.728 102.681 -93.614 2.106
execute if score #t cine matches 139 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 119.379 -13.743 102.655 -93.614 2.106
execute if score #t cine matches 140 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 119.780 -13.758 102.630 -93.614 2.106
execute if score #t cine matches 141 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 120.176 -13.772 102.605 -93.614 2.106
execute if score #t cine matches 142 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 120.567 -13.787 102.580 -93.614 2.106
execute if score #t cine matches 143 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 120.952 -13.801 102.556 -93.614 2.106
execute if score #t cine matches 144 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 121.333 -13.815 102.532 -93.614 2.106
execute if score #t cine matches 145 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 121.708 -13.829 102.508 -93.614 2.106
execute if score #t cine matches 146 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 122.079 -13.842 102.485 -93.614 2.106
execute if score #t cine matches 147 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 122.444 -13.856 102.461 -93.614 2.106
execute if score #t cine matches 148 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 122.805 -13.869 102.439 -93.614 2.106
execute if score #t cine matches 149 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 123.162 -13.882 102.416 -93.614 2.106
execute if score #t cine matches 150 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 123.514 -13.895 102.394 -93.614 2.106
execute if score #t cine matches 151 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 123.862 -13.908 102.372 -93.614 2.106
execute if score #t cine matches 152 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 124.206 -13.921 102.350 -93.614 2.106
execute if score #t cine matches 153 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 124.545 -13.933 102.329 -93.614 2.106
execute if score #t cine matches 154 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 124.881 -13.946 102.308 -93.614 2.106
execute if score #t cine matches 155 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 125.213 -13.958 102.287 -93.614 2.106
execute if score #t cine matches 156 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 125.541 -13.970 102.266 -93.614 2.106
execute if score #t cine matches 157 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 125.865 -13.982 102.245 -93.614 2.106
execute if score #t cine matches 158 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 126.186 -13.994 102.225 -93.614 2.106
execute if score #t cine matches 159 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 126.504 -14.005 102.205 -93.614 2.106
execute if score #t cine matches 160 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 126.818 -14.017 102.185 -93.614 2.106
execute if score #t cine matches 161 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 127.130 -14.028 102.166 -93.614 2.106
execute if score #t cine matches 162 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 127.438 -14.040 102.146 -93.614 2.106
execute if score #t cine matches 163 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 127.743 -14.051 102.127 -93.614 2.106
execute if score #t cine matches 164 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 128.045 -14.062 102.108 -93.614 2.106
execute if score #t cine matches 165 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 128.345 -14.073 102.089 -93.614 2.106
execute if score #t cine matches 166 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 128.643 -14.084 102.070 -93.614 2.106
execute if score #t cine matches 167 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 128.937 -14.095 102.051 -93.614 2.106
execute if score #t cine matches 168 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 129.230 -14.106 102.033 -93.614 2.106
execute if score #t cine matches 169 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 129.520 -14.117 102.015 -93.614 2.106
execute if score #t cine matches 170 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 129.808 -14.127 101.996 -93.614 2.106
execute if score #t cine matches 171 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 130.094 -14.138 101.978 -93.614 2.106
execute if score #t cine matches 172 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 130.379 -14.148 101.960 -93.614 2.106
execute if score #t cine matches 173 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 130.661 -14.159 101.942 -93.614 2.106
execute if score #t cine matches 174 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 130.942 -14.169 101.925 -93.614 2.106
execute if score #t cine matches 175 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 131.222 -14.179 101.907 -93.614 2.106
execute if score #t cine matches 176 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 131.500 -14.189 101.889 -93.614 2.106
execute if score #t cine matches 177 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 131.776 -14.200 101.872 -93.614 2.106
execute if score #t cine matches 178 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 132.052 -14.210 101.855 -93.614 2.106
execute if score #t cine matches 179 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 132.326 -14.220 101.837 -93.614 2.106
execute if score #t cine matches 180 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 132.600 -14.230 101.820 -93.614 2.106
execute if score #t cine matches 181 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 132.871 -14.240 101.803 -93.614 2.106
execute if score #t cine matches 182 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 133.136 -14.250 101.786 -93.614 2.106
execute if score #t cine matches 183 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 133.397 -14.259 101.770 -93.614 2.106
execute if score #t cine matches 184 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 133.651 -14.269 101.754 -93.614 2.106
execute if score #t cine matches 185 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 133.900 -14.278 101.738 -93.614 2.106
execute if score #t cine matches 186 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 134.143 -14.287 101.723 -93.614 2.106
execute if score #t cine matches 187 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 134.379 -14.296 101.708 -93.614 2.106
execute if score #t cine matches 188 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 134.608 -14.304 101.693 -93.614 2.106
execute if score #t cine matches 189 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 134.830 -14.312 101.679 -93.614 2.106
execute if score #t cine matches 190 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 135.045 -14.320 101.666 -93.614 2.106
execute if score #t cine matches 191 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 135.253 -14.328 101.652 -93.614 2.106
execute if score #t cine matches 192 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 135.452 -14.335 101.640 -93.614 2.106
execute if score #t cine matches 193 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 135.643 -14.342 101.628 -93.614 2.106
execute if score #t cine matches 194 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 135.825 -14.349 101.616 -93.614 2.106
execute if score #t cine matches 195 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 135.999 -14.355 101.605 -93.614 2.106
execute if score #t cine matches 196 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 136.164 -14.361 101.595 -93.614 2.106
execute if score #t cine matches 197 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 136.319 -14.367 101.585 -93.614 2.106
execute if score #t cine matches 198 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 136.465 -14.372 101.576 -93.614 2.106
execute if score #t cine matches 199 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 136.600 -14.377 101.567 -93.614 2.106
execute if score #t cine matches 200 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 136.725 -14.382 101.559 -93.614 2.106
execute if score #t cine matches 201 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 136.840 -14.386 101.552 -93.614 2.106
execute if score #t cine matches 202 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 136.944 -14.390 101.546 -93.614 2.106
execute if score #t cine matches 203 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 137.037 -14.393 101.540 -93.614 2.106
execute if score #t cine matches 204 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 137.118 -14.396 101.535 -93.614 2.106
execute if score #t cine matches 205 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 137.188 -14.399 101.530 -93.614 2.106
execute if score #t cine matches 206 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 137.245 -14.401 101.527 -93.614 2.106
execute if score #t cine matches 207 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 137.291 -14.403 101.524 -93.614 2.106
execute if score #t cine matches 208 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 137.323 -14.404 101.522 -93.614 2.106
execute if score #t cine matches 209 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 137.343 -14.405 101.520 -93.614 2.106
execute if score #t cine matches 210 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 137.350 -14.405 101.520 -93.614 2.106
execute if score #t cine matches 2 run title @a[tag=cine] actionbar {"text":"…","color":"gray"}
execute if score #t cine matches 8 run fill 74 -61 91 76 -61 91 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 73 -61 92 77 -61 92 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 73 -61 93 77 -61 93 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 73 -61 94 77 -61 94 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 74 -61 95 76 -61 95 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 74 -60 91 76 -60 91 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 73 -60 92 77 -60 92 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 73 -60 93 77 -60 93 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 73 -60 94 77 -60 94 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 74 -60 95 76 -60 95 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 74 -59 91 76 -59 91 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 73 -59 92 77 -59 92 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 73 -59 93 77 -59 93 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 73 -59 94 77 -59 94 minecraft:stone_bricks
execute if score #t cine matches 8 run fill 74 -59 95 76 -59 95 minecraft:stone_bricks
execute if score #t cine matches 8 run particle minecraft:campfire_cosy_smoke 75.500 -60.000 93.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 8 run particle minecraft:dust_plume 75.500 -60.000 93.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 8 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 8 run execute as @a[tag=cine] at @s run playsound minecraft:block.piston.extend master @s ~ ~ ~ 0.8 0.5
execute if score #t cine matches 9 run fill 74 -58 91 76 -58 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 9 run fill 73 -58 92 77 -58 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 9 run fill 73 -58 93 77 -58 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 9 run fill 73 -58 94 77 -58 94 minecraft:chiseled_stone_bricks
execute if score #t cine matches 9 run fill 74 -58 95 76 -58 95 minecraft:chiseled_stone_bricks
execute if score #t cine matches 9 run fill 74 -57 91 76 -57 91 minecraft:stone_bricks
execute if score #t cine matches 9 run fill 73 -57 92 77 -57 92 minecraft:stone_bricks
execute if score #t cine matches 9 run fill 73 -57 93 77 -57 93 minecraft:stone_bricks
execute if score #t cine matches 9 run fill 73 -57 94 77 -57 94 minecraft:stone_bricks
execute if score #t cine matches 9 run fill 74 -57 95 76 -57 95 minecraft:stone_bricks
execute if score #t cine matches 10 run fill 74 -56 91 76 -56 91 minecraft:stone_bricks
execute if score #t cine matches 10 run fill 73 -56 92 77 -56 92 minecraft:stone_bricks
execute if score #t cine matches 10 run fill 73 -56 93 77 -56 93 minecraft:stone_bricks
execute if score #t cine matches 10 run fill 73 -56 94 77 -56 94 minecraft:stone_bricks
execute if score #t cine matches 10 run fill 74 -56 95 76 -56 95 minecraft:stone_bricks
execute if score #t cine matches 10 run fill 74 -55 91 76 -55 91 minecraft:stone_bricks
execute if score #t cine matches 10 run fill 73 -55 92 77 -55 92 minecraft:stone_bricks
execute if score #t cine matches 10 run fill 73 -55 93 77 -55 93 minecraft:stone_bricks
execute if score #t cine matches 10 run fill 73 -55 94 77 -55 94 minecraft:stone_bricks
execute if score #t cine matches 10 run fill 74 -55 95 76 -55 95 minecraft:stone_bricks
execute if score #t cine matches 11 run fill 74 -54 91 76 -54 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 11 run fill 73 -54 92 77 -54 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 11 run fill 73 -54 93 77 -54 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 11 run fill 73 -54 94 77 -54 94 minecraft:chiseled_stone_bricks
execute if score #t cine matches 11 run fill 74 -54 95 76 -54 95 minecraft:chiseled_stone_bricks
execute if score #t cine matches 11 run fill 74 -53 91 76 -53 91 minecraft:stone_bricks
execute if score #t cine matches 11 run fill 73 -53 92 77 -53 92 minecraft:stone_bricks
execute if score #t cine matches 11 run fill 73 -53 93 77 -53 93 minecraft:stone_bricks
execute if score #t cine matches 11 run fill 73 -53 94 77 -53 94 minecraft:stone_bricks
execute if score #t cine matches 11 run fill 74 -53 95 76 -53 95 minecraft:stone_bricks
execute if score #t cine matches 11 run particle minecraft:campfire_cosy_smoke 75.500 -54.000 93.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 11 run particle minecraft:dust_plume 75.500 -54.000 93.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 12 run fill 74 -52 91 76 -52 91 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 73 -52 92 77 -52 92 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 73 -52 93 77 -52 93 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 73 -52 94 77 -52 94 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 74 -52 95 76 -52 95 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 74 -51 91 76 -51 91 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 73 -51 92 77 -51 92 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 73 -51 93 77 -51 93 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 73 -51 94 77 -51 94 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 74 -51 95 76 -51 95 minecraft:stone_bricks
execute if score #t cine matches 13 run fill 74 -50 91 76 -50 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 13 run fill 73 -50 92 77 -50 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 13 run fill 73 -50 93 77 -50 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 13 run fill 73 -50 94 77 -50 94 minecraft:chiseled_stone_bricks
execute if score #t cine matches 13 run fill 74 -50 95 76 -50 95 minecraft:chiseled_stone_bricks
execute if score #t cine matches 13 run fill 74 -49 91 76 -49 91 minecraft:stone_bricks
execute if score #t cine matches 13 run fill 73 -49 92 77 -49 92 minecraft:stone_bricks
execute if score #t cine matches 13 run fill 73 -49 93 77 -49 93 minecraft:stone_bricks
execute if score #t cine matches 13 run fill 73 -49 94 77 -49 94 minecraft:stone_bricks
execute if score #t cine matches 13 run fill 74 -49 95 76 -49 95 minecraft:stone_bricks
execute if score #t cine matches 14 run fill 74 -48 91 76 -48 91 minecraft:stone_bricks
execute if score #t cine matches 14 run fill 73 -48 92 77 -48 92 minecraft:stone_bricks
execute if score #t cine matches 14 run fill 73 -48 93 77 -48 93 minecraft:stone_bricks
execute if score #t cine matches 14 run fill 73 -48 94 77 -48 94 minecraft:stone_bricks
execute if score #t cine matches 14 run fill 74 -48 95 76 -48 95 minecraft:stone_bricks
execute if score #t cine matches 14 run fill 74 -47 91 76 -47 91 minecraft:stone_bricks
execute if score #t cine matches 14 run fill 73 -47 92 77 -47 92 minecraft:stone_bricks
execute if score #t cine matches 14 run fill 73 -47 93 77 -47 93 minecraft:stone_bricks
execute if score #t cine matches 14 run fill 73 -47 94 77 -47 94 minecraft:stone_bricks
execute if score #t cine matches 14 run fill 74 -47 95 76 -47 95 minecraft:stone_bricks
execute if score #t cine matches 14 run fill 74 -46 91 76 -46 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 14 run fill 73 -46 92 77 -46 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 14 run fill 73 -46 93 77 -46 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 14 run fill 73 -46 94 77 -46 94 minecraft:chiseled_stone_bricks
execute if score #t cine matches 14 run fill 74 -46 95 76 -46 95 minecraft:chiseled_stone_bricks
execute if score #t cine matches 14 run particle minecraft:campfire_cosy_smoke 75.500 -48.000 93.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 14 run particle minecraft:dust_plume 75.500 -48.000 93.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 14 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 15 run fill 74 -45 91 76 -45 91 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 73 -45 92 77 -45 92 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 73 -45 93 77 -45 93 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 73 -45 94 77 -45 94 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 74 -45 95 76 -45 95 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 74 -44 91 76 -44 91 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 73 -44 92 77 -44 92 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 73 -44 93 77 -44 93 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 73 -44 94 77 -44 94 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 74 -44 95 76 -44 95 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 74 -43 91 76 -43 91 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 73 -43 92 77 -43 92 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 73 -43 93 77 -43 93 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 73 -43 94 77 -43 94 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 74 -43 95 76 -43 95 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 74 -42 91 76 -42 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 16 run fill 73 -42 92 77 -42 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 16 run fill 73 -42 93 77 -42 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 16 run fill 73 -42 94 77 -42 94 minecraft:chiseled_stone_bricks
execute if score #t cine matches 16 run fill 74 -42 95 76 -42 95 minecraft:chiseled_stone_bricks
execute if score #t cine matches 17 run fill 74 -41 91 76 -41 91 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 73 -41 92 77 -41 92 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 73 -41 93 77 -41 93 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 73 -41 94 77 -41 94 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 74 -41 95 76 -41 95 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 74 -40 91 76 -40 91 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 73 -40 92 77 -40 92 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 73 -40 93 77 -40 93 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 73 -40 94 77 -40 94 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 74 -40 95 76 -40 95 minecraft:stone_bricks
execute if score #t cine matches 17 run particle minecraft:campfire_cosy_smoke 75.500 -41.000 93.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 17 run particle minecraft:dust_plume 75.500 -41.000 93.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 18 run fill 74 -39 91 76 -39 91 minecraft:stone_bricks
execute if score #t cine matches 18 run fill 73 -39 92 77 -39 92 minecraft:stone_bricks
execute if score #t cine matches 18 run fill 73 -39 93 77 -39 93 minecraft:stone_bricks
execute if score #t cine matches 18 run fill 73 -39 94 77 -39 94 minecraft:stone_bricks
execute if score #t cine matches 18 run fill 74 -39 95 76 -39 95 minecraft:stone_bricks
execute if score #t cine matches 18 run fill 74 -38 91 76 -38 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run fill 73 -38 92 77 -38 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run fill 73 -38 93 77 -38 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run fill 73 -38 94 77 -38 94 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run fill 74 -38 95 76 -38 95 minecraft:chiseled_stone_bricks
execute if score #t cine matches 19 run fill 74 -37 91 76 -37 91 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 73 -37 92 77 -37 92 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 73 -37 93 77 -37 93 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 73 -37 94 77 -37 94 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 74 -37 95 76 -37 95 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 74 -36 91 76 -36 91 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 73 -36 92 77 -36 92 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 73 -36 93 77 -36 93 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 73 -36 94 77 -36 94 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 74 -36 95 76 -36 95 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 74 -35 91 76 -35 91 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 73 -35 92 77 -35 92 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 73 -35 93 77 -35 93 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 73 -35 94 77 -35 94 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 74 -35 95 76 -35 95 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 74 -34 91 76 -34 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 20 run fill 73 -34 92 77 -34 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 20 run fill 73 -34 93 77 -34 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 20 run fill 73 -34 94 77 -34 94 minecraft:chiseled_stone_bricks
execute if score #t cine matches 20 run fill 74 -34 95 76 -34 95 minecraft:chiseled_stone_bricks
execute if score #t cine matches 20 run particle minecraft:campfire_cosy_smoke 75.500 -35.000 93.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 20 run particle minecraft:dust_plume 75.500 -35.000 93.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 20 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 21 run fill 74 -33 91 76 -33 91 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 73 -33 92 77 -33 92 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 73 -33 93 77 -33 93 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 73 -33 94 77 -33 94 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 74 -33 95 76 -33 95 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 74 -32 91 76 -32 91 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 73 -32 92 77 -32 92 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 73 -32 93 77 -32 93 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 73 -32 94 77 -32 94 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 74 -32 95 76 -32 95 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 74 -31 91 76 -31 91 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 73 -31 92 77 -31 92 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 73 -31 93 77 -31 93 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 73 -31 94 77 -31 94 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 74 -31 95 76 -31 95 minecraft:stone_bricks
execute if score #t cine matches 22 run fill 74 -30 91 76 -30 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 22 run fill 73 -30 92 77 -30 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 22 run fill 73 -30 93 77 -30 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 22 run fill 73 -30 94 77 -30 94 minecraft:chiseled_stone_bricks
execute if score #t cine matches 22 run fill 74 -30 95 76 -30 95 minecraft:chiseled_stone_bricks
execute if score #t cine matches 22 run fill 74 -29 91 76 -29 91 minecraft:stone_bricks
execute if score #t cine matches 22 run fill 73 -29 92 77 -29 92 minecraft:stone_bricks
execute if score #t cine matches 22 run fill 73 -29 93 77 -29 93 minecraft:stone_bricks
execute if score #t cine matches 22 run fill 73 -29 94 77 -29 94 minecraft:stone_bricks
execute if score #t cine matches 22 run fill 74 -29 95 76 -29 95 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 74 -28 91 76 -28 91 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 73 -28 92 77 -28 92 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 73 -28 93 77 -28 93 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 73 -28 94 77 -28 94 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 74 -28 95 76 -28 95 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 74 -27 91 76 -27 91 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 73 -27 92 77 -27 92 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 73 -27 93 77 -27 93 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 73 -27 94 77 -27 94 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 74 -27 95 76 -27 95 minecraft:stone_bricks
execute if score #t cine matches 23 run particle minecraft:campfire_cosy_smoke 75.500 -28.000 93.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 23 run particle minecraft:dust_plume 75.500 -28.000 93.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 24 run fill 74 -26 91 76 -26 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 24 run fill 73 -26 92 77 -26 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 24 run fill 73 -26 93 77 -26 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 24 run fill 73 -26 94 77 -26 94 minecraft:chiseled_stone_bricks
execute if score #t cine matches 24 run fill 74 -26 95 76 -26 95 minecraft:chiseled_stone_bricks
execute if score #t cine matches 24 run fill 74 -25 91 76 -25 91 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 73 -25 92 77 -25 92 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 73 -25 93 77 -25 93 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 73 -25 94 77 -25 94 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 74 -25 95 76 -25 95 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 74 -24 91 76 -24 91 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 73 -24 92 77 -24 92 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 73 -24 93 77 -24 93 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 73 -24 94 77 -24 94 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 74 -24 95 76 -24 95 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 74 -23 91 76 -23 91 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 73 -23 92 77 -23 92 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 73 -23 93 77 -23 93 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 73 -23 94 77 -23 94 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 74 -23 95 76 -23 95 minecraft:stone_bricks
execute if score #t cine matches 26 run fill 74 -22 91 76 -22 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 26 run fill 73 -22 92 77 -22 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 26 run fill 73 -22 93 77 -22 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 26 run fill 73 -22 94 77 -22 94 minecraft:chiseled_stone_bricks
execute if score #t cine matches 26 run fill 74 -22 95 76 -22 95 minecraft:chiseled_stone_bricks
execute if score #t cine matches 26 run fill 74 -21 91 76 -21 91 minecraft:stone_bricks
execute if score #t cine matches 26 run fill 73 -21 92 77 -21 92 minecraft:stone_bricks
execute if score #t cine matches 26 run fill 73 -21 93 77 -21 93 minecraft:stone_bricks
execute if score #t cine matches 26 run fill 73 -21 94 77 -21 94 minecraft:stone_bricks
execute if score #t cine matches 26 run fill 74 -21 95 76 -21 95 minecraft:stone_bricks
execute if score #t cine matches 26 run particle minecraft:campfire_cosy_smoke 75.500 -22.000 93.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 26 run particle minecraft:dust_plume 75.500 -22.000 93.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 26 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 27 run fill 74 -20 91 76 -20 91 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 73 -20 92 77 -20 92 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 73 -20 93 77 -20 93 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 73 -20 94 77 -20 94 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 74 -20 95 76 -20 95 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 74 -19 91 76 -19 91 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 73 -19 92 77 -19 92 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 73 -19 93 77 -19 93 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 73 -19 94 77 -19 94 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 74 -19 95 76 -19 95 minecraft:stone_bricks
execute if score #t cine matches 30 run function atelier:suspendu_ss2_l5_a1
execute if score #t cine matches 36 run fill 96 -61 89 98 -61 89 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 95 -61 90 99 -61 90 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 95 -61 91 99 -61 91 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 95 -61 92 99 -61 92 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 96 -61 93 98 -61 93 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 96 -60 89 98 -60 89 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 95 -60 90 99 -60 90 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 95 -60 91 99 -60 91 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 95 -60 92 99 -60 92 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 96 -60 93 98 -60 93 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 96 -59 89 98 -59 89 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 95 -59 90 99 -59 90 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 95 -59 91 99 -59 91 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 95 -59 92 99 -59 92 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 96 -59 93 98 -59 93 minecraft:stone_bricks
execute if score #t cine matches 36 run particle minecraft:campfire_cosy_smoke 97.500 -60.000 91.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 36 run particle minecraft:dust_plume 97.500 -60.000 91.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 36 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 36 run execute as @a[tag=cine] at @s run playsound minecraft:block.piston.extend master @s ~ ~ ~ 0.8 0.5
execute if score #t cine matches 37 run fill 96 -58 89 98 -58 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 37 run fill 95 -58 90 99 -58 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 37 run fill 95 -58 91 99 -58 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 37 run fill 95 -58 92 99 -58 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 37 run fill 96 -58 93 98 -58 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 37 run fill 96 -57 89 98 -57 89 minecraft:stone_bricks
execute if score #t cine matches 37 run fill 95 -57 90 99 -57 90 minecraft:stone_bricks
execute if score #t cine matches 37 run fill 95 -57 91 99 -57 91 minecraft:stone_bricks
execute if score #t cine matches 37 run fill 95 -57 92 99 -57 92 minecraft:stone_bricks
execute if score #t cine matches 37 run fill 96 -57 93 98 -57 93 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 96 -56 89 98 -56 89 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 95 -56 90 99 -56 90 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 95 -56 91 99 -56 91 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 95 -56 92 99 -56 92 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 96 -56 93 98 -56 93 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 96 -55 89 98 -55 89 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 95 -55 90 99 -55 90 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 95 -55 91 99 -55 91 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 95 -55 92 99 -55 92 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 96 -55 93 98 -55 93 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 96 -54 89 98 -54 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 39 run fill 95 -54 90 99 -54 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 39 run fill 95 -54 91 99 -54 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 39 run fill 95 -54 92 99 -54 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 39 run fill 96 -54 93 98 -54 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 39 run fill 96 -53 89 98 -53 89 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 95 -53 90 99 -53 90 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 95 -53 91 99 -53 91 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 95 -53 92 99 -53 92 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 96 -53 93 98 -53 93 minecraft:stone_bricks
execute if score #t cine matches 39 run particle minecraft:campfire_cosy_smoke 97.500 -54.000 91.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 39 run particle minecraft:dust_plume 97.500 -54.000 91.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 40 run fill 96 -52 89 98 -52 89 minecraft:stone_bricks
execute if score #t cine matches 40 run fill 95 -52 90 99 -52 90 minecraft:stone_bricks
execute if score #t cine matches 40 run fill 95 -52 91 99 -52 91 minecraft:stone_bricks
execute if score #t cine matches 40 run fill 95 -52 92 99 -52 92 minecraft:stone_bricks
execute if score #t cine matches 40 run fill 96 -52 93 98 -52 93 minecraft:stone_bricks
execute if score #t cine matches 40 run fill 96 -51 89 98 -51 89 minecraft:stone_bricks
execute if score #t cine matches 40 run fill 95 -51 90 99 -51 90 minecraft:stone_bricks
execute if score #t cine matches 40 run fill 95 -51 91 99 -51 91 minecraft:stone_bricks
execute if score #t cine matches 40 run fill 95 -51 92 99 -51 92 minecraft:stone_bricks
execute if score #t cine matches 40 run fill 96 -51 93 98 -51 93 minecraft:stone_bricks
execute if score #t cine matches 41 run fill 96 -50 89 98 -50 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 41 run fill 95 -50 90 99 -50 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 41 run fill 95 -50 91 99 -50 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 41 run fill 95 -50 92 99 -50 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 41 run fill 96 -50 93 98 -50 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 41 run fill 96 -49 89 98 -49 89 minecraft:stone_bricks
execute if score #t cine matches 41 run fill 95 -49 90 99 -49 90 minecraft:stone_bricks
execute if score #t cine matches 41 run fill 95 -49 91 99 -49 91 minecraft:stone_bricks
execute if score #t cine matches 41 run fill 95 -49 92 99 -49 92 minecraft:stone_bricks
execute if score #t cine matches 41 run fill 96 -49 93 98 -49 93 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 96 -48 89 98 -48 89 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 95 -48 90 99 -48 90 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 95 -48 91 99 -48 91 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 95 -48 92 99 -48 92 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 96 -48 93 98 -48 93 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 96 -47 89 98 -47 89 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 95 -47 90 99 -47 90 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 95 -47 91 99 -47 91 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 95 -47 92 99 -47 92 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 96 -47 93 98 -47 93 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 96 -46 89 98 -46 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 42 run fill 95 -46 90 99 -46 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 42 run fill 95 -46 91 99 -46 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 42 run fill 95 -46 92 99 -46 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 42 run fill 96 -46 93 98 -46 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 42 run particle minecraft:campfire_cosy_smoke 97.500 -48.000 91.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 42 run particle minecraft:dust_plume 97.500 -48.000 91.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 42 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 43 run fill 96 -45 89 98 -45 89 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 95 -45 90 99 -45 90 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 95 -45 91 99 -45 91 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 95 -45 92 99 -45 92 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 96 -45 93 98 -45 93 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 96 -44 89 98 -44 89 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 95 -44 90 99 -44 90 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 95 -44 91 99 -44 91 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 95 -44 92 99 -44 92 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 96 -44 93 98 -44 93 minecraft:stone_bricks
execute if score #t cine matches 44 run fill 96 -43 89 98 -43 89 minecraft:stone_bricks
execute if score #t cine matches 44 run fill 95 -43 90 99 -43 90 minecraft:stone_bricks
execute if score #t cine matches 44 run fill 95 -43 91 99 -43 91 minecraft:stone_bricks
execute if score #t cine matches 44 run fill 95 -43 92 99 -43 92 minecraft:stone_bricks
execute if score #t cine matches 44 run fill 96 -43 93 98 -43 93 minecraft:stone_bricks
execute if score #t cine matches 44 run fill 96 -42 89 98 -42 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run fill 95 -42 90 99 -42 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run fill 95 -42 91 99 -42 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run fill 95 -42 92 99 -42 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run fill 96 -42 93 98 -42 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 45 run fill 96 -41 89 98 -41 89 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 95 -41 90 99 -41 90 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 95 -41 91 99 -41 91 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 95 -41 92 99 -41 92 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 96 -41 93 98 -41 93 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 96 -40 89 98 -40 89 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 95 -40 90 99 -40 90 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 95 -40 91 99 -40 91 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 95 -40 92 99 -40 92 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 96 -40 93 98 -40 93 minecraft:stone_bricks
execute if score #t cine matches 45 run particle minecraft:campfire_cosy_smoke 97.500 -41.000 91.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 45 run particle minecraft:dust_plume 97.500 -41.000 91.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 46 run fill 96 -39 89 98 -39 89 minecraft:stone_bricks
execute if score #t cine matches 46 run fill 95 -39 90 99 -39 90 minecraft:stone_bricks
execute if score #t cine matches 46 run fill 95 -39 91 99 -39 91 minecraft:stone_bricks
execute if score #t cine matches 46 run fill 95 -39 92 99 -39 92 minecraft:stone_bricks
execute if score #t cine matches 46 run fill 96 -39 93 98 -39 93 minecraft:stone_bricks
execute if score #t cine matches 46 run fill 96 -38 89 98 -38 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 46 run fill 95 -38 90 99 -38 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 46 run fill 95 -38 91 99 -38 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 46 run fill 95 -38 92 99 -38 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 46 run fill 96 -38 93 98 -38 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 47 run fill 96 -37 89 98 -37 89 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 95 -37 90 99 -37 90 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 95 -37 91 99 -37 91 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 95 -37 92 99 -37 92 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 96 -37 93 98 -37 93 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 96 -36 89 98 -36 89 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 95 -36 90 99 -36 90 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 95 -36 91 99 -36 91 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 95 -36 92 99 -36 92 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 96 -36 93 98 -36 93 minecraft:stone_bricks
execute if score #t cine matches 48 run fill 96 -35 89 98 -35 89 minecraft:stone_bricks
execute if score #t cine matches 48 run fill 95 -35 90 99 -35 90 minecraft:stone_bricks
execute if score #t cine matches 48 run fill 95 -35 91 99 -35 91 minecraft:stone_bricks
execute if score #t cine matches 48 run fill 95 -35 92 99 -35 92 minecraft:stone_bricks
execute if score #t cine matches 48 run fill 96 -35 93 98 -35 93 minecraft:stone_bricks
execute if score #t cine matches 48 run fill 96 -34 89 98 -34 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run fill 95 -34 90 99 -34 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run fill 95 -34 91 99 -34 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run fill 95 -34 92 99 -34 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run fill 96 -34 93 98 -34 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run particle minecraft:campfire_cosy_smoke 97.500 -35.000 91.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 48 run particle minecraft:dust_plume 97.500 -35.000 91.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 48 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 49 run fill 96 -33 89 98 -33 89 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 95 -33 90 99 -33 90 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 95 -33 91 99 -33 91 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 95 -33 92 99 -33 92 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 96 -33 93 98 -33 93 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 96 -32 89 98 -32 89 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 95 -32 90 99 -32 90 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 95 -32 91 99 -32 91 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 95 -32 92 99 -32 92 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 96 -32 93 98 -32 93 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 96 -31 89 98 -31 89 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 95 -31 90 99 -31 90 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 95 -31 91 99 -31 91 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 95 -31 92 99 -31 92 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 96 -31 93 98 -31 93 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 96 -30 89 98 -30 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 50 run fill 95 -30 90 99 -30 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 50 run fill 95 -30 91 99 -30 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 50 run fill 95 -30 92 99 -30 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 50 run fill 96 -30 93 98 -30 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 50 run fill 96 -29 89 98 -29 89 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 95 -29 90 99 -29 90 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 95 -29 91 99 -29 91 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 95 -29 92 99 -29 92 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 96 -29 93 98 -29 93 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 96 -28 89 98 -28 89 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 95 -28 90 99 -28 90 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 95 -28 91 99 -28 91 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 95 -28 92 99 -28 92 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 96 -28 93 98 -28 93 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 96 -27 89 98 -27 89 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 95 -27 90 99 -27 90 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 95 -27 91 99 -27 91 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 95 -27 92 99 -27 92 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 96 -27 93 98 -27 93 minecraft:stone_bricks
execute if score #t cine matches 51 run particle minecraft:campfire_cosy_smoke 97.500 -28.000 91.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 51 run particle minecraft:dust_plume 97.500 -28.000 91.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 52 run fill 96 -26 89 98 -26 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 52 run fill 95 -26 90 99 -26 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 52 run fill 95 -26 91 99 -26 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 52 run fill 95 -26 92 99 -26 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 52 run fill 96 -26 93 98 -26 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 52 run fill 96 -25 89 98 -25 89 minecraft:stone_bricks
execute if score #t cine matches 52 run fill 95 -25 90 99 -25 90 minecraft:stone_bricks
execute if score #t cine matches 52 run fill 95 -25 91 99 -25 91 minecraft:stone_bricks
execute if score #t cine matches 52 run fill 95 -25 92 99 -25 92 minecraft:stone_bricks
execute if score #t cine matches 52 run fill 96 -25 93 98 -25 93 minecraft:stone_bricks
execute if score #t cine matches 53 run fill 96 -24 89 98 -24 89 minecraft:stone_bricks
execute if score #t cine matches 53 run fill 95 -24 90 99 -24 90 minecraft:stone_bricks
execute if score #t cine matches 53 run fill 95 -24 91 99 -24 91 minecraft:stone_bricks
execute if score #t cine matches 53 run fill 95 -24 92 99 -24 92 minecraft:stone_bricks
execute if score #t cine matches 53 run fill 96 -24 93 98 -24 93 minecraft:stone_bricks
execute if score #t cine matches 53 run fill 96 -23 89 98 -23 89 minecraft:stone_bricks
execute if score #t cine matches 53 run fill 95 -23 90 99 -23 90 minecraft:stone_bricks
execute if score #t cine matches 53 run fill 95 -23 91 99 -23 91 minecraft:stone_bricks
execute if score #t cine matches 53 run fill 95 -23 92 99 -23 92 minecraft:stone_bricks
execute if score #t cine matches 53 run fill 96 -23 93 98 -23 93 minecraft:stone_bricks
execute if score #t cine matches 54 run fill 96 -22 89 98 -22 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 54 run fill 95 -22 90 99 -22 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 54 run fill 95 -22 91 99 -22 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 54 run fill 95 -22 92 99 -22 92 minecraft:chiseled_stone_bricks
execute if score #t cine matches 54 run fill 96 -22 93 98 -22 93 minecraft:chiseled_stone_bricks
execute if score #t cine matches 54 run fill 96 -21 89 98 -21 89 minecraft:stone_bricks
execute if score #t cine matches 54 run fill 95 -21 90 99 -21 90 minecraft:stone_bricks
execute if score #t cine matches 54 run fill 95 -21 91 99 -21 91 minecraft:stone_bricks
execute if score #t cine matches 54 run fill 95 -21 92 99 -21 92 minecraft:stone_bricks
execute if score #t cine matches 54 run fill 96 -21 93 98 -21 93 minecraft:stone_bricks
execute if score #t cine matches 54 run particle minecraft:campfire_cosy_smoke 97.500 -22.000 91.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 54 run particle minecraft:dust_plume 97.500 -22.000 91.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 54 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 55 run fill 96 -20 89 98 -20 89 minecraft:stone_bricks
execute if score #t cine matches 55 run fill 95 -20 90 99 -20 90 minecraft:stone_bricks
execute if score #t cine matches 55 run fill 95 -20 91 99 -20 91 minecraft:stone_bricks
execute if score #t cine matches 55 run fill 95 -20 92 99 -20 92 minecraft:stone_bricks
execute if score #t cine matches 55 run fill 96 -20 93 98 -20 93 minecraft:stone_bricks
execute if score #t cine matches 55 run fill 96 -19 89 98 -19 89 minecraft:stone_bricks
execute if score #t cine matches 55 run fill 95 -19 90 99 -19 90 minecraft:stone_bricks
execute if score #t cine matches 55 run fill 95 -19 91 99 -19 91 minecraft:stone_bricks
execute if score #t cine matches 55 run fill 95 -19 92 99 -19 92 minecraft:stone_bricks
execute if score #t cine matches 55 run fill 96 -19 93 98 -19 93 minecraft:stone_bricks
execute if score #t cine matches 58 run function atelier:suspendu_ss2_l5_a2
execute if score #t cine matches 64 run fill 118 -61 87 120 -61 87 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 117 -61 88 121 -61 88 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 117 -61 89 121 -61 89 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 117 -61 90 121 -61 90 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 118 -61 91 120 -61 91 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 118 -60 87 120 -60 87 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 117 -60 88 121 -60 88 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 117 -60 89 121 -60 89 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 117 -60 90 121 -60 90 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 118 -60 91 120 -60 91 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 118 -59 87 120 -59 87 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 117 -59 88 121 -59 88 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 117 -59 89 121 -59 89 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 117 -59 90 121 -59 90 minecraft:stone_bricks
execute if score #t cine matches 64 run fill 118 -59 91 120 -59 91 minecraft:stone_bricks
execute if score #t cine matches 64 run particle minecraft:campfire_cosy_smoke 119.500 -60.000 89.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 64 run particle minecraft:dust_plume 119.500 -60.000 89.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 64 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 64 run execute as @a[tag=cine] at @s run playsound minecraft:block.piston.extend master @s ~ ~ ~ 0.8 0.5
execute if score #t cine matches 65 run fill 118 -58 87 120 -58 87 minecraft:chiseled_stone_bricks
execute if score #t cine matches 65 run fill 117 -58 88 121 -58 88 minecraft:chiseled_stone_bricks
execute if score #t cine matches 65 run fill 117 -58 89 121 -58 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 65 run fill 117 -58 90 121 -58 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 65 run fill 118 -58 91 120 -58 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 65 run fill 118 -57 87 120 -57 87 minecraft:stone_bricks
execute if score #t cine matches 65 run fill 117 -57 88 121 -57 88 minecraft:stone_bricks
execute if score #t cine matches 65 run fill 117 -57 89 121 -57 89 minecraft:stone_bricks
execute if score #t cine matches 65 run fill 117 -57 90 121 -57 90 minecraft:stone_bricks
execute if score #t cine matches 65 run fill 118 -57 91 120 -57 91 minecraft:stone_bricks
execute if score #t cine matches 66 run fill 118 -56 87 120 -56 87 minecraft:stone_bricks
execute if score #t cine matches 66 run fill 117 -56 88 121 -56 88 minecraft:stone_bricks
execute if score #t cine matches 66 run fill 117 -56 89 121 -56 89 minecraft:stone_bricks
execute if score #t cine matches 66 run fill 117 -56 90 121 -56 90 minecraft:stone_bricks
execute if score #t cine matches 66 run fill 118 -56 91 120 -56 91 minecraft:stone_bricks
execute if score #t cine matches 66 run fill 118 -55 87 120 -55 87 minecraft:stone_bricks
execute if score #t cine matches 66 run fill 117 -55 88 121 -55 88 minecraft:stone_bricks
execute if score #t cine matches 66 run fill 117 -55 89 121 -55 89 minecraft:stone_bricks
execute if score #t cine matches 66 run fill 117 -55 90 121 -55 90 minecraft:stone_bricks
execute if score #t cine matches 66 run fill 118 -55 91 120 -55 91 minecraft:stone_bricks
execute if score #t cine matches 67 run fill 118 -54 87 120 -54 87 minecraft:chiseled_stone_bricks
execute if score #t cine matches 67 run fill 117 -54 88 121 -54 88 minecraft:chiseled_stone_bricks
execute if score #t cine matches 67 run fill 117 -54 89 121 -54 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 67 run fill 117 -54 90 121 -54 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 67 run fill 118 -54 91 120 -54 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 67 run fill 118 -53 87 120 -53 87 minecraft:stone_bricks
execute if score #t cine matches 67 run fill 117 -53 88 121 -53 88 minecraft:stone_bricks
execute if score #t cine matches 67 run fill 117 -53 89 121 -53 89 minecraft:stone_bricks
execute if score #t cine matches 67 run fill 117 -53 90 121 -53 90 minecraft:stone_bricks
execute if score #t cine matches 67 run fill 118 -53 91 120 -53 91 minecraft:stone_bricks
execute if score #t cine matches 67 run particle minecraft:campfire_cosy_smoke 119.500 -54.000 89.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 67 run particle minecraft:dust_plume 119.500 -54.000 89.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 68 run fill 118 -52 87 120 -52 87 minecraft:stone_bricks
execute if score #t cine matches 68 run fill 117 -52 88 121 -52 88 minecraft:stone_bricks
execute if score #t cine matches 68 run fill 117 -52 89 121 -52 89 minecraft:stone_bricks
execute if score #t cine matches 68 run fill 117 -52 90 121 -52 90 minecraft:stone_bricks
execute if score #t cine matches 68 run fill 118 -52 91 120 -52 91 minecraft:stone_bricks
execute if score #t cine matches 68 run fill 118 -51 87 120 -51 87 minecraft:stone_bricks
execute if score #t cine matches 68 run fill 117 -51 88 121 -51 88 minecraft:stone_bricks
execute if score #t cine matches 68 run fill 117 -51 89 121 -51 89 minecraft:stone_bricks
execute if score #t cine matches 68 run fill 117 -51 90 121 -51 90 minecraft:stone_bricks
execute if score #t cine matches 68 run fill 118 -51 91 120 -51 91 minecraft:stone_bricks
execute if score #t cine matches 69 run fill 118 -50 87 120 -50 87 minecraft:chiseled_stone_bricks
execute if score #t cine matches 69 run fill 117 -50 88 121 -50 88 minecraft:chiseled_stone_bricks
execute if score #t cine matches 69 run fill 117 -50 89 121 -50 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 69 run fill 117 -50 90 121 -50 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 69 run fill 118 -50 91 120 -50 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 69 run fill 118 -49 87 120 -49 87 minecraft:stone_bricks
execute if score #t cine matches 69 run fill 117 -49 88 121 -49 88 minecraft:stone_bricks
execute if score #t cine matches 69 run fill 117 -49 89 121 -49 89 minecraft:stone_bricks
execute if score #t cine matches 69 run fill 117 -49 90 121 -49 90 minecraft:stone_bricks
execute if score #t cine matches 69 run fill 118 -49 91 120 -49 91 minecraft:stone_bricks
execute if score #t cine matches 70 run fill 118 -48 87 120 -48 87 minecraft:stone_bricks
execute if score #t cine matches 70 run fill 117 -48 88 121 -48 88 minecraft:stone_bricks
execute if score #t cine matches 70 run fill 117 -48 89 121 -48 89 minecraft:stone_bricks
execute if score #t cine matches 70 run fill 117 -48 90 121 -48 90 minecraft:stone_bricks
execute if score #t cine matches 70 run fill 118 -48 91 120 -48 91 minecraft:stone_bricks
execute if score #t cine matches 70 run fill 118 -47 87 120 -47 87 minecraft:stone_bricks
execute if score #t cine matches 70 run fill 117 -47 88 121 -47 88 minecraft:stone_bricks
execute if score #t cine matches 70 run fill 117 -47 89 121 -47 89 minecraft:stone_bricks
execute if score #t cine matches 70 run fill 117 -47 90 121 -47 90 minecraft:stone_bricks
execute if score #t cine matches 70 run fill 118 -47 91 120 -47 91 minecraft:stone_bricks
execute if score #t cine matches 70 run fill 118 -46 87 120 -46 87 minecraft:chiseled_stone_bricks
execute if score #t cine matches 70 run fill 117 -46 88 121 -46 88 minecraft:chiseled_stone_bricks
execute if score #t cine matches 70 run fill 117 -46 89 121 -46 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 70 run fill 117 -46 90 121 -46 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 70 run fill 118 -46 91 120 -46 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 70 run particle minecraft:campfire_cosy_smoke 119.500 -48.000 89.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 70 run particle minecraft:dust_plume 119.500 -48.000 89.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 70 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 71 run fill 118 -45 87 120 -45 87 minecraft:stone_bricks
execute if score #t cine matches 71 run fill 117 -45 88 121 -45 88 minecraft:stone_bricks
execute if score #t cine matches 71 run fill 117 -45 89 121 -45 89 minecraft:stone_bricks
execute if score #t cine matches 71 run fill 117 -45 90 121 -45 90 minecraft:stone_bricks
execute if score #t cine matches 71 run fill 118 -45 91 120 -45 91 minecraft:stone_bricks
execute if score #t cine matches 71 run fill 118 -44 87 120 -44 87 minecraft:stone_bricks
execute if score #t cine matches 71 run fill 117 -44 88 121 -44 88 minecraft:stone_bricks
execute if score #t cine matches 71 run fill 117 -44 89 121 -44 89 minecraft:stone_bricks
execute if score #t cine matches 71 run fill 117 -44 90 121 -44 90 minecraft:stone_bricks
execute if score #t cine matches 71 run fill 118 -44 91 120 -44 91 minecraft:stone_bricks
execute if score #t cine matches 72 run fill 118 -43 87 120 -43 87 minecraft:stone_bricks
execute if score #t cine matches 72 run fill 117 -43 88 121 -43 88 minecraft:stone_bricks
execute if score #t cine matches 72 run fill 117 -43 89 121 -43 89 minecraft:stone_bricks
execute if score #t cine matches 72 run fill 117 -43 90 121 -43 90 minecraft:stone_bricks
execute if score #t cine matches 72 run fill 118 -43 91 120 -43 91 minecraft:stone_bricks
execute if score #t cine matches 72 run fill 118 -42 87 120 -42 87 minecraft:chiseled_stone_bricks
execute if score #t cine matches 72 run fill 117 -42 88 121 -42 88 minecraft:chiseled_stone_bricks
execute if score #t cine matches 72 run fill 117 -42 89 121 -42 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 72 run fill 117 -42 90 121 -42 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 72 run fill 118 -42 91 120 -42 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 73 run fill 118 -41 87 120 -41 87 minecraft:stone_bricks
execute if score #t cine matches 73 run fill 117 -41 88 121 -41 88 minecraft:stone_bricks
execute if score #t cine matches 73 run fill 117 -41 89 121 -41 89 minecraft:stone_bricks
execute if score #t cine matches 73 run fill 117 -41 90 121 -41 90 minecraft:stone_bricks
execute if score #t cine matches 73 run fill 118 -41 91 120 -41 91 minecraft:stone_bricks
execute if score #t cine matches 73 run fill 118 -40 87 120 -40 87 minecraft:stone_bricks
execute if score #t cine matches 73 run fill 117 -40 88 121 -40 88 minecraft:stone_bricks
execute if score #t cine matches 73 run fill 117 -40 89 121 -40 89 minecraft:stone_bricks
execute if score #t cine matches 73 run fill 117 -40 90 121 -40 90 minecraft:stone_bricks
execute if score #t cine matches 73 run fill 118 -40 91 120 -40 91 minecraft:stone_bricks
execute if score #t cine matches 73 run particle minecraft:campfire_cosy_smoke 119.500 -41.000 89.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 73 run particle minecraft:dust_plume 119.500 -41.000 89.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 74 run fill 118 -39 87 120 -39 87 minecraft:stone_bricks
execute if score #t cine matches 74 run fill 117 -39 88 121 -39 88 minecraft:stone_bricks
execute if score #t cine matches 74 run fill 117 -39 89 121 -39 89 minecraft:stone_bricks
execute if score #t cine matches 74 run fill 117 -39 90 121 -39 90 minecraft:stone_bricks
execute if score #t cine matches 74 run fill 118 -39 91 120 -39 91 minecraft:stone_bricks
execute if score #t cine matches 74 run fill 118 -38 87 120 -38 87 minecraft:chiseled_stone_bricks
execute if score #t cine matches 74 run fill 117 -38 88 121 -38 88 minecraft:chiseled_stone_bricks
execute if score #t cine matches 74 run fill 117 -38 89 121 -38 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 74 run fill 117 -38 90 121 -38 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 74 run fill 118 -38 91 120 -38 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 75 run fill 118 -37 87 120 -37 87 minecraft:stone_bricks
execute if score #t cine matches 75 run fill 117 -37 88 121 -37 88 minecraft:stone_bricks
execute if score #t cine matches 75 run fill 117 -37 89 121 -37 89 minecraft:stone_bricks
execute if score #t cine matches 75 run fill 117 -37 90 121 -37 90 minecraft:stone_bricks
execute if score #t cine matches 75 run fill 118 -37 91 120 -37 91 minecraft:stone_bricks
execute if score #t cine matches 75 run fill 118 -36 87 120 -36 87 minecraft:stone_bricks
execute if score #t cine matches 75 run fill 117 -36 88 121 -36 88 minecraft:stone_bricks
execute if score #t cine matches 75 run fill 117 -36 89 121 -36 89 minecraft:stone_bricks
execute if score #t cine matches 75 run fill 117 -36 90 121 -36 90 minecraft:stone_bricks
execute if score #t cine matches 75 run fill 118 -36 91 120 -36 91 minecraft:stone_bricks
execute if score #t cine matches 76 run fill 118 -35 87 120 -35 87 minecraft:stone_bricks
execute if score #t cine matches 76 run fill 117 -35 88 121 -35 88 minecraft:stone_bricks
execute if score #t cine matches 76 run fill 117 -35 89 121 -35 89 minecraft:stone_bricks
execute if score #t cine matches 76 run fill 117 -35 90 121 -35 90 minecraft:stone_bricks
execute if score #t cine matches 76 run fill 118 -35 91 120 -35 91 minecraft:stone_bricks
execute if score #t cine matches 76 run fill 118 -34 87 120 -34 87 minecraft:chiseled_stone_bricks
execute if score #t cine matches 76 run fill 117 -34 88 121 -34 88 minecraft:chiseled_stone_bricks
execute if score #t cine matches 76 run fill 117 -34 89 121 -34 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 76 run fill 117 -34 90 121 -34 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 76 run fill 118 -34 91 120 -34 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 76 run particle minecraft:campfire_cosy_smoke 119.500 -35.000 89.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 76 run particle minecraft:dust_plume 119.500 -35.000 89.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 76 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 77 run fill 118 -33 87 120 -33 87 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 117 -33 88 121 -33 88 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 117 -33 89 121 -33 89 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 117 -33 90 121 -33 90 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 118 -33 91 120 -33 91 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 118 -32 87 120 -32 87 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 117 -32 88 121 -32 88 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 117 -32 89 121 -32 89 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 117 -32 90 121 -32 90 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 118 -32 91 120 -32 91 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 118 -31 87 120 -31 87 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 117 -31 88 121 -31 88 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 117 -31 89 121 -31 89 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 117 -31 90 121 -31 90 minecraft:stone_bricks
execute if score #t cine matches 77 run fill 118 -31 91 120 -31 91 minecraft:stone_bricks
execute if score #t cine matches 78 run fill 118 -30 87 120 -30 87 minecraft:chiseled_stone_bricks
execute if score #t cine matches 78 run fill 117 -30 88 121 -30 88 minecraft:chiseled_stone_bricks
execute if score #t cine matches 78 run fill 117 -30 89 121 -30 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 78 run fill 117 -30 90 121 -30 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 78 run fill 118 -30 91 120 -30 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 78 run fill 118 -29 87 120 -29 87 minecraft:stone_bricks
execute if score #t cine matches 78 run fill 117 -29 88 121 -29 88 minecraft:stone_bricks
execute if score #t cine matches 78 run fill 117 -29 89 121 -29 89 minecraft:stone_bricks
execute if score #t cine matches 78 run fill 117 -29 90 121 -29 90 minecraft:stone_bricks
execute if score #t cine matches 78 run fill 118 -29 91 120 -29 91 minecraft:stone_bricks
execute if score #t cine matches 79 run fill 118 -28 87 120 -28 87 minecraft:stone_bricks
execute if score #t cine matches 79 run fill 117 -28 88 121 -28 88 minecraft:stone_bricks
execute if score #t cine matches 79 run fill 117 -28 89 121 -28 89 minecraft:stone_bricks
execute if score #t cine matches 79 run fill 117 -28 90 121 -28 90 minecraft:stone_bricks
execute if score #t cine matches 79 run fill 118 -28 91 120 -28 91 minecraft:stone_bricks
execute if score #t cine matches 79 run fill 118 -27 87 120 -27 87 minecraft:stone_bricks
execute if score #t cine matches 79 run fill 117 -27 88 121 -27 88 minecraft:stone_bricks
execute if score #t cine matches 79 run fill 117 -27 89 121 -27 89 minecraft:stone_bricks
execute if score #t cine matches 79 run fill 117 -27 90 121 -27 90 minecraft:stone_bricks
execute if score #t cine matches 79 run fill 118 -27 91 120 -27 91 minecraft:stone_bricks
execute if score #t cine matches 79 run particle minecraft:campfire_cosy_smoke 119.500 -28.000 89.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 79 run particle minecraft:dust_plume 119.500 -28.000 89.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 80 run fill 118 -26 87 120 -26 87 minecraft:chiseled_stone_bricks
execute if score #t cine matches 80 run fill 117 -26 88 121 -26 88 minecraft:chiseled_stone_bricks
execute if score #t cine matches 80 run fill 117 -26 89 121 -26 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 80 run fill 117 -26 90 121 -26 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 80 run fill 118 -26 91 120 -26 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 80 run fill 118 -25 87 120 -25 87 minecraft:stone_bricks
execute if score #t cine matches 80 run fill 117 -25 88 121 -25 88 minecraft:stone_bricks
execute if score #t cine matches 80 run fill 117 -25 89 121 -25 89 minecraft:stone_bricks
execute if score #t cine matches 80 run fill 117 -25 90 121 -25 90 minecraft:stone_bricks
execute if score #t cine matches 80 run fill 118 -25 91 120 -25 91 minecraft:stone_bricks
execute if score #t cine matches 81 run fill 118 -24 87 120 -24 87 minecraft:stone_bricks
execute if score #t cine matches 81 run fill 117 -24 88 121 -24 88 minecraft:stone_bricks
execute if score #t cine matches 81 run fill 117 -24 89 121 -24 89 minecraft:stone_bricks
execute if score #t cine matches 81 run fill 117 -24 90 121 -24 90 minecraft:stone_bricks
execute if score #t cine matches 81 run fill 118 -24 91 120 -24 91 minecraft:stone_bricks
execute if score #t cine matches 81 run fill 118 -23 87 120 -23 87 minecraft:stone_bricks
execute if score #t cine matches 81 run fill 117 -23 88 121 -23 88 minecraft:stone_bricks
execute if score #t cine matches 81 run fill 117 -23 89 121 -23 89 minecraft:stone_bricks
execute if score #t cine matches 81 run fill 117 -23 90 121 -23 90 minecraft:stone_bricks
execute if score #t cine matches 81 run fill 118 -23 91 120 -23 91 minecraft:stone_bricks
execute if score #t cine matches 82 run fill 118 -22 87 120 -22 87 minecraft:chiseled_stone_bricks
execute if score #t cine matches 82 run fill 117 -22 88 121 -22 88 minecraft:chiseled_stone_bricks
execute if score #t cine matches 82 run fill 117 -22 89 121 -22 89 minecraft:chiseled_stone_bricks
execute if score #t cine matches 82 run fill 117 -22 90 121 -22 90 minecraft:chiseled_stone_bricks
execute if score #t cine matches 82 run fill 118 -22 91 120 -22 91 minecraft:chiseled_stone_bricks
execute if score #t cine matches 82 run fill 118 -21 87 120 -21 87 minecraft:stone_bricks
execute if score #t cine matches 82 run fill 117 -21 88 121 -21 88 minecraft:stone_bricks
execute if score #t cine matches 82 run fill 117 -21 89 121 -21 89 minecraft:stone_bricks
execute if score #t cine matches 82 run fill 117 -21 90 121 -21 90 minecraft:stone_bricks
execute if score #t cine matches 82 run fill 118 -21 91 120 -21 91 minecraft:stone_bricks
execute if score #t cine matches 82 run particle minecraft:campfire_cosy_smoke 119.500 -22.000 89.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 82 run particle minecraft:dust_plume 119.500 -22.000 89.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 82 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 83 run fill 118 -20 87 120 -20 87 minecraft:stone_bricks
execute if score #t cine matches 83 run fill 117 -20 88 121 -20 88 minecraft:stone_bricks
execute if score #t cine matches 83 run fill 117 -20 89 121 -20 89 minecraft:stone_bricks
execute if score #t cine matches 83 run fill 117 -20 90 121 -20 90 minecraft:stone_bricks
execute if score #t cine matches 83 run fill 118 -20 91 120 -20 91 minecraft:stone_bricks
execute if score #t cine matches 83 run fill 118 -19 87 120 -19 87 minecraft:stone_bricks
execute if score #t cine matches 83 run fill 117 -19 88 121 -19 88 minecraft:stone_bricks
execute if score #t cine matches 83 run fill 117 -19 89 121 -19 89 minecraft:stone_bricks
execute if score #t cine matches 83 run fill 117 -19 90 121 -19 90 minecraft:stone_bricks
execute if score #t cine matches 83 run fill 118 -19 91 120 -19 91 minecraft:stone_bricks
execute if score #t cine matches 86 run function atelier:suspendu_ss2_l5_a3
execute if score #t cine matches 96 run setblock 141 -6 86 minecraft:chain[axis=y]
execute if score #t cine matches 96 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 97 run setblock 141 -7 86 minecraft:chain[axis=y]
execute if score #t cine matches 97 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 99 run setblock 141 -8 86 minecraft:chain[axis=y]
execute if score #t cine matches 99 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 101 run setblock 141 -9 86 minecraft:chain[axis=y]
execute if score #t cine matches 101 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 103 run setblock 141 -10 86 minecraft:chain[axis=y]
execute if score #t cine matches 103 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 104 run setblock 141 -11 86 minecraft:chain[axis=y]
execute if score #t cine matches 104 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 106 run setblock 141 -12 86 minecraft:chain[axis=y]
execute if score #t cine matches 106 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 108 run setblock 141 -13 86 minecraft:chain[axis=y]
execute if score #t cine matches 108 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 110 run setblock 141 -14 86 minecraft:chain[axis=y]
execute if score #t cine matches 110 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 114 run function atelier:suspendu_ss2_l5_a4
execute if score #t cine matches 150 run function atelier:suspendu_ss2_cle_coffre
execute if score #t cine matches 150 run execute as @a[tag=cine] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1 1.2
execute if score #t cine matches 159 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 0.75
execute if score #t cine matches 163 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 0.94
execute if score #t cine matches 167 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.12
execute if score #t cine matches 172 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
execute if score #t cine matches 172 run execute as @a[tag=cine] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1
