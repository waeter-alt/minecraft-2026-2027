# [claude-build] Un joueur entre dans la cinematique : sa place et son mode de jeu sont gardes, puis il regarde par la camera. Execute en tant que ce joueur.
tag @s add cine
scoreboard players add #nb cine 1
scoreboard players operation @s cine = #nb cine
execute store result score @s cine_mode run data get entity @s playerGameType
summon minecraft:marker ~ ~ ~ {Tags:["cine_retour","cine_neuf"]}
tp @e[type=minecraft:marker,tag=cine_neuf] @s
scoreboard players operation @e[type=minecraft:marker,tag=cine_neuf] cine = @s cine
tag @e[type=minecraft:marker,tag=cine_neuf] remove cine_neuf
gamemode spectator @s
spectate @e[type=minecraft:armor_stand,tag=cine_cam,limit=1]
