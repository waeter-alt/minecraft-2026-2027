# [claude-build] Lance la cinematique « cle » : la camera, puis les joueurs de la salle (en spectateur, tournes vers la camera).
scoreboard players set #id cine 60
scoreboard players set #t cine 1
scoreboard players set #nb cine 0
summon minecraft:armor_stand 58.500 -11.500 106.500 {Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["cine_cam"],Rotation:[-93.614f,2.106f]}
execute positioned 27 -17 100 as @a[distance=..45,gamemode=!spectator] at @s run function atelier:suspendu_cine_joueur
