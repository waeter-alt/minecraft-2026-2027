# [claude-build] Un joueur s'approche de l'ile G : ses 3 ennemi(s) apparaissent (une seule fois).
scoreboard players set #e_G suspendu 1
summon minecraft:zombie 118 -17 38 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
summon minecraft:skeleton 133 -17 46 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
summon minecraft:zombie 120 -17 49 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
