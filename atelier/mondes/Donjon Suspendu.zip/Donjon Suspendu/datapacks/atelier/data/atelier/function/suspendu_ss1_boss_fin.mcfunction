# [claude-build] Le mini-boss est vaincu : une cinematique montre le coffre du grappin qui apparait sur l'estrade (ou le coffre apparait tout de suite si une autre cinematique est en cours).
scoreboard players set #s4 suspendu 2
scoreboard players operation #libre cine = #t cine
execute if score #libre cine matches 0 run function atelier:suspendu_cine_debut_boss
execute unless score #libre cine matches 0 run function atelier:suspendu_ss1_boss_coffre
