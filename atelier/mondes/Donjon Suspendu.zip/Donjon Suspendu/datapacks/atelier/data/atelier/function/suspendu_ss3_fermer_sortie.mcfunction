# [claude-build] Referme la sortie du boss (remise a zero).
fill 233 4 -29 233 7 -27 minecraft:iron_bars[waterlogged=false]
