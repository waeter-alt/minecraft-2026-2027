# [claude-build] Chaque tick : les cinematiques, le combat de la salle 1 et les portes a cle.
execute if score #t cine matches 1.. run function atelier:suspendu_cine_cadre
execute unless score #t cine matches 1.. as @a[tag=cine] run function atelier:suspendu_cine_retour_joueur
execute if score #s1 suspendu matches 0 positioned 1 30 -30 if entity @a[gamemode=!spectator,distance=..13] run function atelier:suspendu_s1_debut
execute if score #s1 suspendu matches 1 unless entity @e[type=minecraft:zombie,tag=suspendu_s1] run function atelier:suspendu_s1_fin
execute if score #p1 suspendu matches 0 positioned 11 32 -41 as @a[gamemode=!spectator,distance=..5] if items entity @s weapon.mainhand minecraft:tripwire_hook[minecraft:custom_name='"Clé bleu"'] run function atelier:suspendu_ouvrir_p1
execute if score #p2 suspendu matches 0 positioned -13 32 -42 as @a[gamemode=!spectator,distance=..5] if items entity @s weapon.mainhand minecraft:tripwire_hook[minecraft:custom_name='"Clé jaune"'] run function atelier:suspendu_ouvrir_p2
execute if score #p3 suspendu matches 0 positioned -2 32 -48 as @a[gamemode=!spectator,distance=..8] if items entity @s weapon.mainhand minecraft:tripwire_hook[minecraft:custom_name='"Clé rouge"'] run function atelier:suspendu_ouvrir_p3
execute if score #s2 suspendu matches 0 positioned 7 2 -3 if entity @a[gamemode=!spectator,distance=..9] run function atelier:suspendu_ss1_petite_debut
execute if score #s2 suspendu matches 1 unless entity @e[tag=suspendu_ss1a] run function atelier:suspendu_ss1_petite_fin
execute if score #s3 suspendu matches 0 positioned 15 13 -35 if entity @a[gamemode=!spectator,distance=..14] run function atelier:suspendu_ss1_musicale_debut
execute if score #s4 suspendu matches 0 positioned -30 -26 -30 if entity @a[gamemode=!spectator,distance=..22] run function atelier:suspendu_ss1_boss_debut
execute if score #s4 suspendu matches 1 unless entity @e[tag=suspendu_ss1m] run function atelier:suspendu_ss1_boss_fin
execute if score #mt suspendu matches 1.. run function atelier:suspendu_mus_cadre
execute if score #mt suspendu matches 0 if score #mok suspendu matches 0 if block 3 14 -40 minecraft:stone_button[powered=true] run function atelier:suspendu_mus_start
execute if block 3 14 -37 minecraft:note_block[note=6] run function atelier:suspendu_mus_pad1
execute if block 3 14 -35 minecraft:note_block[note=9] run function atelier:suspendu_mus_pad2
execute if block 3 14 -33 minecraft:note_block[note=11] run function atelier:suspendu_mus_pad3
execute if block 3 14 -31 minecraft:note_block[note=13] run function atelier:suspendu_mus_pad4
execute if block 3 14 -29 minecraft:note_block[note=16] run function atelier:suspendu_mus_pad5
execute if score #l1 suspendu matches 0 if block 122 -17 -44 minecraft:lever[powered=true] run function atelier:suspendu_ss2_levier1
execute if score #l2 suspendu matches 0 if block 62 -16 -16 minecraft:lever[powered=true] run function atelier:suspendu_ss2_levier2
execute if score #l3 suspendu matches 0 if block 87 -17 -60 minecraft:lever[powered=true] run function atelier:suspendu_ss2_levier3
execute if score #l4 suspendu matches 0 if block 47 -17 61 minecraft:lever[powered=true] run function atelier:suspendu_ss2_levier4
execute if score #l5 suspendu matches 0 if block 27 -17 100 minecraft:lever[powered=true] run function atelier:suspendu_ss2_levier5
execute if score #e_B suspendu matches 0 positioned 120 -17 -37 if entity @a[gamemode=!spectator,distance=..36] run function atelier:suspendu_ss2_ennemis_b
execute if score #e_C suspendu matches 0 positioned 64 -17 -14 if entity @a[gamemode=!spectator,distance=..36] run function atelier:suspendu_ss2_ennemis_c
execute if score #e_A suspendu matches 0 positioned 87 -17 -58 if entity @a[gamemode=!spectator,distance=..36] run function atelier:suspendu_ss2_ennemis_a
execute if score #e_F suspendu matches 0 positioned 58 -17 60 if entity @a[gamemode=!spectator,distance=..36] run function atelier:suspendu_ss2_ennemis_f
execute if score #e_PONT suspendu matches 0 positioned 76 -17 53 if entity @a[gamemode=!spectator,distance=..36] run function atelier:suspendu_ss2_ennemis_pont
execute if score #e_G suspendu matches 0 positioned 127 -17 44 if entity @a[gamemode=!spectator,distance=..36] run function atelier:suspendu_ss2_ennemis_g
execute if score #e_H suspendu matches 0 positioned 32 -17 101 if entity @a[gamemode=!spectator,distance=..36] run function atelier:suspendu_ss2_ennemis_h
execute if score #e_I suspendu matches 0 positioned 143 -17 98 if entity @a[gamemode=!spectator,distance=..36] run function atelier:suspendu_ss2_ennemis_i
