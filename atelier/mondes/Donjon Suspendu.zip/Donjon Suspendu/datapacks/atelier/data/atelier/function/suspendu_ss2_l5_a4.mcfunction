# [claude-build] Levier 5 : l'ancrage 4 sur 4 apparait (avec son pilier s'il est au dessus du vide).
fill 141 -14 86 141 -6 86 minecraft:chain[axis=y]
setblock 141 -15 86 grappin:ancrage
execute positioned 141 -15 86 run particle minecraft:end_rod ~ ~ ~ 0.3 0.6 0.3 0.05 30
execute positioned 141 -15 86 run playsound minecraft:block.chain.place master @a[distance=..60] ~ ~ ~ 2 0.8
