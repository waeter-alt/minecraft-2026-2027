# [claude-build] Levier 3 : l'ancrage 2 sur 2 apparait (avec son pilier s'il est au dessus du vide).
fill 119 -14 41 119 -6 41 minecraft:chain[axis=y]
setblock 119 -15 41 grappin:ancrage
execute positioned 119 -15 41 run particle minecraft:end_rod ~ ~ ~ 0.3 0.6 0.3 0.05 30
execute positioned 119 -15 41 run playsound minecraft:block.chain.place master @a[distance=..60] ~ ~ ~ 2 0.8
