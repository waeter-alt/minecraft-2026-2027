# [claude-build] Tout apparait tout de suite (une autre cinematique est en cours) : les ancrages du levier 5, puis le coffre de la cle.
function atelier:suspendu_ss2_l5_a1
function atelier:suspendu_ss2_l5_a2
function atelier:suspendu_ss2_l5_a3
function atelier:suspendu_ss2_l5_a4
function atelier:suspendu_ss2_cle_coffre
