# [claude-build] Un joueur entre dans la salle de l'enigme musicale : un zombie et un squelette apparaissent (une seule fois).
scoreboard players set #s3 suspendu 1
summon minecraft:zombie 20 13 -40 {Tags:["suspendu_ss1b"],PersistenceRequired:1b}
summon minecraft:skeleton 29 13 -30 {Tags:["suspendu_ss1b"],PersistenceRequired:1b}
