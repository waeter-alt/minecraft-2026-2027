# [claude-build] Levier 4 : l'ancrage 1 sur 1 apparait (avec son pilier s'il est au dessus du vide).
fill 45 -14 92 45 -6 92 minecraft:chain[axis=y]
setblock 45 -15 92 donjon:ancrage
execute positioned 45 -15 92 run particle minecraft:end_rod ~ ~ ~ 0.3 0.6 0.3 0.05 30
execute positioned 45 -15 92 run playsound minecraft:block.chain.place master @a[distance=..60] ~ ~ ~ 2 0.8
