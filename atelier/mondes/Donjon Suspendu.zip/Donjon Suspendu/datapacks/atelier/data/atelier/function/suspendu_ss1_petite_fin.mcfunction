# [claude-build] Les deux gardiens sont vaincus : la porte bleue de la petite salle s'ouvre.
scoreboard players set #s2 suspendu 2
function atelier:suspendu_ouvrir_pm1
