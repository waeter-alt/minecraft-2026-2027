# [claude-build] Un joueur s'approche de l'ile C : ses 1 ennemi(s) apparaissent (une seule fois).
scoreboard players set #e_C suspendu 1
summon minecraft:zombie 83 -17 -19 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
