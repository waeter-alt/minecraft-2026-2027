# [claude-build] Cinematique « levier3 » : une image par tick (la camera), et ses evenements (sons, effets).
execute if score #t cine matches 1 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.818 -12.000 -8.237 -18.667 33.690
execute if score #t cine matches 2 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.821 -12.005 -8.231 -18.667 33.690
execute if score #t cine matches 3 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.827 -12.018 -8.212 -18.667 33.690
execute if score #t cine matches 4 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.838 -12.040 -8.181 -18.667 33.690
execute if score #t cine matches 5 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.852 -12.070 -8.138 -18.667 33.690
execute if score #t cine matches 6 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.870 -12.108 -8.084 -18.667 33.690
execute if score #t cine matches 7 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.892 -12.153 -8.020 -18.667 33.690
execute if score #t cine matches 8 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.917 -12.206 -7.945 -18.667 33.690
execute if score #t cine matches 9 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.945 -12.265 -7.861 -18.667 33.690
execute if score #t cine matches 10 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 104.977 -12.330 -7.768 -18.667 33.690
execute if score #t cine matches 11 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.011 -12.402 -7.666 -18.667 33.690
execute if score #t cine matches 12 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.048 -12.479 -7.557 -18.667 33.690
execute if score #t cine matches 13 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.088 -12.562 -7.439 -18.667 33.690
execute if score #t cine matches 14 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.130 -12.649 -7.315 -18.667 33.690
execute if score #t cine matches 15 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.174 -12.742 -7.184 -18.667 33.690
execute if score #t cine matches 16 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.221 -12.838 -7.047 -18.667 33.690
execute if score #t cine matches 17 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.269 -12.938 -6.904 -18.667 33.690
execute if score #t cine matches 18 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.319 -13.042 -6.756 -18.667 33.690
execute if score #t cine matches 19 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.370 -13.150 -6.604 -18.667 33.690
execute if score #t cine matches 20 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.423 -13.260 -6.447 -18.667 33.690
execute if score #t cine matches 21 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.477 -13.372 -6.287 -18.667 33.690
execute if score #t cine matches 22 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.532 -13.487 -6.124 -18.667 33.690
execute if score #t cine matches 23 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.588 -13.604 -5.959 -18.667 33.690
execute if score #t cine matches 24 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.645 -13.722 -5.791 -18.667 33.690
execute if score #t cine matches 25 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.702 -13.841 -5.622 -18.667 33.690
execute if score #t cine matches 26 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.760 -13.961 -5.451 -18.667 33.690
execute if score #t cine matches 27 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.817 -14.081 -5.280 -18.667 33.690
execute if score #t cine matches 28 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.875 -14.201 -5.109 -18.667 33.690
execute if score #t cine matches 29 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.933 -14.321 -4.939 -18.667 33.690
execute if score #t cine matches 30 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 105.990 -14.440 -4.769 -18.667 33.690
execute if score #t cine matches 31 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.047 -14.559 -4.601 -18.667 33.690
execute if score #t cine matches 32 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.103 -14.676 -4.435 -18.667 33.690
execute if score #t cine matches 33 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.158 -14.791 -4.271 -18.667 33.690
execute if score #t cine matches 34 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.213 -14.904 -4.110 -18.667 33.690
execute if score #t cine matches 35 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.266 -15.015 -3.953 -18.667 33.690
execute if score #t cine matches 36 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.318 -15.123 -3.800 -18.667 33.690
execute if score #t cine matches 37 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.368 -15.228 -3.651 -18.667 33.690
execute if score #t cine matches 38 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.417 -15.329 -3.507 -18.667 33.690
execute if score #t cine matches 39 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.464 -15.427 -3.368 -18.667 33.690
execute if score #t cine matches 40 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.508 -15.520 -3.235 -18.667 33.690
execute if score #t cine matches 41 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.552 -15.612 -3.105 -18.667 33.690
execute if score #t cine matches 42 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.597 -15.704 -2.974 -18.667 33.690
execute if score #t cine matches 43 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.641 -15.797 -2.841 -18.667 33.690
execute if score #t cine matches 44 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.687 -15.891 -2.708 -18.667 33.690
execute if score #t cine matches 45 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.732 -15.986 -2.573 -18.667 33.690
execute if score #t cine matches 46 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.778 -16.081 -2.438 -18.667 33.690
execute if score #t cine matches 47 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.824 -16.177 -2.302 -18.667 33.690
execute if score #t cine matches 48 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.870 -16.273 -2.165 -18.667 33.690
execute if score #t cine matches 49 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.916 -16.369 -2.028 -18.667 33.690
execute if score #t cine matches 50 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 106.963 -16.466 -1.891 -18.667 33.690
execute if score #t cine matches 51 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.009 -16.563 -1.753 -18.667 33.690
execute if score #t cine matches 52 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.056 -16.661 -1.614 -18.667 33.690
execute if score #t cine matches 53 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.103 -16.758 -1.476 -18.667 33.690
execute if score #t cine matches 54 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.150 -16.856 -1.337 -18.667 33.690
execute if score #t cine matches 55 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.196 -16.953 -1.199 -18.667 33.690
execute if score #t cine matches 56 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.243 -17.051 -1.060 -18.667 33.690
execute if score #t cine matches 57 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.290 -17.148 -0.922 -18.667 33.690
execute if score #t cine matches 58 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.337 -17.245 -0.784 -18.667 33.690
execute if score #t cine matches 59 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.383 -17.342 -0.646 -18.667 33.690
execute if score #t cine matches 60 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.429 -17.439 -0.509 -18.667 33.690
execute if score #t cine matches 61 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.476 -17.535 -0.372 -18.667 33.690
execute if score #t cine matches 62 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.522 -17.630 -0.236 -18.667 33.690
execute if score #t cine matches 63 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.567 -17.726 -0.101 -18.667 33.690
execute if score #t cine matches 64 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.613 -17.820 0.033 -18.667 33.690
execute if score #t cine matches 65 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.658 -17.914 0.167 -18.667 33.690
execute if score #t cine matches 66 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.703 -18.007 0.299 -18.667 33.690
execute if score #t cine matches 67 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.747 -18.100 0.431 -18.667 33.690
execute if score #t cine matches 68 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.791 -18.191 0.561 -18.667 33.690
execute if score #t cine matches 69 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.834 -18.282 0.690 -18.667 33.690
execute if score #t cine matches 70 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.877 -18.372 0.817 -18.667 33.690
execute if score #t cine matches 71 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.920 -18.460 0.943 -18.667 33.690
execute if score #t cine matches 72 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 107.962 -18.548 1.067 -18.667 33.690
execute if score #t cine matches 73 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.003 -18.634 1.190 -18.667 33.690
execute if score #t cine matches 74 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.044 -18.719 1.311 -18.667 33.690
execute if score #t cine matches 75 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.085 -18.803 1.430 -18.667 33.690
execute if score #t cine matches 76 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.124 -18.885 1.547 -18.667 33.690
execute if score #t cine matches 77 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.163 -18.966 1.662 -18.667 33.690
execute if score #t cine matches 78 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.201 -19.046 1.775 -18.667 33.690
execute if score #t cine matches 79 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.239 -19.124 1.886 -18.667 33.690
execute if score #t cine matches 80 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.275 -19.200 1.994 -18.667 33.690
execute if score #t cine matches 81 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.311 -19.276 2.102 -18.667 33.690
execute if score #t cine matches 82 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.348 -19.352 2.210 -18.667 33.690
execute if score #t cine matches 83 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.385 -19.428 2.319 -18.667 33.690
execute if score #t cine matches 84 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.421 -19.504 2.427 -18.667 33.690
execute if score #t cine matches 85 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.458 -19.580 2.535 -18.667 33.690
execute if score #t cine matches 86 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.494 -19.656 2.642 -18.667 33.690
execute if score #t cine matches 87 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.530 -19.731 2.749 -18.667 33.690
execute if score #t cine matches 88 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.566 -19.805 2.854 -18.667 33.690
execute if score #t cine matches 89 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.601 -19.878 2.958 -18.667 33.690
execute if score #t cine matches 90 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.635 -19.950 3.060 -18.667 33.690
execute if score #t cine matches 91 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.669 -20.020 3.160 -18.667 33.690
execute if score #t cine matches 92 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.702 -20.089 3.258 -18.667 33.690
execute if score #t cine matches 93 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.734 -20.156 3.353 -18.667 33.690
execute if score #t cine matches 94 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.765 -20.220 3.445 -18.667 33.690
execute if score #t cine matches 95 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.795 -20.283 3.533 -18.667 33.690
execute if score #t cine matches 96 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.824 -20.343 3.618 -18.667 33.690
execute if score #t cine matches 97 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.851 -20.400 3.699 -18.667 33.690
execute if score #t cine matches 98 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.877 -20.454 3.776 -18.667 33.690
execute if score #t cine matches 99 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.902 -20.505 3.849 -18.667 33.690
execute if score #t cine matches 100 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.925 -20.553 3.917 -18.667 33.690
execute if score #t cine matches 101 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.946 -20.597 3.980 -18.667 33.690
execute if score #t cine matches 102 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.965 -20.637 4.037 -18.667 33.690
execute if score #t cine matches 103 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.983 -20.674 4.089 -18.667 33.690
execute if score #t cine matches 104 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 108.998 -20.706 4.135 -18.667 33.690
execute if score #t cine matches 105 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.012 -20.734 4.174 -18.667 33.690
execute if score #t cine matches 106 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.023 -20.757 4.207 -18.667 33.690
execute if score #t cine matches 107 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.032 -20.776 4.233 -18.667 33.690
execute if score #t cine matches 108 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.038 -20.789 4.253 -18.667 33.690
execute if score #t cine matches 109 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.042 -20.797 4.264 -18.667 33.690
execute if score #t cine matches 110 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 109.043 -20.800 4.268 -18.667 33.690
execute if score #t cine matches 2 run title @a[tag=cine] actionbar {"text":"Un pilier sort de l'abîme…","color":"gray"}
execute if score #t cine matches 12 run fill 111 -61 12 113 -61 12 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 110 -61 13 114 -61 13 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 110 -61 14 114 -61 14 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 110 -61 15 114 -61 15 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 111 -61 16 113 -61 16 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 111 -60 12 113 -60 12 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 110 -60 13 114 -60 13 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 110 -60 14 114 -60 14 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 110 -60 15 114 -60 15 minecraft:stone_bricks
execute if score #t cine matches 12 run fill 111 -60 16 113 -60 16 minecraft:stone_bricks
execute if score #t cine matches 12 run particle minecraft:campfire_cosy_smoke 112.500 -60.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 12 run particle minecraft:dust_plume 112.500 -60.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 12 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 12 run execute as @a[tag=cine] at @s run playsound minecraft:block.piston.extend master @s ~ ~ ~ 0.8 0.5
execute if score #t cine matches 13 run fill 111 -59 12 113 -59 12 minecraft:stone_bricks
execute if score #t cine matches 13 run fill 110 -59 13 114 -59 13 minecraft:stone_bricks
execute if score #t cine matches 13 run fill 110 -59 14 114 -59 14 minecraft:stone_bricks
execute if score #t cine matches 13 run fill 110 -59 15 114 -59 15 minecraft:stone_bricks
execute if score #t cine matches 13 run fill 111 -59 16 113 -59 16 minecraft:stone_bricks
execute if score #t cine matches 14 run fill 111 -58 12 113 -58 12 minecraft:chiseled_stone_bricks
execute if score #t cine matches 14 run fill 110 -58 13 114 -58 13 minecraft:chiseled_stone_bricks
execute if score #t cine matches 14 run fill 110 -58 14 114 -58 14 minecraft:chiseled_stone_bricks
execute if score #t cine matches 14 run fill 110 -58 15 114 -58 15 minecraft:chiseled_stone_bricks
execute if score #t cine matches 14 run fill 111 -58 16 113 -58 16 minecraft:chiseled_stone_bricks
execute if score #t cine matches 15 run fill 111 -57 12 113 -57 12 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 110 -57 13 114 -57 13 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 110 -57 14 114 -57 14 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 110 -57 15 114 -57 15 minecraft:stone_bricks
execute if score #t cine matches 15 run fill 111 -57 16 113 -57 16 minecraft:stone_bricks
execute if score #t cine matches 15 run particle minecraft:campfire_cosy_smoke 112.500 -57.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 15 run particle minecraft:dust_plume 112.500 -57.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 16 run fill 111 -56 12 113 -56 12 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 110 -56 13 114 -56 13 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 110 -56 14 114 -56 14 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 110 -56 15 114 -56 15 minecraft:stone_bricks
execute if score #t cine matches 16 run fill 111 -56 16 113 -56 16 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 111 -55 12 113 -55 12 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 110 -55 13 114 -55 13 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 110 -55 14 114 -55 14 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 110 -55 15 114 -55 15 minecraft:stone_bricks
execute if score #t cine matches 17 run fill 111 -55 16 113 -55 16 minecraft:stone_bricks
execute if score #t cine matches 18 run fill 111 -54 12 113 -54 12 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run fill 110 -54 13 114 -54 13 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run fill 110 -54 14 114 -54 14 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run fill 110 -54 15 114 -54 15 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run fill 111 -54 16 113 -54 16 minecraft:chiseled_stone_bricks
execute if score #t cine matches 18 run particle minecraft:campfire_cosy_smoke 112.500 -54.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 18 run particle minecraft:dust_plume 112.500 -54.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 18 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 19 run fill 111 -53 12 113 -53 12 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 110 -53 13 114 -53 13 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 110 -53 14 114 -53 14 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 110 -53 15 114 -53 15 minecraft:stone_bricks
execute if score #t cine matches 19 run fill 111 -53 16 113 -53 16 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 111 -52 12 113 -52 12 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 110 -52 13 114 -52 13 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 110 -52 14 114 -52 14 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 110 -52 15 114 -52 15 minecraft:stone_bricks
execute if score #t cine matches 20 run fill 111 -52 16 113 -52 16 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 111 -51 12 113 -51 12 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 110 -51 13 114 -51 13 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 110 -51 14 114 -51 14 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 110 -51 15 114 -51 15 minecraft:stone_bricks
execute if score #t cine matches 21 run fill 111 -51 16 113 -51 16 minecraft:stone_bricks
execute if score #t cine matches 21 run particle minecraft:campfire_cosy_smoke 112.500 -51.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 21 run particle minecraft:dust_plume 112.500 -51.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 22 run fill 111 -50 12 113 -50 12 minecraft:chiseled_stone_bricks
execute if score #t cine matches 22 run fill 110 -50 13 114 -50 13 minecraft:chiseled_stone_bricks
execute if score #t cine matches 22 run fill 110 -50 14 114 -50 14 minecraft:chiseled_stone_bricks
execute if score #t cine matches 22 run fill 110 -50 15 114 -50 15 minecraft:chiseled_stone_bricks
execute if score #t cine matches 22 run fill 111 -50 16 113 -50 16 minecraft:chiseled_stone_bricks
execute if score #t cine matches 23 run fill 111 -49 12 113 -49 12 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 110 -49 13 114 -49 13 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 110 -49 14 114 -49 14 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 110 -49 15 114 -49 15 minecraft:stone_bricks
execute if score #t cine matches 23 run fill 111 -49 16 113 -49 16 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 111 -48 12 113 -48 12 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 110 -48 13 114 -48 13 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 110 -48 14 114 -48 14 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 110 -48 15 114 -48 15 minecraft:stone_bricks
execute if score #t cine matches 24 run fill 111 -48 16 113 -48 16 minecraft:stone_bricks
execute if score #t cine matches 24 run particle minecraft:campfire_cosy_smoke 112.500 -48.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 24 run particle minecraft:dust_plume 112.500 -48.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 24 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 25 run fill 111 -47 12 113 -47 12 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 110 -47 13 114 -47 13 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 110 -47 14 114 -47 14 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 110 -47 15 114 -47 15 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 111 -47 16 113 -47 16 minecraft:stone_bricks
execute if score #t cine matches 25 run fill 111 -46 12 113 -46 12 minecraft:chiseled_stone_bricks
execute if score #t cine matches 25 run fill 110 -46 13 114 -46 13 minecraft:chiseled_stone_bricks
execute if score #t cine matches 25 run fill 110 -46 14 114 -46 14 minecraft:chiseled_stone_bricks
execute if score #t cine matches 25 run fill 110 -46 15 114 -46 15 minecraft:chiseled_stone_bricks
execute if score #t cine matches 25 run fill 111 -46 16 113 -46 16 minecraft:chiseled_stone_bricks
execute if score #t cine matches 26 run fill 111 -45 12 113 -45 12 minecraft:stone_bricks
execute if score #t cine matches 26 run fill 110 -45 13 114 -45 13 minecraft:stone_bricks
execute if score #t cine matches 26 run fill 110 -45 14 114 -45 14 minecraft:stone_bricks
execute if score #t cine matches 26 run fill 110 -45 15 114 -45 15 minecraft:stone_bricks
execute if score #t cine matches 26 run fill 111 -45 16 113 -45 16 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 111 -44 12 113 -44 12 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 110 -44 13 114 -44 13 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 110 -44 14 114 -44 14 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 110 -44 15 114 -44 15 minecraft:stone_bricks
execute if score #t cine matches 27 run fill 111 -44 16 113 -44 16 minecraft:stone_bricks
execute if score #t cine matches 27 run particle minecraft:campfire_cosy_smoke 112.500 -44.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 27 run particle minecraft:dust_plume 112.500 -44.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 28 run fill 111 -43 12 113 -43 12 minecraft:stone_bricks
execute if score #t cine matches 28 run fill 110 -43 13 114 -43 13 minecraft:stone_bricks
execute if score #t cine matches 28 run fill 110 -43 14 114 -43 14 minecraft:stone_bricks
execute if score #t cine matches 28 run fill 110 -43 15 114 -43 15 minecraft:stone_bricks
execute if score #t cine matches 28 run fill 111 -43 16 113 -43 16 minecraft:stone_bricks
execute if score #t cine matches 29 run fill 111 -42 12 113 -42 12 minecraft:chiseled_stone_bricks
execute if score #t cine matches 29 run fill 110 -42 13 114 -42 13 minecraft:chiseled_stone_bricks
execute if score #t cine matches 29 run fill 110 -42 14 114 -42 14 minecraft:chiseled_stone_bricks
execute if score #t cine matches 29 run fill 110 -42 15 114 -42 15 minecraft:chiseled_stone_bricks
execute if score #t cine matches 29 run fill 111 -42 16 113 -42 16 minecraft:chiseled_stone_bricks
execute if score #t cine matches 30 run fill 111 -41 12 113 -41 12 minecraft:stone_bricks
execute if score #t cine matches 30 run fill 110 -41 13 114 -41 13 minecraft:stone_bricks
execute if score #t cine matches 30 run fill 110 -41 14 114 -41 14 minecraft:stone_bricks
execute if score #t cine matches 30 run fill 110 -41 15 114 -41 15 minecraft:stone_bricks
execute if score #t cine matches 30 run fill 111 -41 16 113 -41 16 minecraft:stone_bricks
execute if score #t cine matches 30 run particle minecraft:campfire_cosy_smoke 112.500 -41.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 30 run particle minecraft:dust_plume 112.500 -41.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 30 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 31 run fill 111 -40 12 113 -40 12 minecraft:stone_bricks
execute if score #t cine matches 31 run fill 110 -40 13 114 -40 13 minecraft:stone_bricks
execute if score #t cine matches 31 run fill 110 -40 14 114 -40 14 minecraft:stone_bricks
execute if score #t cine matches 31 run fill 110 -40 15 114 -40 15 minecraft:stone_bricks
execute if score #t cine matches 31 run fill 111 -40 16 113 -40 16 minecraft:stone_bricks
execute if score #t cine matches 32 run fill 111 -39 12 113 -39 12 minecraft:stone_bricks
execute if score #t cine matches 32 run fill 110 -39 13 114 -39 13 minecraft:stone_bricks
execute if score #t cine matches 32 run fill 110 -39 14 114 -39 14 minecraft:stone_bricks
execute if score #t cine matches 32 run fill 110 -39 15 114 -39 15 minecraft:stone_bricks
execute if score #t cine matches 32 run fill 111 -39 16 113 -39 16 minecraft:stone_bricks
execute if score #t cine matches 33 run fill 111 -38 12 113 -38 12 minecraft:chiseled_stone_bricks
execute if score #t cine matches 33 run fill 110 -38 13 114 -38 13 minecraft:chiseled_stone_bricks
execute if score #t cine matches 33 run fill 110 -38 14 114 -38 14 minecraft:chiseled_stone_bricks
execute if score #t cine matches 33 run fill 110 -38 15 114 -38 15 minecraft:chiseled_stone_bricks
execute if score #t cine matches 33 run fill 111 -38 16 113 -38 16 minecraft:chiseled_stone_bricks
execute if score #t cine matches 33 run particle minecraft:campfire_cosy_smoke 112.500 -38.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 33 run particle minecraft:dust_plume 112.500 -38.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 34 run fill 111 -37 12 113 -37 12 minecraft:stone_bricks
execute if score #t cine matches 34 run fill 110 -37 13 114 -37 13 minecraft:stone_bricks
execute if score #t cine matches 34 run fill 110 -37 14 114 -37 14 minecraft:stone_bricks
execute if score #t cine matches 34 run fill 110 -37 15 114 -37 15 minecraft:stone_bricks
execute if score #t cine matches 34 run fill 111 -37 16 113 -37 16 minecraft:stone_bricks
execute if score #t cine matches 34 run setblock 119 -6 41 minecraft:chain[axis=y]
execute if score #t cine matches 34 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 35 run fill 111 -36 12 113 -36 12 minecraft:stone_bricks
execute if score #t cine matches 35 run fill 110 -36 13 114 -36 13 minecraft:stone_bricks
execute if score #t cine matches 35 run fill 110 -36 14 114 -36 14 minecraft:stone_bricks
execute if score #t cine matches 35 run fill 110 -36 15 114 -36 15 minecraft:stone_bricks
execute if score #t cine matches 35 run fill 111 -36 16 113 -36 16 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 111 -35 12 113 -35 12 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 110 -35 13 114 -35 13 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 110 -35 14 114 -35 14 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 110 -35 15 114 -35 15 minecraft:stone_bricks
execute if score #t cine matches 36 run fill 111 -35 16 113 -35 16 minecraft:stone_bricks
execute if score #t cine matches 36 run particle minecraft:campfire_cosy_smoke 112.500 -35.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 36 run particle minecraft:dust_plume 112.500 -35.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 36 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 36 run setblock 119 -7 41 minecraft:chain[axis=y]
execute if score #t cine matches 36 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 37 run fill 111 -34 12 113 -34 12 minecraft:chiseled_stone_bricks
execute if score #t cine matches 37 run fill 110 -34 13 114 -34 13 minecraft:chiseled_stone_bricks
execute if score #t cine matches 37 run fill 110 -34 14 114 -34 14 minecraft:chiseled_stone_bricks
execute if score #t cine matches 37 run fill 110 -34 15 114 -34 15 minecraft:chiseled_stone_bricks
execute if score #t cine matches 37 run fill 111 -34 16 113 -34 16 minecraft:chiseled_stone_bricks
execute if score #t cine matches 38 run fill 111 -33 12 113 -33 12 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 110 -33 13 114 -33 13 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 110 -33 14 114 -33 14 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 110 -33 15 114 -33 15 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 111 -33 16 113 -33 16 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 111 -32 12 113 -32 12 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 110 -32 13 114 -32 13 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 110 -32 14 114 -32 14 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 110 -32 15 114 -32 15 minecraft:stone_bricks
execute if score #t cine matches 38 run fill 111 -32 16 113 -32 16 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 111 -31 12 113 -31 12 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 110 -31 13 114 -31 13 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 110 -31 14 114 -31 14 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 110 -31 15 114 -31 15 minecraft:stone_bricks
execute if score #t cine matches 39 run fill 111 -31 16 113 -31 16 minecraft:stone_bricks
execute if score #t cine matches 39 run particle minecraft:campfire_cosy_smoke 112.500 -31.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 39 run particle minecraft:dust_plume 112.500 -31.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 39 run setblock 119 -8 41 minecraft:chain[axis=y]
execute if score #t cine matches 39 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 40 run fill 111 -30 12 113 -30 12 minecraft:chiseled_stone_bricks
execute if score #t cine matches 40 run fill 110 -30 13 114 -30 13 minecraft:chiseled_stone_bricks
execute if score #t cine matches 40 run fill 110 -30 14 114 -30 14 minecraft:chiseled_stone_bricks
execute if score #t cine matches 40 run fill 110 -30 15 114 -30 15 minecraft:chiseled_stone_bricks
execute if score #t cine matches 40 run fill 111 -30 16 113 -30 16 minecraft:chiseled_stone_bricks
execute if score #t cine matches 41 run fill 111 -29 12 113 -29 12 minecraft:stone_bricks
execute if score #t cine matches 41 run fill 110 -29 13 114 -29 13 minecraft:stone_bricks
execute if score #t cine matches 41 run fill 110 -29 14 114 -29 14 minecraft:stone_bricks
execute if score #t cine matches 41 run fill 110 -29 15 114 -29 15 minecraft:stone_bricks
execute if score #t cine matches 41 run fill 111 -29 16 113 -29 16 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 111 -28 12 113 -28 12 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 110 -28 13 114 -28 13 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 110 -28 14 114 -28 14 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 110 -28 15 114 -28 15 minecraft:stone_bricks
execute if score #t cine matches 42 run fill 111 -28 16 113 -28 16 minecraft:stone_bricks
execute if score #t cine matches 42 run particle minecraft:campfire_cosy_smoke 112.500 -28.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 42 run particle minecraft:dust_plume 112.500 -28.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 42 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 42 run setblock 119 -9 41 minecraft:chain[axis=y]
execute if score #t cine matches 42 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 43 run fill 111 -27 12 113 -27 12 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 110 -27 13 114 -27 13 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 110 -27 14 114 -27 14 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 110 -27 15 114 -27 15 minecraft:stone_bricks
execute if score #t cine matches 43 run fill 111 -27 16 113 -27 16 minecraft:stone_bricks
execute if score #t cine matches 44 run fill 111 -26 12 113 -26 12 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run fill 110 -26 13 114 -26 13 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run fill 110 -26 14 114 -26 14 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run fill 110 -26 15 114 -26 15 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run fill 111 -26 16 113 -26 16 minecraft:chiseled_stone_bricks
execute if score #t cine matches 44 run setblock 119 -10 41 minecraft:chain[axis=y]
execute if score #t cine matches 44 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 45 run fill 111 -25 12 113 -25 12 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 110 -25 13 114 -25 13 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 110 -25 14 114 -25 14 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 110 -25 15 114 -25 15 minecraft:stone_bricks
execute if score #t cine matches 45 run fill 111 -25 16 113 -25 16 minecraft:stone_bricks
execute if score #t cine matches 45 run particle minecraft:campfire_cosy_smoke 112.500 -25.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 45 run particle minecraft:dust_plume 112.500 -25.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 46 run fill 111 -24 12 113 -24 12 minecraft:stone_bricks
execute if score #t cine matches 46 run fill 110 -24 13 114 -24 13 minecraft:stone_bricks
execute if score #t cine matches 46 run fill 110 -24 14 114 -24 14 minecraft:stone_bricks
execute if score #t cine matches 46 run fill 110 -24 15 114 -24 15 minecraft:stone_bricks
execute if score #t cine matches 46 run fill 111 -24 16 113 -24 16 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 111 -23 12 113 -23 12 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 110 -23 13 114 -23 13 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 110 -23 14 114 -23 14 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 110 -23 15 114 -23 15 minecraft:stone_bricks
execute if score #t cine matches 47 run fill 111 -23 16 113 -23 16 minecraft:stone_bricks
execute if score #t cine matches 47 run setblock 119 -11 41 minecraft:chain[axis=y]
execute if score #t cine matches 47 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 48 run fill 111 -22 12 113 -22 12 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run fill 110 -22 13 114 -22 13 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run fill 110 -22 14 114 -22 14 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run fill 110 -22 15 114 -22 15 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run fill 111 -22 16 113 -22 16 minecraft:chiseled_stone_bricks
execute if score #t cine matches 48 run particle minecraft:campfire_cosy_smoke 112.500 -22.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 48 run particle minecraft:dust_plume 112.500 -22.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 48 run execute as @a[tag=cine] at @s run playsound minecraft:block.deepslate.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 49 run fill 111 -21 12 113 -21 12 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 110 -21 13 114 -21 13 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 110 -21 14 114 -21 14 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 110 -21 15 114 -21 15 minecraft:stone_bricks
execute if score #t cine matches 49 run fill 111 -21 16 113 -21 16 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 111 -20 12 113 -20 12 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 110 -20 13 114 -20 13 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 110 -20 14 114 -20 14 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 110 -20 15 114 -20 15 minecraft:stone_bricks
execute if score #t cine matches 50 run fill 111 -20 16 113 -20 16 minecraft:stone_bricks
execute if score #t cine matches 50 run setblock 119 -12 41 minecraft:chain[axis=y]
execute if score #t cine matches 50 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 51 run fill 111 -19 12 113 -19 12 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 110 -19 13 114 -19 13 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 110 -19 14 114 -19 14 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 110 -19 15 114 -19 15 minecraft:stone_bricks
execute if score #t cine matches 51 run fill 111 -19 16 113 -19 16 minecraft:stone_bricks
execute if score #t cine matches 51 run particle minecraft:campfire_cosy_smoke 112.500 -19.000 14.500 1.6 0.3 1.6 0.02 10 force
execute if score #t cine matches 51 run particle minecraft:dust_plume 112.500 -19.000 14.500 1.8 0.2 1.8 0.05 25 force
execute if score #t cine matches 52 run setblock 119 -13 41 minecraft:chain[axis=y]
execute if score #t cine matches 52 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 55 run setblock 119 -14 41 minecraft:chain[axis=y]
execute if score #t cine matches 55 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 56 run function atelier:suspendu_ss2_l3_a1
execute if score #t cine matches 56 run execute as @a[tag=cine] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1 1.4
execute if score #t cine matches 62 run function atelier:suspendu_ss2_l3_a2
execute if score #t cine matches 62 run execute as @a[tag=cine] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1 1.4
execute if score #t cine matches 70 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.0
execute if score #t cine matches 74 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.26
execute if score #t cine matches 78 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
execute if score #t cine matches 78 run title @a[tag=cine] actionbar {"text":"Levier 3 : un point d'ancrage est apparu","color":"aqua"}
