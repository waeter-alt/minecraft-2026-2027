# [claude-build] Lance la cinematique « porte3 » : la camera, puis les joueurs de la salle (en spectateur, tournes vers la camera).
scoreboard players set #id cine 23
scoreboard players set #t cine 1
scoreboard players set #nb cine 0
summon minecraft:armor_stand -3.191 34.500 -35.666 {Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["cine_cam"],Rotation:[-169.060f,7.404f]}
execute positioned 1 30 -30 as @a[distance=..45,gamemode=!spectator] at @s run function atelier:suspendu_cine_joueur
