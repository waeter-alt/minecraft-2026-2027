# [claude-build] Un tick de cinematique (appelee quand #t cine est au moins 1).
scoreboard players add #t cine 1
execute if score #id cine matches 10 run function atelier:suspendu_cine_coffre
execute if score #id cine matches 21 run function atelier:suspendu_cine_porte1
execute if score #id cine matches 22 run function atelier:suspendu_cine_porte2
execute if score #id cine matches 23 run function atelier:suspendu_cine_porte3
execute if score #id cine matches 24 run function atelier:suspendu_cine_portem1
execute if score #id cine matches 40 run function atelier:suspendu_cine_boss
execute if score #id cine matches 60 run function atelier:suspendu_cine_cle
execute if score #t cine matches 6.. as @a[tag=cine] at @s unless entity @e[type=minecraft:armor_stand,tag=cine_cam,distance=..1.5] run function atelier:suspendu_cine_retour_joueur
execute unless score #id cine matches 60 if score #t cine matches 112.. run function atelier:suspendu_cine_fin
execute if score #id cine matches 60 if score #t cine matches 212.. run function atelier:suspendu_cine_fin
