# [claude-build] Lance la cinematique « levier3 » : la camera, puis les joueurs de la salle (en spectateur, tournes vers la camera).
scoreboard players set #id cine 63
scoreboard players set #t cine 1
scoreboard players set #nb cine 0
summon minecraft:armor_stand 104.818 -12.000 -8.237 {Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["cine_cam"],Rotation:[-18.667f,33.690f]}
execute positioned 87 -17 -60 as @a[distance=..45,gamemode=!spectator] at @s run function atelier:suspendu_cine_joueur
