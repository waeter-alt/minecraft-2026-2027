# [claude-build] Ouvre la sortie du boss (a la mort du boss).
fill 233 4 -29 233 7 -27 minecraft:air
playsound minecraft:block.iron_door.open master @a 233 4 -29 2 0.6
