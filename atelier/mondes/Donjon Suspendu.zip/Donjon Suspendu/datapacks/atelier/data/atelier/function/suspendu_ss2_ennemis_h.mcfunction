# [claude-build] Un joueur s'approche de l'ile H : ses 1 ennemi(s) apparaissent (une seule fois).
scoreboard players set #e_H suspendu 1
summon minecraft:zombie 43 -17 90 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
