# [claude-build] Levier 4 : tous ses ancrages apparaissent tout de suite (sans camera).
function atelier:suspendu_ss2_l4_a1
execute positioned 47 -17 61 run title @a[distance=..40] actionbar {"text":"Levier 4 : un point d'ancrage est apparu","color":"aqua"}
