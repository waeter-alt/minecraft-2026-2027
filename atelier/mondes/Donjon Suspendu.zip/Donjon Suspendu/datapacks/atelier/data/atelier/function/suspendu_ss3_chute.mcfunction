# [claude-build] Un joueur est tombe dans le gouffre du boss : on decroche son grappin, chute lente (pas de degats). Tombe du pont (en amont de la rampe), il revient au depart du pont (a refranchir au grappin) ; tombe de la rampe, il revient en tete de pont.
data modify storage atelier:suspendu chute.uuid set from entity @s UUID
function atelier:suspendu_ss3_decrocher with storage atelier:suspendu chute
effect give @s minecraft:slow_falling 3 0 true
execute positioned 177 -62 -69 if entity @s[dx=56,dy=12,dz=29] run tag @s add chute_pont
execute if entity @s[tag=chute_pont] run tp @s 205.5 -24.0 -66.5 0 0
execute unless entity @s[tag=chute_pont] run tp @s 205.5 -24.0 -34.5 0 0
tag @s remove chute_pont
title @s actionbar {"text":"Tu es tombé !","color":"red"}
