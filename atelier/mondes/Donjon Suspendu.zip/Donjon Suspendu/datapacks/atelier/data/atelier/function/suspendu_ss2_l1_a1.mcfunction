# [claude-build] Levier 1 : l'ancrage 1 sur 2 apparait (avec son pilier s'il est au dessus du vide).
fill 89 -61 -30 91 -19 -30 minecraft:stone_bricks
fill 88 -61 -29 92 -19 -29 minecraft:stone_bricks
fill 88 -61 -28 92 -19 -28 minecraft:stone_bricks
fill 88 -61 -27 92 -19 -27 minecraft:stone_bricks
fill 89 -61 -26 91 -19 -26 minecraft:stone_bricks
fill 89 -22 -30 91 -22 -30 minecraft:chiseled_stone_bricks
fill 88 -22 -29 92 -22 -29 minecraft:chiseled_stone_bricks
fill 88 -22 -28 92 -22 -28 minecraft:chiseled_stone_bricks
fill 88 -22 -27 92 -22 -27 minecraft:chiseled_stone_bricks
fill 89 -22 -26 91 -22 -26 minecraft:chiseled_stone_bricks
fill 89 -26 -30 91 -26 -30 minecraft:chiseled_stone_bricks
fill 88 -26 -29 92 -26 -29 minecraft:chiseled_stone_bricks
fill 88 -26 -28 92 -26 -28 minecraft:chiseled_stone_bricks
fill 88 -26 -27 92 -26 -27 minecraft:chiseled_stone_bricks
fill 89 -26 -26 91 -26 -26 minecraft:chiseled_stone_bricks
fill 89 -30 -30 91 -30 -30 minecraft:chiseled_stone_bricks
fill 88 -30 -29 92 -30 -29 minecraft:chiseled_stone_bricks
fill 88 -30 -28 92 -30 -28 minecraft:chiseled_stone_bricks
fill 88 -30 -27 92 -30 -27 minecraft:chiseled_stone_bricks
fill 89 -30 -26 91 -30 -26 minecraft:chiseled_stone_bricks
fill 89 -34 -30 91 -34 -30 minecraft:chiseled_stone_bricks
fill 88 -34 -29 92 -34 -29 minecraft:chiseled_stone_bricks
fill 88 -34 -28 92 -34 -28 minecraft:chiseled_stone_bricks
fill 88 -34 -27 92 -34 -27 minecraft:chiseled_stone_bricks
fill 89 -34 -26 91 -34 -26 minecraft:chiseled_stone_bricks
fill 89 -38 -30 91 -38 -30 minecraft:chiseled_stone_bricks
fill 88 -38 -29 92 -38 -29 minecraft:chiseled_stone_bricks
fill 88 -38 -28 92 -38 -28 minecraft:chiseled_stone_bricks
fill 88 -38 -27 92 -38 -27 minecraft:chiseled_stone_bricks
fill 89 -38 -26 91 -38 -26 minecraft:chiseled_stone_bricks
fill 89 -42 -30 91 -42 -30 minecraft:chiseled_stone_bricks
fill 88 -42 -29 92 -42 -29 minecraft:chiseled_stone_bricks
fill 88 -42 -28 92 -42 -28 minecraft:chiseled_stone_bricks
fill 88 -42 -27 92 -42 -27 minecraft:chiseled_stone_bricks
fill 89 -42 -26 91 -42 -26 minecraft:chiseled_stone_bricks
fill 89 -46 -30 91 -46 -30 minecraft:chiseled_stone_bricks
fill 88 -46 -29 92 -46 -29 minecraft:chiseled_stone_bricks
fill 88 -46 -28 92 -46 -28 minecraft:chiseled_stone_bricks
fill 88 -46 -27 92 -46 -27 minecraft:chiseled_stone_bricks
fill 89 -46 -26 91 -46 -26 minecraft:chiseled_stone_bricks
fill 89 -50 -30 91 -50 -30 minecraft:chiseled_stone_bricks
fill 88 -50 -29 92 -50 -29 minecraft:chiseled_stone_bricks
fill 88 -50 -28 92 -50 -28 minecraft:chiseled_stone_bricks
fill 88 -50 -27 92 -50 -27 minecraft:chiseled_stone_bricks
fill 89 -50 -26 91 -50 -26 minecraft:chiseled_stone_bricks
fill 89 -54 -30 91 -54 -30 minecraft:chiseled_stone_bricks
fill 88 -54 -29 92 -54 -29 minecraft:chiseled_stone_bricks
fill 88 -54 -28 92 -54 -28 minecraft:chiseled_stone_bricks
fill 88 -54 -27 92 -54 -27 minecraft:chiseled_stone_bricks
fill 89 -54 -26 91 -54 -26 minecraft:chiseled_stone_bricks
fill 89 -58 -30 91 -58 -30 minecraft:chiseled_stone_bricks
fill 88 -58 -29 92 -58 -29 minecraft:chiseled_stone_bricks
fill 88 -58 -28 92 -58 -28 minecraft:chiseled_stone_bricks
fill 88 -58 -27 92 -58 -27 minecraft:chiseled_stone_bricks
fill 89 -58 -26 91 -58 -26 minecraft:chiseled_stone_bricks
setblock 88 -18 -29 minecraft:andesite
setblock 88 -18 -28 minecraft:stone
setblock 88 -18 -27 minecraft:andesite
setblock 89 -18 -30 minecraft:stone
setblock 89 -18 -29 minecraft:stone
setblock 89 -18 -28 minecraft:stone
setblock 89 -18 -27 minecraft:stone
setblock 89 -18 -26 minecraft:tuff
setblock 90 -18 -30 minecraft:tuff
setblock 90 -18 -29 minecraft:stone
setblock 90 -18 -28 minecraft:stone
setblock 90 -18 -27 minecraft:stone
setblock 90 -18 -26 minecraft:mossy_cobblestone
setblock 91 -18 -30 minecraft:andesite
setblock 91 -18 -29 minecraft:andesite
setblock 91 -18 -28 minecraft:stone
setblock 91 -18 -27 minecraft:stone
setblock 91 -18 -26 minecraft:stone
setblock 92 -18 -29 minecraft:tuff
setblock 92 -18 -28 minecraft:stone
setblock 92 -18 -27 minecraft:stone
setblock 90 -16 -28 minecraft:light[level=13]
execute positioned 90 -17 -28 run particle minecraft:poof ~ ~ ~ 1.2 0.2 1.2 0.05 40
execute positioned 90 -18 -28 run playsound minecraft:block.stone.place master @a[distance=..60] ~ ~ ~ 3 0.6
fill 90 -14 -28 90 -6 -28 minecraft:chain[axis=y]
setblock 90 -15 -28 donjon:ancrage
execute positioned 90 -15 -28 run particle minecraft:end_rod ~ ~ ~ 0.3 0.6 0.3 0.05 30
execute positioned 90 -15 -28 run playsound minecraft:block.chain.place master @a[distance=..60] ~ ~ ~ 2 0.8
