# [claude-build] Decharge le gabarit et annonce.
forceload remove -74 -86 93 121
forceload remove 94 -86 261 121
tellraw @a [{"text":"Le Donjon Suspendu est prêt. Entrée : ","color":"green"},{"text":"[/tp @s 0 30 0 0 0]","color":"aqua","underlined":true,"clickEvent":{"action":"run_command","value":"/tp @s 0 30 0 0 0"},"hoverEvent":{"action":"show_text","contents":"Cliquer pour y aller"}}]
