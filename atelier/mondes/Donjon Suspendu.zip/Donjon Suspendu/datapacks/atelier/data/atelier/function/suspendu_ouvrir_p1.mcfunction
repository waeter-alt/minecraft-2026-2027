# [claude-build] Ouvre la porte 1 (bleue) avec sa cle : la cle est consommee et la dalle se leve tout de suite, sans cinematique.
clear @s minecraft:tripwire_hook[minecraft:custom_name='"Clé bleu"'] 1
scoreboard players set #p1 suspendu 1
function atelier:suspendu_p1_lever
