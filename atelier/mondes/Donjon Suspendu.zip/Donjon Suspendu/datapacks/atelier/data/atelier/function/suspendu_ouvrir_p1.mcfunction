# [claude-build] Ouvre la porte 1 (bleue) : une cinematique montre la porte qui se leve (ou elle se leve tout de suite si une cinematique est en cours).
clear @s minecraft:tripwire_hook[minecraft:custom_name='"Clé bleu"'] 1
scoreboard players set #p1 suspendu 1
scoreboard players operation #libre cine = #t cine
execute if score #libre cine matches 0 run function atelier:suspendu_cine_debut_porte1
execute unless score #libre cine matches 0 run function atelier:suspendu_p1_lever
