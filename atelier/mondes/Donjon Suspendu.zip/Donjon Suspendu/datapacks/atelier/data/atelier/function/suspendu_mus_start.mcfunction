# [claude-build] Le bouton de depart est presse : la melodie va etre jouee (les lampes s'allument dans l'ordre), puis c'est au joueur de la rejouer.
scoreboard players set #mt suspendu 1
scoreboard players set #mq suspendu 0
execute positioned 3 14 -40 run title @a[distance=..30] actionbar {"text":"Écoute la mélodie, puis rejoue-la sur les blocs musicaux","color":"gold"}
execute positioned 3 14 -40 run playsound minecraft:block.note_block.chime master @a[distance=..30] ~ ~ ~ 1 1.2
