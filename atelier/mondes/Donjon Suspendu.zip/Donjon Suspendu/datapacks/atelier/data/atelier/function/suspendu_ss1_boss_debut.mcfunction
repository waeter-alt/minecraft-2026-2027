# [claude-build] Un joueur s'approche du mini-boss de la grande salle : le Rodeur des Racines sort de la mousse (une seule fois). Sa vie et ses degats se reglent dans la config du mod grappin (rodeur*).
scoreboard players set #s4 suspendu 1
summon grappin:rodeur -30 -26 -30 {Tags:["suspendu_ss1m"],PersistenceRequired:1b,CustomName:'{"text":"Rôdeur des Racines","color":"red"}',CustomNameVisible:1b}
execute positioned -30 -26 -30 run title @a[distance=..60] times 10 50 20
execute positioned -30 -26 -30 run title @a[distance=..60] subtitle {"text":"Le coffre du grappin apparaîtra sur l'estrade","color":"gray"}
execute positioned -30 -26 -30 run title @a[distance=..60] title {"text":"Vainquez le Rôdeur des Racines","color":"red"}
execute positioned -30 -26 -30 run playsound minecraft:entity.ravager.roar master @a[distance=..60] ~ ~ ~ 2 1.4
