# [claude-build] Un joueur s'approche du mini-boss de la grande salle : il apparait (une seule fois). Provisoire : un vindicateur a 60 points de vie, a remplacer par le vrai mini-boss.
scoreboard players set #s4 suspendu 1
summon minecraft:vindicator -30 -26 -30 {Tags:["suspendu_ss1m"],PersistenceRequired:1b,CustomName:'{"text":"Gardien de la salle","color":"red"}',CustomNameVisible:1b}
attribute @e[type=minecraft:vindicator,tag=suspendu_ss1m,limit=1] minecraft:generic.max_health base set 60
data modify entity @e[type=minecraft:vindicator,tag=suspendu_ss1m,limit=1] Health set value 60f
execute positioned -30 -26 -30 run title @a[distance=..60] times 10 50 20
execute positioned -30 -26 -30 run title @a[distance=..60] subtitle {"text":"Le coffre du grappin apparaîtra sur l'estrade","color":"gray"}
execute positioned -30 -26 -30 run title @a[distance=..60] title {"text":"Vainquez le gardien de la salle","color":"red"}
execute positioned -30 -26 -30 run playsound minecraft:entity.vindicator.celebrate master @a[distance=..60] ~ ~ ~ 2 0.8
