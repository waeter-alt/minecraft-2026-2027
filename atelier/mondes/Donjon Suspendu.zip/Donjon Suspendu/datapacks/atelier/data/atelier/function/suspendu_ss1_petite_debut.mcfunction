# [claude-build] Un joueur entre dans la petite salle : un zombie et un squelette apparaissent (une seule fois) ; la porte s'ouvrira quand ils seront vaincus.
scoreboard players set #s2 suspendu 1
summon minecraft:zombie 4 2 -4 {Tags:["suspendu_ss1a"],PersistenceRequired:1b}
summon minecraft:skeleton 10 2 -6 {Tags:["suspendu_ss1a"],PersistenceRequired:1b}
execute positioned 7 2 -3 run title @a[distance=..30] title {"text":"Vainquez les gardiens","color":"red"}
execute positioned 7 2 -3 run playsound minecraft:entity.zombie.ambient master @a[distance=..30] ~ ~ ~ 2 0.7
