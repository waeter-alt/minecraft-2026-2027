# [claude-build] Pose automatique, une seule fois (drapeau #suspendu).
scoreboard objectives add atelier dummy
execute unless score #suspendu atelier matches 1 run schedule function atelier:suspendu_pose 100t
scoreboard players set #suspendu atelier 1
