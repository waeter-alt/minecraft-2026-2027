# [claude-build] Appelee par le mod (tag grappin:golem_mort) a la mort du golem : la sortie ne s'ouvre que si le boss a bien ete invoque (pas lors d'une remise a zero).
execute if score #boss suspendu matches 2 run function atelier:suspendu_ss3_vaincu
