# [claude-build] Lance la cinematique « levier2 » : la camera, puis les joueurs de la salle (en spectateur, tournes vers la camera).
scoreboard players set #id cine 62
scoreboard players set #t cine 1
scoreboard players set #nb cine 0
summon minecraft:armor_stand 75.420 -12.000 -35.377 {Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["cine_cam"],Rotation:[-146.976f,3.576f]}
execute positioned 62 -16 -16 as @a[distance=..45,gamemode=!spectator] at @s run function atelier:suspendu_cine_joueur
