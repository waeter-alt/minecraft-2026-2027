# [claude-build] Cinematique « levier2 » : une image par tick (la camera), et ses evenements (sons, effets).
execute if score #t cine matches 1 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.420 -12.000 -35.377 -146.976 3.576
execute if score #t cine matches 2 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.424 -12.000 -35.383 -146.976 3.576
execute if score #t cine matches 3 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.435 -12.002 -35.400 -146.976 3.576
execute if score #t cine matches 4 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.453 -12.004 -35.427 -146.976 3.576
execute if score #t cine matches 5 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.477 -12.007 -35.465 -146.976 3.576
execute if score #t cine matches 6 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.508 -12.010 -35.513 -146.976 3.576
execute if score #t cine matches 7 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.545 -12.014 -35.570 -146.976 3.576
execute if score #t cine matches 8 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.588 -12.019 -35.636 -146.976 3.576
execute if score #t cine matches 9 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.637 -12.025 -35.710 -146.976 3.576
execute if score #t cine matches 10 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.690 -12.031 -35.793 -146.976 3.576
execute if score #t cine matches 11 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.749 -12.038 -35.883 -146.976 3.576
execute if score #t cine matches 12 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.812 -12.045 -35.980 -146.976 3.576
execute if score #t cine matches 13 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.879 -12.053 -36.084 -146.976 3.576
execute if score #t cine matches 14 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 75.951 -12.061 -36.194 -146.976 3.576
execute if score #t cine matches 15 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 76.026 -12.070 -36.310 -146.976 3.576
execute if score #t cine matches 16 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 76.105 -12.079 -36.431 -146.976 3.576
execute if score #t cine matches 17 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 76.187 -12.088 -36.558 -146.976 3.576
execute if score #t cine matches 18 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 76.272 -12.098 -36.688 -146.976 3.576
execute if score #t cine matches 19 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 76.360 -12.108 -36.823 -146.976 3.576
execute if score #t cine matches 20 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 76.450 -12.118 -36.962 -146.976 3.576
execute if score #t cine matches 21 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 76.542 -12.129 -37.103 -146.976 3.576
execute if score #t cine matches 22 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 76.636 -12.139 -37.248 -146.976 3.576
execute if score #t cine matches 23 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 76.731 -12.150 -37.394 -146.976 3.576
execute if score #t cine matches 24 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 76.828 -12.161 -37.543 -146.976 3.576
execute if score #t cine matches 25 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 76.925 -12.173 -37.692 -146.976 3.576
execute if score #t cine matches 26 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.023 -12.184 -37.843 -146.976 3.576
execute if score #t cine matches 27 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.121 -12.195 -37.994 -146.976 3.576
execute if score #t cine matches 28 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.220 -12.206 -38.146 -146.976 3.576
execute if score #t cine matches 29 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.318 -12.218 -38.297 -146.976 3.576
execute if score #t cine matches 30 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.415 -12.229 -38.447 -146.976 3.576
execute if score #t cine matches 31 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.512 -12.240 -38.595 -146.976 3.576
execute if score #t cine matches 32 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.608 -12.251 -38.743 -146.976 3.576
execute if score #t cine matches 33 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.702 -12.262 -38.887 -146.976 3.576
execute if score #t cine matches 34 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.794 -12.272 -39.030 -146.976 3.576
execute if score #t cine matches 35 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.885 -12.283 -39.169 -146.976 3.576
execute if score #t cine matches 36 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 77.973 -12.293 -39.305 -146.976 3.576
execute if score #t cine matches 37 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.059 -12.303 -39.437 -146.976 3.576
execute if score #t cine matches 38 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.142 -12.312 -39.564 -146.976 3.576
execute if score #t cine matches 39 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.222 -12.321 -39.687 -146.976 3.576
execute if score #t cine matches 40 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.298 -12.330 -39.804 -146.976 3.576
execute if score #t cine matches 41 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.373 -12.339 -39.920 -146.976 3.576
execute if score #t cine matches 42 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.448 -12.347 -40.036 -146.976 3.576
execute if score #t cine matches 43 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.524 -12.356 -40.153 -146.976 3.576
execute if score #t cine matches 44 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.601 -12.365 -40.271 -146.976 3.576
execute if score #t cine matches 45 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.679 -12.374 -40.390 -146.976 3.576
execute if score #t cine matches 46 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.756 -12.383 -40.510 -146.976 3.576
execute if score #t cine matches 47 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.835 -12.392 -40.630 -146.976 3.576
execute if score #t cine matches 48 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.913 -12.401 -40.751 -146.976 3.576
execute if score #t cine matches 49 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 78.992 -12.410 -40.873 -146.976 3.576
execute if score #t cine matches 50 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.071 -12.419 -40.994 -146.976 3.576
execute if score #t cine matches 51 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.151 -12.428 -41.117 -146.976 3.576
execute if score #t cine matches 52 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.230 -12.437 -41.239 -146.976 3.576
execute if score #t cine matches 53 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.310 -12.446 -41.362 -146.976 3.576
execute if score #t cine matches 54 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.390 -12.455 -41.484 -146.976 3.576
execute if score #t cine matches 55 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.469 -12.464 -41.607 -146.976 3.576
execute if score #t cine matches 56 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.549 -12.474 -41.729 -146.976 3.576
execute if score #t cine matches 57 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.629 -12.483 -41.852 -146.976 3.576
execute if score #t cine matches 58 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.708 -12.492 -41.974 -146.976 3.576
execute if score #t cine matches 59 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.787 -12.501 -42.096 -146.976 3.576
execute if score #t cine matches 60 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.866 -12.510 -42.217 -146.976 3.576
execute if score #t cine matches 61 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 79.945 -12.519 -42.338 -146.976 3.576
execute if score #t cine matches 62 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.023 -12.528 -42.459 -146.976 3.576
execute if score #t cine matches 63 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.101 -12.537 -42.578 -146.976 3.576
execute if score #t cine matches 64 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.178 -12.546 -42.697 -146.976 3.576
execute if score #t cine matches 65 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.255 -12.554 -42.815 -146.976 3.576
execute if score #t cine matches 66 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.331 -12.563 -42.932 -146.976 3.576
execute if score #t cine matches 67 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.407 -12.572 -43.049 -146.976 3.576
execute if score #t cine matches 68 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.482 -12.580 -43.164 -146.976 3.576
execute if score #t cine matches 69 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.556 -12.589 -43.278 -146.976 3.576
execute if score #t cine matches 70 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.629 -12.597 -43.391 -146.976 3.576
execute if score #t cine matches 71 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.701 -12.606 -43.502 -146.976 3.576
execute if score #t cine matches 72 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.773 -12.614 -43.612 -146.976 3.576
execute if score #t cine matches 73 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.844 -12.622 -43.721 -146.976 3.576
execute if score #t cine matches 74 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.913 -12.630 -43.828 -146.976 3.576
execute if score #t cine matches 75 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 80.982 -12.638 -43.933 -146.976 3.576
execute if score #t cine matches 76 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.049 -12.646 -44.037 -146.976 3.576
execute if score #t cine matches 77 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.115 -12.653 -44.139 -146.976 3.576
execute if score #t cine matches 78 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.180 -12.661 -44.239 -146.976 3.576
execute if score #t cine matches 79 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.244 -12.668 -44.337 -146.976 3.576
execute if score #t cine matches 80 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.306 -12.675 -44.433 -146.976 3.576
execute if score #t cine matches 81 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.368 -12.682 -44.528 -146.976 3.576
execute if score #t cine matches 82 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.430 -12.689 -44.623 -146.976 3.576
execute if score #t cine matches 83 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.493 -12.696 -44.719 -146.976 3.576
execute if score #t cine matches 84 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.555 -12.704 -44.815 -146.976 3.576
execute if score #t cine matches 85 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.617 -12.711 -44.911 -146.976 3.576
execute if score #t cine matches 86 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.679 -12.718 -45.006 -146.976 3.576
execute if score #t cine matches 87 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.740 -12.725 -45.100 -146.976 3.576
execute if score #t cine matches 88 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.801 -12.732 -45.194 -146.976 3.576
execute if score #t cine matches 89 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.861 -12.739 -45.286 -146.976 3.576
execute if score #t cine matches 90 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.919 -12.745 -45.376 -146.976 3.576
execute if score #t cine matches 91 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 81.977 -12.752 -45.464 -146.976 3.576
execute if score #t cine matches 92 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.033 -12.758 -45.551 -146.976 3.576
execute if score #t cine matches 93 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.088 -12.765 -45.635 -146.976 3.576
execute if score #t cine matches 94 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.140 -12.771 -45.716 -146.976 3.576
execute if score #t cine matches 95 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.191 -12.777 -45.794 -146.976 3.576
execute if score #t cine matches 96 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.240 -12.782 -45.870 -146.976 3.576
execute if score #t cine matches 97 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.287 -12.787 -45.942 -146.976 3.576
execute if score #t cine matches 98 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.331 -12.793 -46.010 -146.976 3.576
execute if score #t cine matches 99 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.373 -12.797 -46.074 -146.976 3.576
execute if score #t cine matches 100 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.412 -12.802 -46.134 -146.976 3.576
execute if score #t cine matches 101 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.448 -12.806 -46.189 -146.976 3.576
execute if score #t cine matches 102 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.481 -12.810 -46.240 -146.976 3.576
execute if score #t cine matches 103 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.511 -12.813 -46.286 -146.976 3.576
execute if score #t cine matches 104 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.537 -12.816 -46.327 -146.976 3.576
execute if score #t cine matches 105 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.560 -12.819 -46.362 -146.976 3.576
execute if score #t cine matches 106 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.579 -12.821 -46.391 -146.976 3.576
execute if score #t cine matches 107 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.594 -12.823 -46.414 -146.976 3.576
execute if score #t cine matches 108 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.605 -12.824 -46.431 -146.976 3.576
execute if score #t cine matches 109 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.612 -12.825 -46.441 -146.976 3.576
execute if score #t cine matches 110 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 82.614 -12.825 -46.445 -146.976 3.576
execute if score #t cine matches 2 run title @a[tag=cine] actionbar {"text":"…","color":"gray"}
execute if score #t cine matches 28 run setblock 88 -6 -56 minecraft:chain[axis=y]
execute if score #t cine matches 28 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 30 run setblock 88 -7 -56 minecraft:chain[axis=y]
execute if score #t cine matches 30 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 33 run setblock 88 -8 -56 minecraft:chain[axis=y]
execute if score #t cine matches 33 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 36 run setblock 88 -9 -56 minecraft:chain[axis=y]
execute if score #t cine matches 36 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 38 run setblock 88 -10 -56 minecraft:chain[axis=y]
execute if score #t cine matches 38 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 41 run setblock 88 -11 -56 minecraft:chain[axis=y]
execute if score #t cine matches 41 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 44 run setblock 88 -12 -56 minecraft:chain[axis=y]
execute if score #t cine matches 44 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 46 run setblock 88 -13 -56 minecraft:chain[axis=y]
execute if score #t cine matches 46 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 49 run setblock 88 -14 -56 minecraft:chain[axis=y]
execute if score #t cine matches 49 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.step master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 56 run function atelier:suspendu_ss2_l2_a1
execute if score #t cine matches 56 run execute as @a[tag=cine] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1 1.4
execute if score #t cine matches 64 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.0
execute if score #t cine matches 68 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.26
execute if score #t cine matches 72 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
execute if score #t cine matches 72 run title @a[tag=cine] actionbar {"text":"Levier 2 : un point d'ancrage est apparu","color":"aqua"}
