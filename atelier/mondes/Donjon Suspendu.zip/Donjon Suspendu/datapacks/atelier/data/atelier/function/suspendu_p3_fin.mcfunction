# [claude-build] La dalle de la porte 3 a disparu dans le linteau : les blocs affiches sont retires.
kill @e[type=minecraft:block_display,tag=porte3_dalle]
playsound minecraft:block.anvil.land master @a -2 32 -48 2 0.5
