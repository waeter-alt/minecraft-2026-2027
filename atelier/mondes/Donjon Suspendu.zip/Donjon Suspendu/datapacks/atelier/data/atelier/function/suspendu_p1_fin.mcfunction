# [claude-build] La dalle de la porte 1 a disparu dans le linteau : les blocs affiches sont retires.
kill @e[type=minecraft:block_display,tag=porte1_dalle]
playsound minecraft:block.anvil.land master @a 11 32 -41 2 0.5
