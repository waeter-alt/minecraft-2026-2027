# [claude-build] Le bon bloc : un coup de plus ; au dernier, l'enigme est resolue.
scoreboard players add #mq suspendu 1
execute if score #mq suspendu matches 5 run function atelier:suspendu_mus_fin
