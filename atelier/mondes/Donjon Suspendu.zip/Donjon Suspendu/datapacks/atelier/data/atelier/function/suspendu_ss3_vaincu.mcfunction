# [claude-build] Le Gardien des Racines est mort : la sortie de la salle du boss s'ouvre.
scoreboard players set #boss suspendu 3
function atelier:suspendu_ss3_ouvrir_sortie
execute positioned 205 -58 -20 run title @a[distance=..90] title {"text":"Le Gardien est vaincu","color":"green"}
