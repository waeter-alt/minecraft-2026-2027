# [claude-build] Un joueur est arrive sur la plateforme de depart de la salle du boss : annonce, puis le Gardien des Racines apparait apres 5 s (une seule fois).
scoreboard players set #boss suspendu 1
execute positioned 205 -58 -20 run title @a[distance=..90] times 10 60 20
execute positioned 205 -58 -20 run title @a[distance=..90] subtitle {"text":"Tenez-vous prets","color":"gray"}
execute positioned 205 -58 -20 run title @a[distance=..90] title {"text":"Le Gardien se reveille...","color":"gold"}
execute positioned 205 -58 -20 run playsound minecraft:block.beacon.power_select master @a[distance=..90] ~ ~ ~ 3 0.6
schedule function atelier:suspendu_ss3_invoque 100t
