# [claude-build] Lance la cinematique « boss » : la camera, puis les joueurs de la salle (en spectateur, tournes vers la camera).
scoreboard players set #id cine 40
scoreboard players set #t cine 1
scoreboard players set #nb cine 0
summon minecraft:armor_stand -14.500 4.500 -1.500 {Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["cine_cam"],Rotation:[14.036f,28.622f]}
execute positioned -19 -5 14 as @a[distance=..70,gamemode=!spectator] at @s run function atelier:suspendu_cine_joueur
