# [claude-build] Un joueur s'approche de l'ile F : ses 5 ennemi(s) apparaissent (une seule fois).
scoreboard players set #e_F suspendu 1
summon minecraft:zombie 42 -17 56 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
summon minecraft:skeleton 51 -17 55 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
summon minecraft:zombie 63 -17 53 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
summon minecraft:skeleton 58 -17 61 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
summon minecraft:zombie 67 -17 65 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
