# [claude-build] Le coffre de la cle de la derniere porte apparait (au milieu de la cinematique, ou tout de suite) ; on repart d'une case vide, setblock viderait un coffre deja la.
setblock 153 -17 100 minecraft:air
setblock 153 -17 100 minecraft:chest[facing=north]{Items:[{Slot:13b,id:"minecraft:tripwire_hook",count:1,components:{"minecraft:custom_name":'"Clé rouge"',"minecraft:lore":['"Ouvre la porte rouge"']}}]}
execute positioned 153 -17 100 run particle minecraft:happy_villager ~ ~0.5 ~ 0.4 0.4 0.4 0.1 30
execute positioned 153 -17 100 run particle minecraft:end_rod ~ ~1 ~ 0.3 0.6 0.3 0.05 25
execute positioned 153 -17 100 run particle minecraft:end_rod ~ ~4 ~ 0.12 4 0.12 0.01 120 force
execute positioned 153 -17 100 run playsound minecraft:block.chest.open master @a[distance=..64] ~ ~ ~ 2 1
execute positioned 153 -17 100 run title @a[distance=..64] title {"text":"Un coffre est apparu au fond de la salle","color":"gold"}
