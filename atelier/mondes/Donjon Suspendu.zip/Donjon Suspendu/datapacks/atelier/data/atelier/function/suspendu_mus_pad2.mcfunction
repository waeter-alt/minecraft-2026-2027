# [claude-build] Un clic droit sur le bloc musical 2 : on remet sa note ; si la melodie est finie et l'enigme pas resolue, on compte le coup.
setblock 3 14 -35 minecraft:note_block[instrument=chime,note=8,powered=false]
execute positioned 3 14 -35 run particle minecraft:note ~ ~1.2 ~ 0.2 0.2 0.2 1 3
execute if score #mt suspendu matches 0 if score #mok suspendu matches 0 run function atelier:suspendu_mus_joue2
