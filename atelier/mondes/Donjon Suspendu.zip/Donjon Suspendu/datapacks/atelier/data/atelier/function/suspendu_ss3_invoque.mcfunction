# [claude-build] Fait surgir le Gardien des Racines de la lave, au centre de la salle (jamais deux a la fois).
execute positioned 205 -58 -20 unless entity @e[type=donjon:golem,distance=..150] run summon donjon:golem 205.5 -58 -19.5 {Rotation:[180f,0f]}
execute positioned 205 -58 -20 if entity @e[type=donjon:golem,distance=..150] run scoreboard players set #boss suspendu 2
execute positioned 205 -58 -20 unless entity @e[type=donjon:golem,distance=..150] run scoreboard players set #boss suspendu 0
execute positioned 205 -58 -20 run playsound minecraft:entity.ender_dragon.growl master @a[distance=..90] ~ ~ ~ 5 0.6
