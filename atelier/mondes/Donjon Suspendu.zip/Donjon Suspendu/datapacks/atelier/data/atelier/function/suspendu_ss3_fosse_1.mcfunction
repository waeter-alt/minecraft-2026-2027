# [claude-build] Un joueur est tombe dans une fosse du tunnel : on decroche son grappin, chute lente (pas de degats), retour au bord d'ou il est venu.
data modify storage atelier:suspendu chute.uuid set from entity @s UUID
function atelier:suspendu_ss3_decrocher with storage atelier:suspendu chute
effect give @s minecraft:slow_falling 3 0 true
tp @s 83.5 -24.0 -74.5 0 0
title @s actionbar {"text":"Tu es tombé !","color":"red"}
