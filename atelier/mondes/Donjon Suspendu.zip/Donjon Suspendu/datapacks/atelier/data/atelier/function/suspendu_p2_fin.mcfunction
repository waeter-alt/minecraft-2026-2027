# [claude-build] La dalle de la porte 2 a disparu dans le linteau : les blocs affiches sont retires.
kill @e[type=minecraft:block_display,tag=porte2_dalle]
playsound minecraft:block.anvil.land master @a -13 32 -42 2 0.5
