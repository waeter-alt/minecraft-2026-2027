# [claude-build] Rend un joueur : il quitte la camera, retrouve sa place (et son regard) et son mode de jeu. Execute en tant que ce joueur.
spectate
scoreboard players operation #cherche cine = @s cine
tag @s add cine_cible
execute as @e[type=minecraft:marker,tag=cine_retour] if score @s cine = #cherche cine run tp @a[tag=cine_cible,limit=1] @s
execute as @e[type=minecraft:marker,tag=cine_retour] if score @s cine = #cherche cine run kill @s
execute if score @s cine_mode matches 0 run gamemode survival @s
execute if score @s cine_mode matches 1 run gamemode creative @s
execute if score @s cine_mode matches 2 run gamemode adventure @s
tag @s remove cine_cible
tag @s remove cine
