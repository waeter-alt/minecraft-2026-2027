# [claude-build] Pose du donjon, etape 17 sur 18 (le terrain du gabarit : pierre, terre, herbe, air ; puis les salles ; puis la remise a zero).
place template atelier:suspendu_ss2 -66 -63 -64
schedule function atelier:suspendu_pose_2_17 2t
