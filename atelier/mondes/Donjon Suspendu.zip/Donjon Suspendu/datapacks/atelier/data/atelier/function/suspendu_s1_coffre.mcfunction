# [claude-build] Le coffre apparait au centre de la salle, avec la cle de la porte 1.
setblock 0 30 -32 minecraft:air
setblock 0 30 -32 minecraft:chest[facing=south]{Items:[{Slot:13b,id:"minecraft:tripwire_hook",count:1,components:{"minecraft:custom_name":'"Clé bleu"',"minecraft:lore":['"Ouvre la porte bleue"']}}]}
execute positioned 0 30 -32 run particle minecraft:happy_villager ~ ~0.5 ~ 0.4 0.4 0.4 0.1 30
execute positioned 0 30 -32 run playsound minecraft:block.chest.open master @a[distance=..40] ~ ~ ~ 2 1
execute positioned 1 30 -30 run title @a[distance=..40] title {"text":"Un coffre est apparu","color":"gold"}
