# [claude-build] Levier 3 : tous ses ancrages apparaissent tout de suite (sans camera).
function atelier:suspendu_ss2_l3_a1
function atelier:suspendu_ss2_l3_a2
execute positioned 87 -17 -60 run title @a[distance=..40] actionbar {"text":"Levier 3 : un point d'ancrage est apparu","color":"aqua"}
