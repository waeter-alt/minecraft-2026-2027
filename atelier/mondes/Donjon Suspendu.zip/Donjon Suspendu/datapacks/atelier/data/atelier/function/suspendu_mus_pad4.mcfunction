# [claude-build] Un clic droit sur le bloc musical 4 : on remet sa note ; si la melodie est finie et l'enigme pas resolue, on compte le coup.
setblock 3 14 -31 minecraft:note_block[instrument=iron_xylophone,note=12,powered=false]
execute positioned 3 14 -31 run particle minecraft:note ~ ~1.2 ~ 0.2 0.2 0.2 1 3
execute if score #mt suspendu matches 0 if score #mok suspendu matches 0 run function atelier:suspendu_mus_joue4
