# [claude-build] Lance la cinematique « porte1 » : la camera, puis les joueurs de la salle (en spectateur, tournes vers la camera).
scoreboard players set #id cine 21
scoreboard players set #t cine 1
scoreboard players set #nb cine 0
summon minecraft:armor_stand 1.025 34.500 -35.049 {Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["cine_cam"],Rotation:[-118.180f,7.404f]}
execute positioned 1 30 -30 as @a[distance=..45,gamemode=!spectator] at @s run function atelier:suspendu_cine_joueur
