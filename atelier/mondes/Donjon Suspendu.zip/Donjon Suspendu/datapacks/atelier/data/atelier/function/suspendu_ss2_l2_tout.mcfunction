# [claude-build] Levier 2 : tous ses ancrages apparaissent tout de suite (sans camera).
function atelier:suspendu_ss2_l2_a1
execute positioned 62 -16 -16 run title @a[distance=..40] actionbar {"text":"Levier 2 : un point d'ancrage est apparu","color":"aqua"}
