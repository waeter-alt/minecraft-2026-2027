# [claude-build] Un joueur s'approche de l'ile I : ses 2 ennemi(s) apparaissent (une seule fois).
scoreboard players set #e_I suspendu 1
summon minecraft:zombie 152 -17 78 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
summon minecraft:skeleton 136 -17 101 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
