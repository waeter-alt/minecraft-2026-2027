# [claude-build] Levier 1 : l'ancrage 2 sur 2 apparait (avec son pilier s'il est au dessus du vide).
fill 82 -14 -22 82 -6 -22 minecraft:chain[axis=y]
setblock 82 -15 -22 grappin:ancrage
execute positioned 82 -15 -22 run particle minecraft:end_rod ~ ~ ~ 0.3 0.6 0.3 0.05 30
execute positioned 82 -15 -22 run playsound minecraft:block.chain.place master @a[distance=..60] ~ ~ ~ 2 0.8
