# [claude-build] Ouvre la porte m1 (bleue) : une cinematique montre la porte qui se leve (ou elle se leve tout de suite si une cinematique est en cours).
scoreboard players set #pm1 suspendu 1
scoreboard players operation #libre cine = #t cine
execute if score #libre cine matches 0 run function atelier:suspendu_cine_debut_portem1
execute unless score #libre cine matches 0 run function atelier:suspendu_pm1_lever
