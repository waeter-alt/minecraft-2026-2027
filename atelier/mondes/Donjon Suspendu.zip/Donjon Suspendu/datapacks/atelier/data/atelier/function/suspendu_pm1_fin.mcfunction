# [claude-build] La dalle de la porte m1 a disparu dans le linteau : les blocs affiches sont retires.
kill @e[type=minecraft:block_display,tag=portem1_dalle]
playsound minecraft:block.anvil.land master @a 7 4 -10 2 0.5
