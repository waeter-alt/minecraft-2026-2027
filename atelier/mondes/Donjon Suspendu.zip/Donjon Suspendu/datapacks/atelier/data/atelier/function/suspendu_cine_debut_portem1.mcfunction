# [claude-build] Lance la cinematique « portem1 » : la camera, puis les joueurs de la salle (en spectateur, tournes vers la camera).
scoreboard players set #id cine 24
scoreboard players set #t cine 1
scoreboard players set #nb cine 0
summon minecraft:armor_stand 4.000 6.500 -0.500 {Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["cine_cam"],Rotation:[-157.620f,9.268f]}
execute positioned 8 4 -9 as @a[distance=..45,gamemode=!spectator] at @s run function atelier:suspendu_cine_joueur
