# [claude-build] Un joueur est arrive au centre de la salle 1 : trois zombies apparaissent (une seule fois).
scoreboard players set #s1 suspendu 1
summon minecraft:zombie -9 30 -34 {Tags:["suspendu_s1"],PersistenceRequired:1b}
summon minecraft:zombie 10 30 -34 {Tags:["suspendu_s1"],PersistenceRequired:1b}
summon minecraft:zombie 6 30 -24 {Tags:["suspendu_s1"],PersistenceRequired:1b}
execute positioned 1 30 -30 run title @a[distance=..40] times 10 50 20
execute positioned 1 30 -30 run title @a[distance=..40] subtitle {"text":"Le coffre apparaîtra ensuite","color":"gray"}
execute positioned 1 30 -30 run title @a[distance=..40] title {"text":"Vainquez les 3 zombies","color":"red"}
execute positioned 1 30 -30 run playsound minecraft:entity.zombie.ambient master @a[distance=..40] ~ ~ ~ 2 0.7
