# [claude-build] La melodie est rejouee en entier : l'enigme est resolue, toutes les lampes s'allument et le coffre de la cle jaune apparait (on repart d'une case vide, setblock viderait un coffre deja la).
scoreboard players set #mok suspendu 1
setblock 3 16 -37 minecraft:sea_lantern
setblock 3 16 -35 minecraft:sea_lantern
setblock 3 16 -33 minecraft:sea_lantern
setblock 3 16 -31 minecraft:sea_lantern
setblock 3 16 -29 minecraft:sea_lantern
execute positioned 3 14 -40 run playsound minecraft:block.note_block.chime master @a[distance=..40] ~ ~ ~ 2 1.5
execute positioned 3 14 -40 run playsound minecraft:entity.player.levelup master @a[distance=..40] ~ ~ ~ 1 1
setblock 12 13 -36 minecraft:air
setblock 12 13 -36 minecraft:chest[facing=south]{Items:[{Slot:13b,id:"minecraft:tripwire_hook",count:1,components:{"minecraft:custom_name":'"Clé jaune"',"minecraft:lore":['"Ouvre la porte jaune"']}}]}
execute positioned 12 13 -36 run particle minecraft:happy_villager ~ ~0.5 ~ 0.4 0.4 0.4 0.1 30
execute positioned 12 13 -36 run title @a[distance=..40] title {"text":"Un coffre est apparu au fond de la salle","color":"gold"}
