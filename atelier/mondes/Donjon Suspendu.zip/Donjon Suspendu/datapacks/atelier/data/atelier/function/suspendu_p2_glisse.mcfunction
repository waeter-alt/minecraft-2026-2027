# [claude-build] La dalle de la porte 2 monte de 8.6 blocs en 36 ticks (le client interpole : mouvement continu).
execute as @e[type=minecraft:block_display,tag=porte2_dalle] run data merge entity @s {start_interpolation:0,interpolation_duration:36,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],scale:[0.998f,0.998f,0.998f],translation:[0.001f,8.601f,0.001f]}}
playsound minecraft:block.grindstone.use master @a -13 32 -42 2 0.5
schedule function atelier:suspendu_p2_fin 38t
