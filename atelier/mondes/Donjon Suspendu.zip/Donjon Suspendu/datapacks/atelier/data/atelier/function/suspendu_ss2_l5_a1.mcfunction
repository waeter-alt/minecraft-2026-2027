# [claude-build] Levier 5 : l'ancrage 1 sur 4 apparait (avec son pilier s'il est au dessus du vide).
fill 74 -61 91 76 -19 91 minecraft:stone_bricks
fill 73 -61 92 77 -19 92 minecraft:stone_bricks
fill 73 -61 93 77 -19 93 minecraft:stone_bricks
fill 73 -61 94 77 -19 94 minecraft:stone_bricks
fill 74 -61 95 76 -19 95 minecraft:stone_bricks
fill 74 -22 91 76 -22 91 minecraft:chiseled_stone_bricks
fill 73 -22 92 77 -22 92 minecraft:chiseled_stone_bricks
fill 73 -22 93 77 -22 93 minecraft:chiseled_stone_bricks
fill 73 -22 94 77 -22 94 minecraft:chiseled_stone_bricks
fill 74 -22 95 76 -22 95 minecraft:chiseled_stone_bricks
fill 74 -26 91 76 -26 91 minecraft:chiseled_stone_bricks
fill 73 -26 92 77 -26 92 minecraft:chiseled_stone_bricks
fill 73 -26 93 77 -26 93 minecraft:chiseled_stone_bricks
fill 73 -26 94 77 -26 94 minecraft:chiseled_stone_bricks
fill 74 -26 95 76 -26 95 minecraft:chiseled_stone_bricks
fill 74 -30 91 76 -30 91 minecraft:chiseled_stone_bricks
fill 73 -30 92 77 -30 92 minecraft:chiseled_stone_bricks
fill 73 -30 93 77 -30 93 minecraft:chiseled_stone_bricks
fill 73 -30 94 77 -30 94 minecraft:chiseled_stone_bricks
fill 74 -30 95 76 -30 95 minecraft:chiseled_stone_bricks
fill 74 -34 91 76 -34 91 minecraft:chiseled_stone_bricks
fill 73 -34 92 77 -34 92 minecraft:chiseled_stone_bricks
fill 73 -34 93 77 -34 93 minecraft:chiseled_stone_bricks
fill 73 -34 94 77 -34 94 minecraft:chiseled_stone_bricks
fill 74 -34 95 76 -34 95 minecraft:chiseled_stone_bricks
fill 74 -38 91 76 -38 91 minecraft:chiseled_stone_bricks
fill 73 -38 92 77 -38 92 minecraft:chiseled_stone_bricks
fill 73 -38 93 77 -38 93 minecraft:chiseled_stone_bricks
fill 73 -38 94 77 -38 94 minecraft:chiseled_stone_bricks
fill 74 -38 95 76 -38 95 minecraft:chiseled_stone_bricks
fill 74 -42 91 76 -42 91 minecraft:chiseled_stone_bricks
fill 73 -42 92 77 -42 92 minecraft:chiseled_stone_bricks
fill 73 -42 93 77 -42 93 minecraft:chiseled_stone_bricks
fill 73 -42 94 77 -42 94 minecraft:chiseled_stone_bricks
fill 74 -42 95 76 -42 95 minecraft:chiseled_stone_bricks
fill 74 -46 91 76 -46 91 minecraft:chiseled_stone_bricks
fill 73 -46 92 77 -46 92 minecraft:chiseled_stone_bricks
fill 73 -46 93 77 -46 93 minecraft:chiseled_stone_bricks
fill 73 -46 94 77 -46 94 minecraft:chiseled_stone_bricks
fill 74 -46 95 76 -46 95 minecraft:chiseled_stone_bricks
fill 74 -50 91 76 -50 91 minecraft:chiseled_stone_bricks
fill 73 -50 92 77 -50 92 minecraft:chiseled_stone_bricks
fill 73 -50 93 77 -50 93 minecraft:chiseled_stone_bricks
fill 73 -50 94 77 -50 94 minecraft:chiseled_stone_bricks
fill 74 -50 95 76 -50 95 minecraft:chiseled_stone_bricks
fill 74 -54 91 76 -54 91 minecraft:chiseled_stone_bricks
fill 73 -54 92 77 -54 92 minecraft:chiseled_stone_bricks
fill 73 -54 93 77 -54 93 minecraft:chiseled_stone_bricks
fill 73 -54 94 77 -54 94 minecraft:chiseled_stone_bricks
fill 74 -54 95 76 -54 95 minecraft:chiseled_stone_bricks
fill 74 -58 91 76 -58 91 minecraft:chiseled_stone_bricks
fill 73 -58 92 77 -58 92 minecraft:chiseled_stone_bricks
fill 73 -58 93 77 -58 93 minecraft:chiseled_stone_bricks
fill 73 -58 94 77 -58 94 minecraft:chiseled_stone_bricks
fill 74 -58 95 76 -58 95 minecraft:chiseled_stone_bricks
setblock 73 -18 92 minecraft:andesite
setblock 73 -18 93 minecraft:stone
setblock 73 -18 94 minecraft:stone
setblock 74 -18 91 minecraft:stone
setblock 74 -18 92 minecraft:tuff
setblock 74 -18 93 minecraft:andesite
setblock 74 -18 94 minecraft:stone
setblock 74 -18 95 minecraft:tuff
setblock 75 -18 91 minecraft:stone
setblock 75 -18 92 minecraft:stone
setblock 75 -18 93 minecraft:stone
setblock 75 -18 94 minecraft:stone
setblock 75 -18 95 minecraft:mossy_cobblestone
setblock 76 -18 91 minecraft:andesite
setblock 76 -18 92 minecraft:stone
setblock 76 -18 93 minecraft:tuff
setblock 76 -18 94 minecraft:stone
setblock 76 -18 95 minecraft:mossy_cobblestone
setblock 77 -18 92 minecraft:stone
setblock 77 -18 93 minecraft:stone
setblock 77 -18 94 minecraft:stone
setblock 75 -16 93 minecraft:light[level=13]
execute positioned 75 -17 93 run particle minecraft:poof ~ ~ ~ 1.2 0.2 1.2 0.05 40
execute positioned 75 -18 93 run playsound minecraft:block.stone.place master @a[distance=..60] ~ ~ ~ 3 0.6
fill 75 -14 93 75 -6 93 minecraft:chain[axis=y]
setblock 75 -15 93 grappin:ancrage
execute positioned 75 -15 93 run particle minecraft:end_rod ~ ~ ~ 0.3 0.6 0.3 0.05 30
execute positioned 75 -15 93 run playsound minecraft:block.chain.place master @a[distance=..60] ~ ~ ~ 2 0.8
