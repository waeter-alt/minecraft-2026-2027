# [claude-build] Chaque tick pendant la melodie : on allume une lampe tous les 25 ticks, avec sa note, et on l'eteint 15 ticks plus tard ; la melodie finie, le joueur peut jouer.
scoreboard players add #mt suspendu 1
execute if score #mt suspendu matches 20 run setblock 3 16 -35 minecraft:sea_lantern
execute if score #mt suspendu matches 20 positioned 3 14 -35 run playsound minecraft:block.note_block.chime master @a[distance=..30] ~ ~ ~ 2 0.8409
execute if score #mt suspendu matches 35 run setblock 3 16 -35 minecraft:blue_concrete
execute if score #mt suspendu matches 45 run setblock 3 16 -31 minecraft:sea_lantern
execute if score #mt suspendu matches 45 positioned 3 14 -31 run playsound minecraft:block.note_block.iron_xylophone master @a[distance=..30] ~ ~ ~ 2 1.0595
execute if score #mt suspendu matches 60 run setblock 3 16 -31 minecraft:yellow_concrete
execute if score #mt suspendu matches 70 run setblock 3 16 -37 minecraft:sea_lantern
execute if score #mt suspendu matches 70 positioned 3 14 -37 run playsound minecraft:block.note_block.bell master @a[distance=..30] ~ ~ ~ 2 0.7071
execute if score #mt suspendu matches 85 run setblock 3 16 -37 minecraft:red_concrete
execute if score #mt suspendu matches 95 run setblock 3 16 -29 minecraft:sea_lantern
execute if score #mt suspendu matches 95 positioned 3 14 -29 run playsound minecraft:block.note_block.xylophone master @a[distance=..30] ~ ~ ~ 2 1.2599
execute if score #mt suspendu matches 110 run setblock 3 16 -29 minecraft:purple_concrete
execute if score #mt suspendu matches 120 run setblock 3 16 -33 minecraft:sea_lantern
execute if score #mt suspendu matches 120 positioned 3 14 -33 run playsound minecraft:block.note_block.bit master @a[distance=..30] ~ ~ ~ 2 0.9439
execute if score #mt suspendu matches 135 run setblock 3 16 -33 minecraft:lime_concrete
execute if score #mt suspendu matches 155 run scoreboard players set #mt suspendu 0
