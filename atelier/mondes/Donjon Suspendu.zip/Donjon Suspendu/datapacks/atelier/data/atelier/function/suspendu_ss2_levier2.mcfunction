# [claude-build] Le levier 2 est tire : ses ancrages apparaissent (un bloc d'ancrage et sa chaine, du plafond), avec un son et des particules.
scoreboard players set #l2 suspendu 1
fill 88 -14 -56 88 -6 -56 minecraft:chain[axis=y]
setblock 88 -15 -56 grappin:ancrage
execute positioned 88 -15 -56 run particle minecraft:end_rod ~ ~ ~ 0.3 0.6 0.3 0.05 30
execute positioned 88 -15 -56 run playsound minecraft:block.chain.place master @a[distance=..60] ~ ~ ~ 2 0.8
execute positioned 62 -16 -16 run playsound minecraft:block.beacon.activate master @a[distance=..40] ~ ~ ~ 1 1.4
execute positioned 62 -16 -16 run title @a[distance=..40] actionbar {"text":"Levier 2 : un point d'ancrage est apparu","color":"aqua"}
