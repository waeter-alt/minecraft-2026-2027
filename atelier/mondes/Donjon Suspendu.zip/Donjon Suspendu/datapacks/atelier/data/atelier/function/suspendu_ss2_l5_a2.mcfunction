# [claude-build] Levier 5 : l'ancrage 2 sur 4 apparait (avec son pilier s'il est au dessus du vide).
fill 96 -61 89 98 -19 89 minecraft:stone_bricks
fill 95 -61 90 99 -19 90 minecraft:stone_bricks
fill 95 -61 91 99 -19 91 minecraft:stone_bricks
fill 95 -61 92 99 -19 92 minecraft:stone_bricks
fill 96 -61 93 98 -19 93 minecraft:stone_bricks
fill 96 -22 89 98 -22 89 minecraft:chiseled_stone_bricks
fill 95 -22 90 99 -22 90 minecraft:chiseled_stone_bricks
fill 95 -22 91 99 -22 91 minecraft:chiseled_stone_bricks
fill 95 -22 92 99 -22 92 minecraft:chiseled_stone_bricks
fill 96 -22 93 98 -22 93 minecraft:chiseled_stone_bricks
fill 96 -26 89 98 -26 89 minecraft:chiseled_stone_bricks
fill 95 -26 90 99 -26 90 minecraft:chiseled_stone_bricks
fill 95 -26 91 99 -26 91 minecraft:chiseled_stone_bricks
fill 95 -26 92 99 -26 92 minecraft:chiseled_stone_bricks
fill 96 -26 93 98 -26 93 minecraft:chiseled_stone_bricks
fill 96 -30 89 98 -30 89 minecraft:chiseled_stone_bricks
fill 95 -30 90 99 -30 90 minecraft:chiseled_stone_bricks
fill 95 -30 91 99 -30 91 minecraft:chiseled_stone_bricks
fill 95 -30 92 99 -30 92 minecraft:chiseled_stone_bricks
fill 96 -30 93 98 -30 93 minecraft:chiseled_stone_bricks
fill 96 -34 89 98 -34 89 minecraft:chiseled_stone_bricks
fill 95 -34 90 99 -34 90 minecraft:chiseled_stone_bricks
fill 95 -34 91 99 -34 91 minecraft:chiseled_stone_bricks
fill 95 -34 92 99 -34 92 minecraft:chiseled_stone_bricks
fill 96 -34 93 98 -34 93 minecraft:chiseled_stone_bricks
fill 96 -38 89 98 -38 89 minecraft:chiseled_stone_bricks
fill 95 -38 90 99 -38 90 minecraft:chiseled_stone_bricks
fill 95 -38 91 99 -38 91 minecraft:chiseled_stone_bricks
fill 95 -38 92 99 -38 92 minecraft:chiseled_stone_bricks
fill 96 -38 93 98 -38 93 minecraft:chiseled_stone_bricks
fill 96 -42 89 98 -42 89 minecraft:chiseled_stone_bricks
fill 95 -42 90 99 -42 90 minecraft:chiseled_stone_bricks
fill 95 -42 91 99 -42 91 minecraft:chiseled_stone_bricks
fill 95 -42 92 99 -42 92 minecraft:chiseled_stone_bricks
fill 96 -42 93 98 -42 93 minecraft:chiseled_stone_bricks
fill 96 -46 89 98 -46 89 minecraft:chiseled_stone_bricks
fill 95 -46 90 99 -46 90 minecraft:chiseled_stone_bricks
fill 95 -46 91 99 -46 91 minecraft:chiseled_stone_bricks
fill 95 -46 92 99 -46 92 minecraft:chiseled_stone_bricks
fill 96 -46 93 98 -46 93 minecraft:chiseled_stone_bricks
fill 96 -50 89 98 -50 89 minecraft:chiseled_stone_bricks
fill 95 -50 90 99 -50 90 minecraft:chiseled_stone_bricks
fill 95 -50 91 99 -50 91 minecraft:chiseled_stone_bricks
fill 95 -50 92 99 -50 92 minecraft:chiseled_stone_bricks
fill 96 -50 93 98 -50 93 minecraft:chiseled_stone_bricks
fill 96 -54 89 98 -54 89 minecraft:chiseled_stone_bricks
fill 95 -54 90 99 -54 90 minecraft:chiseled_stone_bricks
fill 95 -54 91 99 -54 91 minecraft:chiseled_stone_bricks
fill 95 -54 92 99 -54 92 minecraft:chiseled_stone_bricks
fill 96 -54 93 98 -54 93 minecraft:chiseled_stone_bricks
fill 96 -58 89 98 -58 89 minecraft:chiseled_stone_bricks
fill 95 -58 90 99 -58 90 minecraft:chiseled_stone_bricks
fill 95 -58 91 99 -58 91 minecraft:chiseled_stone_bricks
fill 95 -58 92 99 -58 92 minecraft:chiseled_stone_bricks
fill 96 -58 93 98 -58 93 minecraft:chiseled_stone_bricks
setblock 95 -18 90 minecraft:stone
setblock 95 -18 91 minecraft:andesite
setblock 95 -18 92 minecraft:andesite
setblock 96 -18 89 minecraft:stone
setblock 96 -18 90 minecraft:stone
setblock 96 -18 91 minecraft:mossy_cobblestone
setblock 96 -18 92 minecraft:stone
setblock 96 -18 93 minecraft:tuff
setblock 97 -18 89 minecraft:andesite
setblock 97 -18 90 minecraft:tuff
setblock 97 -18 91 minecraft:andesite
setblock 97 -18 92 minecraft:stone
setblock 97 -18 93 minecraft:stone
setblock 98 -18 89 minecraft:stone
setblock 98 -18 90 minecraft:stone
setblock 98 -18 91 minecraft:stone
setblock 98 -18 92 minecraft:stone
setblock 98 -18 93 minecraft:stone
setblock 99 -18 90 minecraft:tuff
setblock 99 -18 91 minecraft:tuff
setblock 99 -18 92 minecraft:stone
setblock 97 -16 91 minecraft:light[level=13]
execute positioned 97 -17 91 run particle minecraft:poof ~ ~ ~ 1.2 0.2 1.2 0.05 40
execute positioned 97 -18 91 run playsound minecraft:block.stone.place master @a[distance=..60] ~ ~ ~ 3 0.6
fill 97 -14 91 97 -6 91 minecraft:chain[axis=y]
setblock 97 -15 91 grappin:ancrage
execute positioned 97 -15 91 run particle minecraft:end_rod ~ ~ ~ 0.3 0.6 0.3 0.05 30
execute positioned 97 -15 91 run playsound minecraft:block.chain.place master @a[distance=..60] ~ ~ ~ 2 0.8
