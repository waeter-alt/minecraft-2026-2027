# [claude-build] Levier 1 : tous ses ancrages apparaissent tout de suite (sans camera).
function atelier:suspendu_ss2_l1_a1
function atelier:suspendu_ss2_l1_a2
execute positioned 122 -17 -44 run title @a[distance=..40] actionbar {"text":"Levier 1 : un point d'ancrage est apparu","color":"aqua"}
