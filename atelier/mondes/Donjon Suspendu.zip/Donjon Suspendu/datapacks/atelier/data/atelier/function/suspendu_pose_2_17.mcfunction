# [claude-build] Pose du donjon, etape 18 sur 18 (le terrain du gabarit : pierre, terre, herbe, air ; puis les salles ; puis la remise a zero).
place template atelier:suspendu_ss3 -5 -63 -84
kill @e[type=item]
function atelier:suspendu_reset
schedule function atelier:suspendu_pose_3 100t
