# [claude-build] Levier 5 : l'ancrage 3 sur 4 apparait (avec son pilier s'il est au dessus du vide).
fill 118 -61 87 120 -19 87 minecraft:stone_bricks
fill 117 -61 88 121 -19 88 minecraft:stone_bricks
fill 117 -61 89 121 -19 89 minecraft:stone_bricks
fill 117 -61 90 121 -19 90 minecraft:stone_bricks
fill 118 -61 91 120 -19 91 minecraft:stone_bricks
fill 118 -22 87 120 -22 87 minecraft:chiseled_stone_bricks
fill 117 -22 88 121 -22 88 minecraft:chiseled_stone_bricks
fill 117 -22 89 121 -22 89 minecraft:chiseled_stone_bricks
fill 117 -22 90 121 -22 90 minecraft:chiseled_stone_bricks
fill 118 -22 91 120 -22 91 minecraft:chiseled_stone_bricks
fill 118 -26 87 120 -26 87 minecraft:chiseled_stone_bricks
fill 117 -26 88 121 -26 88 minecraft:chiseled_stone_bricks
fill 117 -26 89 121 -26 89 minecraft:chiseled_stone_bricks
fill 117 -26 90 121 -26 90 minecraft:chiseled_stone_bricks
fill 118 -26 91 120 -26 91 minecraft:chiseled_stone_bricks
fill 118 -30 87 120 -30 87 minecraft:chiseled_stone_bricks
fill 117 -30 88 121 -30 88 minecraft:chiseled_stone_bricks
fill 117 -30 89 121 -30 89 minecraft:chiseled_stone_bricks
fill 117 -30 90 121 -30 90 minecraft:chiseled_stone_bricks
fill 118 -30 91 120 -30 91 minecraft:chiseled_stone_bricks
fill 118 -34 87 120 -34 87 minecraft:chiseled_stone_bricks
fill 117 -34 88 121 -34 88 minecraft:chiseled_stone_bricks
fill 117 -34 89 121 -34 89 minecraft:chiseled_stone_bricks
fill 117 -34 90 121 -34 90 minecraft:chiseled_stone_bricks
fill 118 -34 91 120 -34 91 minecraft:chiseled_stone_bricks
fill 118 -38 87 120 -38 87 minecraft:chiseled_stone_bricks
fill 117 -38 88 121 -38 88 minecraft:chiseled_stone_bricks
fill 117 -38 89 121 -38 89 minecraft:chiseled_stone_bricks
fill 117 -38 90 121 -38 90 minecraft:chiseled_stone_bricks
fill 118 -38 91 120 -38 91 minecraft:chiseled_stone_bricks
fill 118 -42 87 120 -42 87 minecraft:chiseled_stone_bricks
fill 117 -42 88 121 -42 88 minecraft:chiseled_stone_bricks
fill 117 -42 89 121 -42 89 minecraft:chiseled_stone_bricks
fill 117 -42 90 121 -42 90 minecraft:chiseled_stone_bricks
fill 118 -42 91 120 -42 91 minecraft:chiseled_stone_bricks
fill 118 -46 87 120 -46 87 minecraft:chiseled_stone_bricks
fill 117 -46 88 121 -46 88 minecraft:chiseled_stone_bricks
fill 117 -46 89 121 -46 89 minecraft:chiseled_stone_bricks
fill 117 -46 90 121 -46 90 minecraft:chiseled_stone_bricks
fill 118 -46 91 120 -46 91 minecraft:chiseled_stone_bricks
fill 118 -50 87 120 -50 87 minecraft:chiseled_stone_bricks
fill 117 -50 88 121 -50 88 minecraft:chiseled_stone_bricks
fill 117 -50 89 121 -50 89 minecraft:chiseled_stone_bricks
fill 117 -50 90 121 -50 90 minecraft:chiseled_stone_bricks
fill 118 -50 91 120 -50 91 minecraft:chiseled_stone_bricks
fill 118 -54 87 120 -54 87 minecraft:chiseled_stone_bricks
fill 117 -54 88 121 -54 88 minecraft:chiseled_stone_bricks
fill 117 -54 89 121 -54 89 minecraft:chiseled_stone_bricks
fill 117 -54 90 121 -54 90 minecraft:chiseled_stone_bricks
fill 118 -54 91 120 -54 91 minecraft:chiseled_stone_bricks
fill 118 -58 87 120 -58 87 minecraft:chiseled_stone_bricks
fill 117 -58 88 121 -58 88 minecraft:chiseled_stone_bricks
fill 117 -58 89 121 -58 89 minecraft:chiseled_stone_bricks
fill 117 -58 90 121 -58 90 minecraft:chiseled_stone_bricks
fill 118 -58 91 120 -58 91 minecraft:chiseled_stone_bricks
setblock 117 -18 88 minecraft:tuff
setblock 117 -18 89 minecraft:stone
setblock 117 -18 90 minecraft:stone
setblock 118 -18 87 minecraft:stone
setblock 118 -18 88 minecraft:stone
setblock 118 -18 89 minecraft:stone
setblock 118 -18 90 minecraft:andesite
setblock 118 -18 91 minecraft:stone
setblock 119 -18 87 minecraft:tuff
setblock 119 -18 88 minecraft:stone
setblock 119 -18 89 minecraft:stone
setblock 119 -18 90 minecraft:andesite
setblock 119 -18 91 minecraft:stone
setblock 120 -18 87 minecraft:tuff
setblock 120 -18 88 minecraft:stone
setblock 120 -18 89 minecraft:stone
setblock 120 -18 90 minecraft:andesite
setblock 120 -18 91 minecraft:andesite
setblock 121 -18 88 minecraft:andesite
setblock 121 -18 89 minecraft:andesite
setblock 121 -18 90 minecraft:stone
setblock 119 -16 89 minecraft:light[level=13]
execute positioned 119 -17 89 run particle minecraft:poof ~ ~ ~ 1.2 0.2 1.2 0.05 40
execute positioned 119 -18 89 run playsound minecraft:block.stone.place master @a[distance=..60] ~ ~ ~ 3 0.6
fill 119 -14 89 119 -6 89 minecraft:chain[axis=y]
setblock 119 -15 89 donjon:ancrage
execute positioned 119 -15 89 run particle minecraft:end_rod ~ ~ ~ 0.3 0.6 0.3 0.05 30
execute positioned 119 -15 89 run playsound minecraft:block.chain.place master @a[distance=..60] ~ ~ ~ 2 0.8
