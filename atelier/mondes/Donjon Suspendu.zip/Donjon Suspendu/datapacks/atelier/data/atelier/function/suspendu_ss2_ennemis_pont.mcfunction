# [claude-build] Un joueur s'approche de l'ile PONT : ses 2 ennemi(s) apparaissent (une seule fois).
scoreboard players set #e_PONT suspendu 1
summon minecraft:zombie 85 -17 57 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
summon minecraft:skeleton 102 -17 54 {Tags:["suspendu_ss2e"],PersistenceRequired:1b}
