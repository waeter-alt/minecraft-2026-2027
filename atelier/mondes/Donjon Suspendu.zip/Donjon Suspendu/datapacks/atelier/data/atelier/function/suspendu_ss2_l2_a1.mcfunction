# [claude-build] Levier 2 : l'ancrage 1 sur 1 apparait (avec son pilier s'il est au dessus du vide).
fill 88 -14 -56 88 -6 -56 minecraft:chain[axis=y]
setblock 88 -15 -56 donjon:ancrage
execute positioned 88 -15 -56 run particle minecraft:end_rod ~ ~ ~ 0.3 0.6 0.3 0.05 30
execute positioned 88 -15 -56 run playsound minecraft:block.chain.place master @a[distance=..60] ~ ~ ~ 2 0.8
