# [claude-build] Les trois zombies sont vaincus : une cinematique montre le coffre qui apparait (ou le coffre apparait tout de suite si une autre cinematique est en cours).
scoreboard players set #s1 suspendu 2
scoreboard players operation #libre cine = #t cine
execute if score #libre cine matches 0 run function atelier:suspendu_cine_debut_coffre
execute unless score #libre cine matches 0 run function atelier:suspendu_s1_coffre
