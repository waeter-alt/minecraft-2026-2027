# [claude-build] Le coffre du grappin apparait sur l'estrade (au milieu de la cinematique, ou tout de suite) ; on repart d'une case vide, setblock viderait un coffre deja la.
setblock -19 -5 14 minecraft:air
setblock -19 -5 14 minecraft:chest[facing=north]{Items:[{Slot:13b,id:"grappin:grappin",count:1}]}
execute positioned -19 -5 14 run particle minecraft:happy_villager ~ ~0.5 ~ 0.4 0.4 0.4 0.1 30
execute positioned -19 -5 14 run particle minecraft:end_rod ~ ~1 ~ 0.3 0.6 0.3 0.05 25
execute positioned -19 -5 14 run playsound minecraft:block.chest.open master @a[distance=..60] ~ ~ ~ 2 1
execute positioned -19 -5 14 run title @a[distance=..60] title {"text":"Un coffre est apparu sur l'estrade","color":"gold"}
