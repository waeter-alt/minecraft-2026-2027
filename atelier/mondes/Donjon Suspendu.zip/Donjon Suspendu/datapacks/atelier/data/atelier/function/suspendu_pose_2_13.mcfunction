# [claude-build] Pose du donjon, etape 14 sur 18 (le terrain du gabarit : pierre, terre, herbe, air ; puis les salles ; puis la remise a zero).
fill 205 61 -24 235 63 6 minecraft:air
fill 205 61 7 235 63 37 minecraft:air
fill 205 61 38 235 63 68 minecraft:air
fill 205 61 69 235 63 99 minecraft:air
fill 205 61 100 235 63 121 minecraft:air
fill 236 30 -86 261 60 -56 minecraft:air
fill 236 30 -55 261 60 -25 minecraft:air
fill 236 30 -24 261 60 6 minecraft:air
fill 236 30 7 261 60 37 minecraft:air
fill 236 30 38 261 60 68 minecraft:air
fill 236 30 69 261 60 99 minecraft:air
fill 236 30 100 261 60 121 minecraft:air
fill 236 61 -86 261 63 -56 minecraft:air
fill 236 61 -55 261 63 -25 minecraft:air
fill 236 61 -24 261 63 6 minecraft:air
fill 236 61 7 261 63 37 minecraft:air
fill 236 61 38 261 63 68 minecraft:air
fill 236 61 69 261 63 99 minecraft:air
fill 236 61 100 261 63 121 minecraft:air
schedule function atelier:suspendu_pose_2_14 2t
