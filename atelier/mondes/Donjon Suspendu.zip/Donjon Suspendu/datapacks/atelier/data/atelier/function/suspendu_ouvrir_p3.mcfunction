# [claude-build] Ouvre la porte 3 (rouge) avec sa cle : la cle est consommee et la dalle se leve tout de suite, sans cinematique.
clear @s minecraft:tripwire_hook[minecraft:custom_name='"Clé rouge"'] 1
scoreboard players set #p3 suspendu 1
function atelier:suspendu_p3_lever
