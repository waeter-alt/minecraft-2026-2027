# [claude-build] Ouvre la porte 3 (rouge) : une cinematique montre la porte qui se leve (ou elle se leve tout de suite si une cinematique est en cours).
clear @s minecraft:tripwire_hook[minecraft:custom_name='"Clé rouge"'] 1
scoreboard players set #p3 suspendu 1
scoreboard players operation #libre cine = #t cine
execute if score #libre cine matches 0 run function atelier:suspendu_cine_debut_porte3
execute unless score #libre cine matches 0 run function atelier:suspendu_p3_lever
