# [claude-build] pose du bassin de test de la cape
fill 2 -60 2 59 -48 35 air
fill 2 -47 2 59 -35 35 air
fill 2 -34 2 59 -20 35 air
fill 2 -19 2 59 -8 35 air
fill 4 -60 4 43 -46 33 stone_bricks
fill 6 -59 6 41 -48 31 water
fill 6 -47 6 41 -46 31 air
fill 6 -60 6 41 -60 31 smooth_stone
fill 29 -59 6 29 -59 31 sandstone
fill 30 -59 6 30 -58 31 sandstone
fill 31 -59 6 31 -57 31 sandstone
fill 32 -59 6 32 -56 31 sandstone
fill 33 -59 6 33 -55 31 sandstone
fill 34 -59 6 34 -54 31 sandstone
fill 35 -59 6 35 -53 31 sandstone
fill 36 -59 6 36 -52 31 sandstone
fill 37 -59 6 37 -51 31 sandstone
fill 38 -59 6 38 -50 31 sandstone
fill 39 -59 6 39 -49 31 sandstone
fill 40 -59 6 40 -48 31 sandstone
fill 41 -59 6 41 -47 31 sandstone
fill 9 -59 9 10 -49 10 stone_bricks
fill 9 -59 21 10 -49 22 stone_bricks
fill 12 -59 15 13 -49 16 stone_bricks
fill 15 -59 9 16 -49 10 stone_bricks
fill 15 -59 21 16 -49 22 stone_bricks
fill 21 -59 6 25 -55 31 stone_bricks
fill 22 -58 6 24 -56 31 water
fill 6 -59 26 9 -57 29 stone
fill 6 -59 26 9 -59 29 deepslate
fill 7 -58 27 8 -58 28 iron_ore
setblock 18 -60 18 gold_block
summon drowned 18.5 -59 21.5 {NoAI:1b,PersistenceRequired:1b,CustomName:'"Cible a 3 blocs"',Silent:1b}
summon drowned 18.5 -59 22.5 {NoAI:1b,PersistenceRequired:1b,CustomName:'"Cible a 4 blocs"',Silent:1b}
summon drowned 18.5 -59 24.5 {NoAI:1b,PersistenceRequired:1b,CustomName:'"Cible a 6 blocs"',Silent:1b}
setblock 23 -45 4 grappin:ancrage
setblock 12 -48 15 grappin:ancrage
setblock 23 -54 18 grappin:ancrage
fill 13 -44 24 19 -14 30 lime_stained_glass
fill 14 -44 25 18 -15 29 air
setblock 16 -15 27 grappin:ancrage
fill 24 -44 24 30 -12 30 yellow_stained_glass
fill 25 -44 25 29 -13 29 air
setblock 27 -13 27 grappin:ancrage
fill 24 -44 8 30 -10 14 red_stained_glass
fill 25 -44 9 29 -11 13 air
setblock 27 -11 11 grappin:ancrage
setblock 8 -60 10 sea_lantern
setblock 8 -60 20 sea_lantern
setblock 8 -60 30 sea_lantern
setblock 16 -60 10 sea_lantern
setblock 16 -60 20 sea_lantern
setblock 16 -60 30 sea_lantern
setblock 32 -60 10 sea_lantern
setblock 32 -60 20 sea_lantern
setblock 32 -60 30 sea_lantern
fill 44 -60 18 44 -46 20 stone_bricks
fill 45 -60 18 45 -47 20 stone_bricks
fill 46 -60 18 46 -48 20 stone_bricks
fill 47 -60 18 47 -49 20 stone_bricks
fill 48 -60 18 48 -50 20 stone_bricks
fill 49 -60 18 49 -51 20 stone_bricks
fill 50 -60 18 50 -52 20 stone_bricks
fill 51 -60 18 51 -53 20 stone_bricks
fill 52 -60 18 52 -54 20 stone_bricks
fill 53 -60 18 53 -55 20 stone_bricks
fill 54 -60 18 54 -56 20 stone_bricks
fill 55 -60 18 55 -57 20 stone_bricks
fill 56 -60 18 56 -58 20 stone_bricks
fill 57 -60 18 57 -59 20 stone_bricks
fill 58 -60 18 58 -60 20 stone_bricks
gamerule doMobSpawning false
gamerule doDaylightCycle false
gamerule doWeatherCycle false
gamerule commandBlockOutput false
time set day
weather clear
function atelier:cape_kit
tellraw @a [{"text":"Le bassin de test de la cape est pret. Entrée : ","color":"green"},{"text":"[/tp @s 2 -60 18 0 0]","color":"aqua","underlined":true,"clickEvent":{"action":"run_command","value":"/tp @s 2 -60 18 0 0"},"hoverEvent":{"action":"show_text","contents":"Cliquer pour y aller"}}]
tellraw @a [{"text":"Equipe la cape dans l'emplacement cape d'Accessories. Nage rapide : dans l'eau, avance dans la direction du regard (sprint = elan). Leste : touche V. Tourbillon : clic gauche en nage rapide.","color":"yellow"}]
tellraw @a [{"text":"A essayer : ","color":"gray"},{"text":"plage (marcher leste), slalom, tunnel, minage au fond (nord-ouest), cibles autour de l'or, grappin sous l'eau.","color":"white"}]
tellraw @a [{"text":"Bond : ","color":"gray"},{"text":"les tubes de verre au dessus de l'eau cachent un ancrage hors de portee depuis la surface. Jaillis de l'eau en nage rapide et tire au grappin en l'air. Vert : un bond ; jaune : en sprint ; rouge : sprint + tourbillon juste avant de sortir (hauteurs estimees).","color":"white"}]
