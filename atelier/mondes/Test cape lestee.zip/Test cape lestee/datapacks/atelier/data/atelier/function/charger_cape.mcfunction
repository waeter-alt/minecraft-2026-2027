# [claude-build] Pose automatique, une seule fois (drapeau #cape).
scoreboard objectives add atelier dummy
execute unless score #cape atelier matches 1 run schedule function atelier:cape_pose 100t
scoreboard players set #cape atelier 1
