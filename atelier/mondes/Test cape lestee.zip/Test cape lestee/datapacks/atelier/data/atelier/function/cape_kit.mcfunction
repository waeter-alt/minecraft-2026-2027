# [claude-build] equipement de test
execute as @a run function atelier:cape_kit_un
