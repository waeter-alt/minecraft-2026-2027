# [claude-build] La porte du Vestiaire a fini de monter : le passage est libre.
fill -62 23 -56 -62 27 -52 minecraft:air replace minecraft:barrier
