# [claude-build] Un joueur entre : les monstres de « b3 » apparaissent (une seule fois).
scoreboard players set #b3 station 1
summon minecraft:blaze 80 -1 -162 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned 80 -1 -162 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:blaze 102 -1 -122 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned 102 -1 -122 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:blaze 90 -1 -122 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned 90 -1 -122 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
