# [claude-build] Pose de la station, etape 17 sur 20.
place template atelier:station_b 31 -32 -169
schedule function atelier:station_pose_2_17 2t
