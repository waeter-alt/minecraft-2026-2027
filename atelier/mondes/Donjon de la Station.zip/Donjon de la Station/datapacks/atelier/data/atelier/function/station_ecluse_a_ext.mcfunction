# [claude-build] Ecluse A, cote Cuve : la vanne interieure se ferme, le sas prend le niveau de la Cuve, la vanne exterieure s'ouvre.
scoreboard players set #ecA station 1
setblock -41 2 -146 minecraft:iron_bars[waterlogged=true]
setblock -41 2 -145 minecraft:iron_bars[waterlogged=true]
setblock -41 2 -144 minecraft:iron_bars[waterlogged=true]
setblock -41 2 -143 minecraft:iron_bars[waterlogged=true]
setblock -41 2 -142 minecraft:iron_bars[waterlogged=true]
setblock -41 2 -141 minecraft:iron_bars[waterlogged=true]
setblock -41 2 -140 minecraft:iron_bars[waterlogged=true]
setblock -41 3 -146 minecraft:iron_bars[waterlogged=true]
setblock -41 3 -145 minecraft:iron_bars[waterlogged=true]
setblock -41 3 -144 minecraft:iron_bars[waterlogged=true]
setblock -41 3 -143 minecraft:iron_bars[waterlogged=true]
setblock -41 3 -142 minecraft:iron_bars[waterlogged=true]
setblock -41 3 -141 minecraft:iron_bars[waterlogged=true]
setblock -41 3 -140 minecraft:iron_bars[waterlogged=true]
setblock -41 4 -146 minecraft:iron_bars[waterlogged=true]
setblock -41 4 -145 minecraft:iron_bars[waterlogged=true]
setblock -41 4 -144 minecraft:iron_bars[waterlogged=true]
setblock -41 4 -143 minecraft:iron_bars[waterlogged=true]
setblock -41 4 -142 minecraft:iron_bars[waterlogged=true]
setblock -41 4 -141 minecraft:iron_bars[waterlogged=true]
setblock -41 4 -140 minecraft:iron_bars[waterlogged=true]
setblock -41 5 -146 minecraft:iron_bars[waterlogged=true]
setblock -41 5 -145 minecraft:iron_bars[waterlogged=true]
setblock -41 5 -144 minecraft:iron_bars[waterlogged=true]
setblock -41 5 -143 minecraft:iron_bars[waterlogged=true]
setblock -41 5 -142 minecraft:iron_bars[waterlogged=true]
setblock -41 5 -141 minecraft:iron_bars[waterlogged=true]
setblock -41 5 -140 minecraft:iron_bars[waterlogged=true]
setblock -41 6 -146 minecraft:iron_bars[waterlogged=true]
setblock -41 6 -145 minecraft:iron_bars[waterlogged=true]
setblock -41 6 -144 minecraft:iron_bars[waterlogged=true]
setblock -41 6 -143 minecraft:iron_bars[waterlogged=true]
setblock -41 6 -142 minecraft:iron_bars[waterlogged=true]
setblock -41 6 -141 minecraft:iron_bars[waterlogged=true]
setblock -41 6 -140 minecraft:iron_bars[waterlogged=true]
setblock -41 7 -146 minecraft:iron_bars[waterlogged=true]
setblock -41 7 -145 minecraft:iron_bars[waterlogged=true]
setblock -41 7 -144 minecraft:iron_bars[waterlogged=true]
setblock -41 7 -143 minecraft:iron_bars[waterlogged=true]
setblock -41 7 -142 minecraft:iron_bars[waterlogged=true]
setblock -41 7 -141 minecraft:iron_bars[waterlogged=true]
setblock -41 7 -140 minecraft:iron_bars[waterlogged=true]
setblock -41 8 -146 minecraft:iron_bars[waterlogged=true]
setblock -41 8 -145 minecraft:iron_bars[waterlogged=true]
setblock -41 8 -144 minecraft:iron_bars[waterlogged=true]
setblock -41 8 -143 minecraft:iron_bars[waterlogged=true]
setblock -41 8 -142 minecraft:iron_bars[waterlogged=true]
setblock -41 8 -141 minecraft:iron_bars[waterlogged=true]
setblock -41 8 -140 minecraft:iron_bars[waterlogged=true]
execute if score #niv station matches 70.. run fill -40 2 -146 -32 8 -140 minecraft:water
execute unless score #niv station matches 70.. run fill -40 2 -146 -32 8 -140 minecraft:air
execute if score #niv station matches 70.. run setblock -31 2 -146 minecraft:water
execute if score #niv station matches 70.. run setblock -31 3 -146 minecraft:water
execute if score #niv station matches 70.. run setblock -31 4 -146 minecraft:water
execute if score #niv station matches 70.. run setblock -31 5 -146 minecraft:water
execute if score #niv station matches 70.. run setblock -31 6 -146 minecraft:water
execute if score #niv station matches 70.. run setblock -31 7 -146 minecraft:water
execute if score #niv station matches 70.. run setblock -31 8 -146 minecraft:water
execute if score #niv station matches 70.. run setblock -31 2 -145 minecraft:water
execute if score #niv station matches 70.. run setblock -31 3 -145 minecraft:water
execute if score #niv station matches 70.. run setblock -31 4 -145 minecraft:water
execute if score #niv station matches 70.. run setblock -31 5 -145 minecraft:water
execute if score #niv station matches 70.. run setblock -31 6 -145 minecraft:water
execute if score #niv station matches 70.. run setblock -31 7 -145 minecraft:water
execute if score #niv station matches 70.. run setblock -31 8 -145 minecraft:water
execute if score #niv station matches 70.. run setblock -31 2 -144 minecraft:water
execute if score #niv station matches 70.. run setblock -31 3 -144 minecraft:water
execute if score #niv station matches 70.. run setblock -31 4 -144 minecraft:water
execute if score #niv station matches 70.. run setblock -31 5 -144 minecraft:water
execute if score #niv station matches 70.. run setblock -31 6 -144 minecraft:water
execute if score #niv station matches 70.. run setblock -31 7 -144 minecraft:water
execute if score #niv station matches 70.. run setblock -31 8 -144 minecraft:water
execute if score #niv station matches 70.. run setblock -31 2 -143 minecraft:water
execute if score #niv station matches 70.. run setblock -31 3 -143 minecraft:water
execute if score #niv station matches 70.. run setblock -31 4 -143 minecraft:water
execute if score #niv station matches 70.. run setblock -31 5 -143 minecraft:water
execute if score #niv station matches 70.. run setblock -31 6 -143 minecraft:water
execute if score #niv station matches 70.. run setblock -31 7 -143 minecraft:water
execute if score #niv station matches 70.. run setblock -31 8 -143 minecraft:water
execute if score #niv station matches 70.. run setblock -31 2 -142 minecraft:water
execute if score #niv station matches 70.. run setblock -31 3 -142 minecraft:water
execute if score #niv station matches 70.. run setblock -31 4 -142 minecraft:water
execute if score #niv station matches 70.. run setblock -31 5 -142 minecraft:water
execute if score #niv station matches 70.. run setblock -31 6 -142 minecraft:water
execute if score #niv station matches 70.. run setblock -31 7 -142 minecraft:water
execute if score #niv station matches 70.. run setblock -31 8 -142 minecraft:water
execute if score #niv station matches 70.. run setblock -31 2 -141 minecraft:water
execute if score #niv station matches 70.. run setblock -31 3 -141 minecraft:water
execute if score #niv station matches 70.. run setblock -31 4 -141 minecraft:water
execute if score #niv station matches 70.. run setblock -31 5 -141 minecraft:water
execute if score #niv station matches 70.. run setblock -31 6 -141 minecraft:water
execute if score #niv station matches 70.. run setblock -31 7 -141 minecraft:water
execute if score #niv station matches 70.. run setblock -31 8 -141 minecraft:water
execute unless score #niv station matches 70.. run setblock -31 2 -146 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 3 -146 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 4 -146 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 5 -146 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 6 -146 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 7 -146 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 8 -146 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 2 -145 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 3 -145 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 4 -145 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 5 -145 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 6 -145 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 7 -145 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 8 -145 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 2 -144 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 3 -144 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 4 -144 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 5 -144 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 6 -144 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 7 -144 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 8 -144 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 2 -143 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 3 -143 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 4 -143 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 5 -143 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 6 -143 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 7 -143 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 8 -143 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 2 -142 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 3 -142 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 4 -142 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 5 -142 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 6 -142 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 7 -142 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 8 -142 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 2 -141 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 3 -141 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 4 -141 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 5 -141 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 6 -141 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 7 -141 minecraft:air
execute unless score #niv station matches 70.. run setblock -31 8 -141 minecraft:air
execute positioned -36 5 -143 run playsound minecraft:block.iron_door.open master @a[distance=..24] ~ ~ ~ 1.5 0.5
execute positioned -36 5 -143 run particle minecraft:bubble_column_up ~ ~ ~ 2 2 2 0.1 60
