# [claude-build] La porte du Sas monte dans son linteau : le chemin de la Grande Cuve est ouvert.
data modify entity @e[type=donjon:porte_station,tag=station_porte_sas,limit=1] Ouverte set value 1b
playsound minecraft:block.piston.contract master @a 0 25 -81 3 0.5
playsound minecraft:block.iron_door.open master @a 0 25 -81 3 0.6
schedule function atelier:station_sas_barriere 40t
