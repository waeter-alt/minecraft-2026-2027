# [claude-build] La vanne du Sas se leve : le chemin de la Grande Cuve est ouvert.
fill -3 23 -81 3 27 -81 minecraft:air
playsound minecraft:block.piston.contract master @a 0 25 -81 3 0.5
playsound minecraft:block.iron_door.open master @a 0 25 -81 3 0.6
tellraw @a {"text":"La vanne du Sas se lève.","color":"gray"}
