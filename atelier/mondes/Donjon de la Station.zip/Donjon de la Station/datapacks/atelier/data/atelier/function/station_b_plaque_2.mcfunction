# [claude-build] Plaque lestee 2 : un joueur se tient debout dessus (au fond, pas en nageant).
scoreboard players set #pl2 station 1
# ouvre le jet qui garde la plaque 3
setblock 101 -22 -130 minecraft:water
setblock 101 -21 -130 minecraft:water
setblock 101 -20 -130 minecraft:water
setblock 101 -19 -130 minecraft:water
setblock 101 -18 -130 minecraft:water
setblock 102 -22 -130 minecraft:water
setblock 102 -21 -130 minecraft:water
setblock 102 -20 -130 minecraft:water
setblock 102 -19 -130 minecraft:water
setblock 102 -18 -130 minecraft:water
setblock 103 -22 -130 minecraft:water
setblock 103 -21 -130 minecraft:water
setblock 103 -20 -130 minecraft:water
setblock 103 -19 -130 minecraft:water
setblock 103 -18 -130 minecraft:water
execute positioned 92 -22 -158 run particle minecraft:wax_on ~ ~0.2 ~ 1 0.1 1 0.1 30
execute positioned 92 -22 -158 run playsound minecraft:block.copper_bulb.turn_on master @a[distance=..40] ~ ~ ~ 2 0.7
