# [claude-build] Plaque lestee 1 : un joueur se tient debout dessus (au fond, pas en nageant).
scoreboard players set #pl1 station 1
# ouvre le jet qui garde la plaque 2
setblock 91 -22 -156 minecraft:water
setblock 91 -21 -156 minecraft:water
setblock 91 -20 -156 minecraft:water
setblock 91 -19 -156 minecraft:water
setblock 91 -18 -156 minecraft:water
setblock 92 -22 -156 minecraft:water
setblock 92 -21 -156 minecraft:water
setblock 92 -20 -156 minecraft:water
setblock 92 -19 -156 minecraft:water
setblock 92 -18 -156 minecraft:water
setblock 93 -22 -156 minecraft:water
setblock 93 -21 -156 minecraft:water
setblock 93 -20 -156 minecraft:water
setblock 93 -19 -156 minecraft:water
setblock 93 -18 -156 minecraft:water
execute positioned 80 -22 -143 run particle minecraft:wax_on ~ ~0.2 ~ 1 0.1 1 0.1 30
execute positioned 80 -22 -143 run playsound minecraft:block.copper_bulb.turn_on master @a[distance=..40] ~ ~ ~ 2 0.7
