# [claude-build] Un joueur entre au Vestiaire (une seule fois) : le message dit ou est la cape. Execute positionne au coin du Vestiaire.
scoreboard players set #vest station 1
title @a[dx=41,dy=2,dz=43] actionbar {"text":"La Cape lestée se trouve dans l'une des cabines orange","color":"gold"}
tellraw @a[dx=41,dy=2,dz=43] {"text":"La Cape lestée se trouve dans l'une des cabines orange.","color":"gold"}
