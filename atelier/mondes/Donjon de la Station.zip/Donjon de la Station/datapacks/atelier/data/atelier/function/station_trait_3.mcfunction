# [claude-build] Le trait de lumiere de la valve 3, un tick : il avance de 1,6 bloc vers son voyant (execute en tant que lui, tourne vers le voyant) et l'allume au contact.
particle minecraft:end_rod ~ ~ ~ 0.03 0.03 0.03 0 3 force
particle minecraft:electric_spark ~ ~ ~ 0.06 0.06 0.06 0.1 2 force
execute unless entity @s[tag=arrive] run tp @s ^ ^ ^1.6
execute positioned -60.5 29.5 -52.5 if entity @s[distance=..1.7,tag=!arrive] run function atelier:station_trait_fin_3
