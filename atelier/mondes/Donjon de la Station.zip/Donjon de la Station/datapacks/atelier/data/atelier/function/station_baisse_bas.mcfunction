# [claude-build] La Cuve passe d'un coup au niveau bas (42).
function atelier:station_vide_58
function atelier:station_vide_57
function atelier:station_vide_56
function atelier:station_vide_55
function atelier:station_vide_54
function atelier:station_vide_53
function atelier:station_vide_52
function atelier:station_vide_51
function atelier:station_vide_50
function atelier:station_vide_49
function atelier:station_vide_48
function atelier:station_vide_47
function atelier:station_vide_46
function atelier:station_vide_45
function atelier:station_vide_44
function atelier:station_vide_43
scoreboard players set #niv station 42
tellraw @a {"text":"La Grande Cuve baisse : niveau BAS.","color":"aqua"}
