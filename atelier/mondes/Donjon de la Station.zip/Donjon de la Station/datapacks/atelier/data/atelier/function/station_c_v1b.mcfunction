# [claude-build] La valve B de l'etage 1 est tournee : elle retombe dans 10 s ; si l'autre est tournee avant, la trappe 1 s'ouvre.
scoreboard players set #c1b station 1
scoreboard players set #c1t station 200
execute positioned 15 -14 -204 run playsound minecraft:block.chain.break master @a[distance=..60] ~ ~ ~ 2 0.8
execute if score #c1a station matches 1 run function atelier:station_c_trappe_1
