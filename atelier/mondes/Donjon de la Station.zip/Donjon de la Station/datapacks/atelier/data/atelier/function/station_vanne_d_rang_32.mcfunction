# [claude-build] La vanne D se leve : sa rangee 32 disparait (de bas en haut).
setblock 17 -30 -168 minecraft:water
setblock 18 -30 -168 minecraft:water
setblock 19 -30 -167 minecraft:water
setblock 20 -30 -167 minecraft:water
setblock 20 -30 -166 minecraft:water
setblock 21 -30 -166 minecraft:water
setblock 21 -30 -165 minecraft:water
execute positioned 20 -30 -167 run particle minecraft:bubble_column_up ~0.5 ~ ~0.5 1.2 0.3 1.2 0.2 40 force
execute positioned 20 -30 -167 run playsound minecraft:block.piston.contract master @a[distance=..120] ~ ~ ~ 2 0.58
