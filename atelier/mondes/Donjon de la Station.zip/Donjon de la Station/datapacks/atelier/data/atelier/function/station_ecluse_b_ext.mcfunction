# [claude-build] Ecluse B, cote Cuve : la vanne interieure se ferme, le sas prend le niveau de la Cuve, la vanne exterieure s'ouvre.
scoreboard players set #ecB station 1
setblock 40 -30 -146 minecraft:iron_bars[waterlogged=true]
setblock 40 -30 -145 minecraft:iron_bars[waterlogged=true]
setblock 40 -30 -144 minecraft:iron_bars[waterlogged=true]
setblock 40 -30 -143 minecraft:iron_bars[waterlogged=true]
setblock 40 -30 -142 minecraft:iron_bars[waterlogged=true]
setblock 40 -30 -141 minecraft:iron_bars[waterlogged=true]
setblock 40 -30 -140 minecraft:iron_bars[waterlogged=true]
setblock 40 -29 -146 minecraft:iron_bars[waterlogged=true]
setblock 40 -29 -145 minecraft:iron_bars[waterlogged=true]
setblock 40 -29 -144 minecraft:iron_bars[waterlogged=true]
setblock 40 -29 -143 minecraft:iron_bars[waterlogged=true]
setblock 40 -29 -142 minecraft:iron_bars[waterlogged=true]
setblock 40 -29 -141 minecraft:iron_bars[waterlogged=true]
setblock 40 -29 -140 minecraft:iron_bars[waterlogged=true]
setblock 40 -28 -146 minecraft:iron_bars[waterlogged=true]
setblock 40 -28 -145 minecraft:iron_bars[waterlogged=true]
setblock 40 -28 -144 minecraft:iron_bars[waterlogged=true]
setblock 40 -28 -143 minecraft:iron_bars[waterlogged=true]
setblock 40 -28 -142 minecraft:iron_bars[waterlogged=true]
setblock 40 -28 -141 minecraft:iron_bars[waterlogged=true]
setblock 40 -28 -140 minecraft:iron_bars[waterlogged=true]
setblock 40 -27 -146 minecraft:iron_bars[waterlogged=true]
setblock 40 -27 -145 minecraft:iron_bars[waterlogged=true]
setblock 40 -27 -144 minecraft:iron_bars[waterlogged=true]
setblock 40 -27 -143 minecraft:iron_bars[waterlogged=true]
setblock 40 -27 -142 minecraft:iron_bars[waterlogged=true]
setblock 40 -27 -141 minecraft:iron_bars[waterlogged=true]
setblock 40 -27 -140 minecraft:iron_bars[waterlogged=true]
setblock 40 -26 -146 minecraft:iron_bars[waterlogged=true]
setblock 40 -26 -145 minecraft:iron_bars[waterlogged=true]
setblock 40 -26 -144 minecraft:iron_bars[waterlogged=true]
setblock 40 -26 -143 minecraft:iron_bars[waterlogged=true]
setblock 40 -26 -142 minecraft:iron_bars[waterlogged=true]
setblock 40 -26 -141 minecraft:iron_bars[waterlogged=true]
setblock 40 -26 -140 minecraft:iron_bars[waterlogged=true]
setblock 40 -25 -146 minecraft:iron_bars[waterlogged=true]
setblock 40 -25 -145 minecraft:iron_bars[waterlogged=true]
setblock 40 -25 -144 minecraft:iron_bars[waterlogged=true]
setblock 40 -25 -143 minecraft:iron_bars[waterlogged=true]
setblock 40 -25 -142 minecraft:iron_bars[waterlogged=true]
setblock 40 -25 -141 minecraft:iron_bars[waterlogged=true]
setblock 40 -25 -140 minecraft:iron_bars[waterlogged=true]
setblock 40 -24 -146 minecraft:iron_bars[waterlogged=true]
setblock 40 -24 -145 minecraft:iron_bars[waterlogged=true]
setblock 40 -24 -144 minecraft:iron_bars[waterlogged=true]
setblock 40 -24 -143 minecraft:iron_bars[waterlogged=true]
setblock 40 -24 -142 minecraft:iron_bars[waterlogged=true]
setblock 40 -24 -141 minecraft:iron_bars[waterlogged=true]
setblock 40 -24 -140 minecraft:iron_bars[waterlogged=true]
execute if score #niv station matches 38.. run fill 31 -30 -146 39 -24 -140 minecraft:water
execute unless score #niv station matches 38.. run fill 31 -30 -146 39 -24 -140 minecraft:air
execute if score #niv station matches 38.. run setblock 30 -30 -146 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -29 -146 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -28 -146 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -27 -146 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -26 -146 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -25 -146 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -24 -146 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -30 -145 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -29 -145 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -28 -145 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -27 -145 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -26 -145 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -25 -145 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -24 -145 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -30 -144 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -29 -144 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -28 -144 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -27 -144 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -26 -144 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -25 -144 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -24 -144 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -30 -143 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -29 -143 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -28 -143 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -27 -143 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -26 -143 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -25 -143 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -24 -143 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -30 -142 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -29 -142 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -28 -142 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -27 -142 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -26 -142 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -25 -142 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -24 -142 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -30 -141 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -29 -141 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -28 -141 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -27 -141 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -26 -141 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -25 -141 minecraft:water
execute if score #niv station matches 38.. run setblock 30 -24 -141 minecraft:water
execute unless score #niv station matches 38.. run setblock 30 -30 -146 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -29 -146 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -28 -146 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -27 -146 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -26 -146 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -25 -146 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -24 -146 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -30 -145 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -29 -145 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -28 -145 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -27 -145 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -26 -145 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -25 -145 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -24 -145 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -30 -144 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -29 -144 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -28 -144 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -27 -144 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -26 -144 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -25 -144 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -24 -144 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -30 -143 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -29 -143 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -28 -143 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -27 -143 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -26 -143 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -25 -143 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -24 -143 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -30 -142 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -29 -142 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -28 -142 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -27 -142 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -26 -142 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -25 -142 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -24 -142 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -30 -141 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -29 -141 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -28 -141 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -27 -141 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -26 -141 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -25 -141 minecraft:air
execute unless score #niv station matches 38.. run setblock 30 -24 -141 minecraft:air
execute positioned 35 -27 -143 run playsound minecraft:block.iron_door.open master @a[distance=..24] ~ ~ ~ 1.5 0.5
execute positioned 35 -27 -143 run particle minecraft:bubble_column_up ~ ~ ~ 2 2 2 0.1 60
