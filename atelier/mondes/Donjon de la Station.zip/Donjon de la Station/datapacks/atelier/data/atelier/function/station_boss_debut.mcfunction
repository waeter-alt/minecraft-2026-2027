# [claude-build] Un joueur arrive dans le Reservoir : le Leviathan surgit.
scoreboard players set #boss station 1
function atelier:station_boss_apparition
title @a title {"text":"Le Léviathan","color":"dark_aqua"}
execute unless entity @e[tag=station_boss] run tellraw @a {"text":"(Le Léviathan n'existe pas dans ce jar du grappin : l'Exutoire s'ouvre.)","color":"gray"}
