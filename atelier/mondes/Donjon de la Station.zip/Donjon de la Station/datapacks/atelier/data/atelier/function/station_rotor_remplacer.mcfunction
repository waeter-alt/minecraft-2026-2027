# [claude-build] L'ancien gardien du rotor (gardien des profondeurs) est remplace par le Scaphandrier rouille, a sa place.
summon donjon:scaphandrier ~ ~ ~ {PersistenceRequired:1b,Tags:["station_emb","station_rotor"],CustomName:'"Scaphandrier rouillé"'}
tag @s remove station_rotor
tp @s ~ -400 ~
kill @s
