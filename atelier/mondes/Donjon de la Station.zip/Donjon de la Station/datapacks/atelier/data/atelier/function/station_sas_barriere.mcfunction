# [claude-build] La porte du Sas a fini de monter : le passage est libre.
fill -3 23 -81 3 27 -81 minecraft:air replace minecraft:barrier
