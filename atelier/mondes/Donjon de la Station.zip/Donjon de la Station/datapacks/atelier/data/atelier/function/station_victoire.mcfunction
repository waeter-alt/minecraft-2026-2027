# [claude-build] Retour a la lumiere.
scoreboard players set #boss station 3
title @a title {"text":"La Station est vaincue","color":"gold"}
execute positioned 0 -35 -89 run particle minecraft:firework ~ ~2 ~ 3 2 3 0.1 120
playsound minecraft:ui.toast.challenge_complete master @a 0 -35 -89 2 1
