# [claude-build] Un joueur descend dans le bassin de 50 m : embuscade (une seule fois) : trois zombies et un squelette surgissent du fond.
scoreboard players set #emb station 1
summon minecraft:zombie -14 20 -43 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:zombie 1 20 -39 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:zombie 16 20 -44 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:skeleton 8 20 -46 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned -14 20 -43 run particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute positioned 1 20 -39 run particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute positioned 16 20 -44 run particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute positioned 8 20 -46 run particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute positioned -24 20 -48 run playsound minecraft:entity.zombie.ambient hostile @a[distance=..60] ~ ~ ~ 2 0.6
