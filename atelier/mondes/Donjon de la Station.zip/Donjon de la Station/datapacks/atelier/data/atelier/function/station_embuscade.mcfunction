# [claude-build] Un joueur descend dans le bassin de 50 m : embuscade (une seule fois) : six zombies et deux squelettes surgissent du fond.
scoreboard players set #emb station 1
summon minecraft:zombie -20 20 -65 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:zombie -5 20 -56 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:zombie 10 20 -63 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:skeleton 2 20 -60 {Tags:["station_emb"],PersistenceRequired:1b,HandItems:[{id:"minecraft:bow",count:1},{}]}
summon minecraft:zombie -25 20 -57 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:zombie -12 20 -61 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:zombie 7 20 -66 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:skeleton 15 20 -57 {Tags:["station_emb"],PersistenceRequired:1b,HandItems:[{id:"minecraft:bow",count:1},{}]}
execute positioned -20 20 -65 run particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute positioned -5 20 -56 run particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute positioned 10 20 -63 run particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute positioned 2 20 -60 run particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute positioned -25 20 -57 run particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute positioned -12 20 -61 run particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute positioned 7 20 -66 run particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute positioned 15 20 -57 run particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute positioned -30 20 -68 run playsound minecraft:entity.zombie.ambient hostile @a[distance=..60] ~ ~ ~ 2 0.6
