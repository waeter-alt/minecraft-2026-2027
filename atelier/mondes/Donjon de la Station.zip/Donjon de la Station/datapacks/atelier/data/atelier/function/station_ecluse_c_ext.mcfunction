# [claude-build] Ecluse C, cote Cuve : la vanne interieure se ferme, le sas prend le niveau de la Cuve, la vanne exterieure s'ouvre.
scoreboard players set #ecC station 1
setblock -3 -14 -184 minecraft:iron_bars[waterlogged=true]
setblock -3 -13 -184 minecraft:iron_bars[waterlogged=true]
setblock -3 -12 -184 minecraft:iron_bars[waterlogged=true]
setblock -3 -11 -184 minecraft:iron_bars[waterlogged=true]
setblock -3 -10 -184 minecraft:iron_bars[waterlogged=true]
setblock -3 -9 -184 minecraft:iron_bars[waterlogged=true]
setblock -3 -8 -184 minecraft:iron_bars[waterlogged=true]
setblock -2 -14 -184 minecraft:iron_bars[waterlogged=true]
setblock -2 -13 -184 minecraft:iron_bars[waterlogged=true]
setblock -2 -12 -184 minecraft:iron_bars[waterlogged=true]
setblock -2 -11 -184 minecraft:iron_bars[waterlogged=true]
setblock -2 -10 -184 minecraft:iron_bars[waterlogged=true]
setblock -2 -9 -184 minecraft:iron_bars[waterlogged=true]
setblock -2 -8 -184 minecraft:iron_bars[waterlogged=true]
setblock -1 -14 -184 minecraft:iron_bars[waterlogged=true]
setblock -1 -13 -184 minecraft:iron_bars[waterlogged=true]
setblock -1 -12 -184 minecraft:iron_bars[waterlogged=true]
setblock -1 -11 -184 minecraft:iron_bars[waterlogged=true]
setblock -1 -10 -184 minecraft:iron_bars[waterlogged=true]
setblock -1 -9 -184 minecraft:iron_bars[waterlogged=true]
setblock -1 -8 -184 minecraft:iron_bars[waterlogged=true]
setblock 0 -14 -184 minecraft:iron_bars[waterlogged=true]
setblock 0 -13 -184 minecraft:iron_bars[waterlogged=true]
setblock 0 -12 -184 minecraft:iron_bars[waterlogged=true]
setblock 0 -11 -184 minecraft:iron_bars[waterlogged=true]
setblock 0 -10 -184 minecraft:iron_bars[waterlogged=true]
setblock 0 -9 -184 minecraft:iron_bars[waterlogged=true]
setblock 0 -8 -184 minecraft:iron_bars[waterlogged=true]
setblock 1 -14 -184 minecraft:iron_bars[waterlogged=true]
setblock 1 -13 -184 minecraft:iron_bars[waterlogged=true]
setblock 1 -12 -184 minecraft:iron_bars[waterlogged=true]
setblock 1 -11 -184 minecraft:iron_bars[waterlogged=true]
setblock 1 -10 -184 minecraft:iron_bars[waterlogged=true]
setblock 1 -9 -184 minecraft:iron_bars[waterlogged=true]
setblock 1 -8 -184 minecraft:iron_bars[waterlogged=true]
setblock 2 -14 -184 minecraft:iron_bars[waterlogged=true]
setblock 2 -13 -184 minecraft:iron_bars[waterlogged=true]
setblock 2 -12 -184 minecraft:iron_bars[waterlogged=true]
setblock 2 -11 -184 minecraft:iron_bars[waterlogged=true]
setblock 2 -10 -184 minecraft:iron_bars[waterlogged=true]
setblock 2 -9 -184 minecraft:iron_bars[waterlogged=true]
setblock 2 -8 -184 minecraft:iron_bars[waterlogged=true]
setblock 3 -14 -184 minecraft:iron_bars[waterlogged=true]
setblock 3 -13 -184 minecraft:iron_bars[waterlogged=true]
setblock 3 -12 -184 minecraft:iron_bars[waterlogged=true]
setblock 3 -11 -184 minecraft:iron_bars[waterlogged=true]
setblock 3 -10 -184 minecraft:iron_bars[waterlogged=true]
setblock 3 -9 -184 minecraft:iron_bars[waterlogged=true]
setblock 3 -8 -184 minecraft:iron_bars[waterlogged=true]
execute if score #niv station matches 54.. run fill -3 -14 -183 3 -8 -175 minecraft:water
execute unless score #niv station matches 54.. run fill -3 -14 -183 3 -8 -175 minecraft:air
execute if score #niv station matches 54.. run setblock -3 -14 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -3 -13 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -3 -12 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -3 -11 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -3 -10 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -3 -9 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -3 -8 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -2 -14 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -2 -13 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -2 -12 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -2 -11 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -2 -10 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -2 -9 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -2 -8 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -1 -14 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -1 -13 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -1 -12 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -1 -11 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -1 -10 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -1 -9 -174 minecraft:water
execute if score #niv station matches 54.. run setblock -1 -8 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 0 -14 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 0 -13 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 0 -12 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 0 -11 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 0 -10 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 0 -9 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 0 -8 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 1 -14 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 1 -13 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 1 -12 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 1 -11 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 1 -10 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 1 -9 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 1 -8 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 2 -14 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 2 -13 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 2 -12 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 2 -11 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 2 -10 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 2 -9 -174 minecraft:water
execute if score #niv station matches 54.. run setblock 2 -8 -174 minecraft:water
execute unless score #niv station matches 54.. run setblock -3 -14 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -3 -13 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -3 -12 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -3 -11 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -3 -10 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -3 -9 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -3 -8 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -2 -14 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -2 -13 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -2 -12 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -2 -11 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -2 -10 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -2 -9 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -2 -8 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -1 -14 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -1 -13 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -1 -12 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -1 -11 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -1 -10 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -1 -9 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock -1 -8 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 0 -14 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 0 -13 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 0 -12 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 0 -11 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 0 -10 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 0 -9 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 0 -8 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 1 -14 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 1 -13 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 1 -12 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 1 -11 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 1 -10 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 1 -9 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 1 -8 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 2 -14 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 2 -13 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 2 -12 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 2 -11 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 2 -10 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 2 -9 -174 minecraft:air
execute unless score #niv station matches 54.. run setblock 2 -8 -174 minecraft:air
execute positioned 0 -11 -179 run playsound minecraft:block.iron_door.open master @a[distance=..24] ~ ~ ~ 1.5 0.5
execute positioned 0 -11 -179 run particle minecraft:bubble_column_up ~ ~ ~ 2 2 2 0.1 60
