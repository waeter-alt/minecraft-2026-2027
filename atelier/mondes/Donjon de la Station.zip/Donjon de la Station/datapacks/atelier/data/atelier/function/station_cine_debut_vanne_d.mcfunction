# [claude-build] Lance la cinematique « vanne_d » : la camera, puis les joueurs proches (en spectateur, par les yeux de la camera).
scoreboard players set #id cine 14
scoreboard players set #t cine 1
scoreboard players set #nb cine 0
summon minecraft:armor_stand 6.500 -21.500 -150.500 {Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["cine_cam"],Rotation:[-138.814f,15.760f]}
execute positioned 0 22 -143 as @a[distance=..400,gamemode=!spectator] at @s run function atelier:station_cine_joueur
