# [claude-build] Pose de la station, etape 20 sur 20.
place template atelier:station_reservoir -45 -62 -188
kill @e[type=item]
function atelier:station_reset
schedule function atelier:station_pose_3 100t
