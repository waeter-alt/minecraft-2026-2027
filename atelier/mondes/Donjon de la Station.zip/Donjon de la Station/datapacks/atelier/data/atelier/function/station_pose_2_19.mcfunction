# [claude-build] Pose de la station, etape 20 sur 21.
place template atelier:station_reservoir -45 -62 -188
schedule function atelier:station_pose_2_20 2t
