# [claude-build] Le levier du Sas est tire : la porte du Sas monte, en cinematique (ou tout de suite si une autre est en cours).
scoreboard players set #sasp station 1
scoreboard players operation #libre cine = #t cine
execute if score #libre cine matches 0 run function atelier:station_cine_debut_sas
execute unless score #libre cine matches 0 run function atelier:station_sas_ouvrir
