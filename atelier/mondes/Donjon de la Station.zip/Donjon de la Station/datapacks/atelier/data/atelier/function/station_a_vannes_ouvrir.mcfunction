# [claude-build] Galerie des vannes : le depart (ou un relais entre deux vannes) ouvre les quatre vannes pour 5,0 s.
execute unless score #galA station matches 1.. run playsound minecraft:block.piston.contract master @a[distance=..60] ~ ~ ~ 2 0.6
scoreboard players set #galA station 100
fill -45 2 -156 -43 4 -156 minecraft:water
fill -45 2 -168 -43 4 -168 minecraft:water
fill -45 2 -180 -43 4 -180 minecraft:water
fill -45 2 -192 -43 4 -192 minecraft:water
