# [claude-build] Pose la station (sans pause).
forceload add -120 -238 119 1
tellraw @a {"text":"Station : 30 secondes de chargement, puis la pose par morceaux (le jeu peut ralentir). Ne mets pas en pause.","color":"gold"}
schedule function atelier:station_pose_2 600t
