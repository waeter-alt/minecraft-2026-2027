# [claude-build] Le volant A est tourne : la pompe A repart, la galerie reste ouverte pour le retour.
scoreboard players set #pA station 1
fill -45 2 -156 -43 4 -156 minecraft:water
fill -45 2 -168 -43 4 -168 minecraft:water
fill -45 2 -180 -43 4 -180 minecraft:water
fill -45 2 -192 -43 4 -192 minecraft:water
execute positioned -112 -1 -215 run particle minecraft:bubble_column_up ~ ~2 ~ 1 3 1 0.2 200
execute positioned -112 -1 -215 run playsound minecraft:block.beacon.power_select master @a[distance=..80] ~ ~ ~ 2 0.6
tellraw @a {"text":"La pompe A (Filtration) tourne.","color":"aqua"}
function atelier:station_pompe_faite
