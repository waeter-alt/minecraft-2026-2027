# [claude-build] Le volant A est tourne : la pompe A repart.
scoreboard players set #pA station 1
execute positioned -110 2 -215 run particle minecraft:bubble_column_up ~ ~2 ~ 1 3 1 0.2 200
execute positioned -110 2 -215 run playsound minecraft:block.beacon.power_select master @a[distance=..80] ~ ~ ~ 2 0.6
tellraw @a {"text":"La pompe A (Filtration) tourne.","color":"aqua"}
setblock -110 -1 -215 create:creative_motor[facing=up]
setblock -104 -1 -219 donjon:pompe_station[facing=west,en_marche=true,waterlogged=true]
setblock -89 -1 -206 donjon:pompe_station[facing=north,en_marche=true,waterlogged=true]
setblock -75 -1 -225 donjon:pompe_station[facing=south,en_marche=true,waterlogged=true]
setblock -61 -1 -206 donjon:pompe_station[facing=north,en_marche=true,waterlogged=true]
function atelier:station_pompe_faite
