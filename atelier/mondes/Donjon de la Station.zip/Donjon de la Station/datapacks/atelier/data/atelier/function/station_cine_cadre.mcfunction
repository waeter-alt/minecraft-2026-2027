# [claude-build] Un tick de cinematique (appelee quand #t cine est au moins 1).
scoreboard players add #t cine 1
execute if score #id cine matches 10 run function atelier:station_cine_bas
execute if score #id cine matches 11 run function atelier:station_cine_bonde
execute if score #id cine matches 12 run function atelier:station_cine_eau
execute if score #id cine matches 13 run function atelier:station_cine_median
execute if score #id cine matches 14 run function atelier:station_cine_sas
execute if score #id cine matches 15 run function atelier:station_cine_sortie
execute if score #id cine matches 16 run function atelier:station_cine_vanne_d
execute if score #t cine matches 6.. as @a[tag=cine] at @s unless entity @e[type=minecraft:armor_stand,tag=cine_cam,distance=..1.5] run function atelier:station_cine_retour_joueur
execute if score #id cine matches 10 if score #t cine matches 172.. run function atelier:station_cine_fin
execute if score #id cine matches 11 if score #t cine matches 172.. run function atelier:station_cine_fin
execute if score #id cine matches 12 if score #t cine matches 302.. run function atelier:station_cine_fin
execute if score #id cine matches 13 if score #t cine matches 172.. run function atelier:station_cine_fin
execute if score #id cine matches 14 if score #t cine matches 112.. run function atelier:station_cine_fin
execute if score #id cine matches 15 if score #t cine matches 122.. run function atelier:station_cine_fin
execute if score #id cine matches 16 if score #t cine matches 182.. run function atelier:station_cine_fin
