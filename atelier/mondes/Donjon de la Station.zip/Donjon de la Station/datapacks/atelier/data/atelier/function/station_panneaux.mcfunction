# [claude-build] Les panneaux de la station (une seule rangee de texte par ligne).
setblock 0 15 -114 minecraft:oak_wall_sign[facing=north]{front_text:{color:"white",has_glowing_text:1b,messages:['{"text":"HAUT"}','{"text":"76"}','{"text":""}','{"text":""}']},is_waxed:1b}
setblock 0 -3 -114 minecraft:oak_wall_sign[facing=north]{front_text:{color:"white",has_glowing_text:1b,messages:['{"text":"MEDIAN"}','{"text":"58"}','{"text":""}','{"text":""}']},is_waxed:1b}
setblock 0 -19 -114 minecraft:oak_wall_sign[facing=north]{front_text:{color:"white",has_glowing_text:1b,messages:['{"text":"BAS"}','{"text":"42"}','{"text":""}','{"text":""}']},is_waxed:1b}
