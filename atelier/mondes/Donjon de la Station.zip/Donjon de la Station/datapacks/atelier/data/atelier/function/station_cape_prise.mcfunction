# [claude-build] La cape a quitte le casier : un levier apparait dans le Vestiaire (au mur, pres de l'entree) : il ouvre la grande porte du Sas.
scoreboard players set #cape station 1
setblock -65 24 -51 donjon:levier_station[face=wall,facing=west,powered=false]
execute positioned -65 24 -51 run particle minecraft:end_rod ~0.5 ~1 ~0.5 0.3 0.6 0.3 0.05 40 force
execute positioned -65 24 -51 run playsound minecraft:block.beacon.activate master @a[distance=..80] ~ ~ ~ 2 1.4
