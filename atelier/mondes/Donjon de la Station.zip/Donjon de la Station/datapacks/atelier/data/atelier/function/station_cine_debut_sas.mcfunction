# [claude-build] Lance la cinematique « sas » : la camera, puis les joueurs proches (en spectateur, par les yeux de la camera).
scoreboard players set #id cine 14
scoreboard players set #t cine 1
scoreboard players set #nb cine 0
summon minecraft:armor_stand 7.500 29.500 -56.500 {Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["cine_cam"],Rotation:[163.740f,10.204f]}
execute positioned 0 23 -48 as @a[distance=..90,gamemode=!spectator] at @s run function atelier:station_cine_joueur
