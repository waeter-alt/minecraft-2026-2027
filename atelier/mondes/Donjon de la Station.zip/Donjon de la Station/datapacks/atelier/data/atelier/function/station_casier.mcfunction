# [claude-build] Le casier orange du Vestiaire recoit la Cape lestee : on le vide puis on le repose plein, il pose lui-meme sa moitie haute (on repart d'une case vide : setblock viderait un coffre deja la).
setblock -86 24 -63 minecraft:air
setblock -86 23 -63 minecraft:air
setblock -86 23 -63 donjon:casier[facing=south,couleur=orange]{Items:[{Slot:13b,id:"donjon:cape_lestee",count:1}]}
execute positioned -86 23 -63 run particle minecraft:happy_villager ~ ~0.5 ~ 0.4 0.4 0.4 0.1 30
execute positioned -86 23 -63 run playsound minecraft:block.chest.open master @a[distance=..60] ~ ~ ~ 2 1
tellraw @a {"text":"Au Vestiaire, un casier s'est ouvert.","color":"gold"}
