# [claude-build] Un joueur entre dans la Grande Cuve (par le Sas) : la station se met en route et la Cuve se remplit, en cinematique (ou d'un coup si une autre est en cours). Une seule fois.
scoreboard players set #eau station 1
scoreboard players operation #libre cine = #t cine
execute if score #libre cine matches 0 run function atelier:station_cine_debut_eau
execute unless score #libre cine matches 0 run function atelier:station_eau_tout
