# [claude-build] Un joueur entre : les monstres de « a4 » apparaissent (une seule fois).
scoreboard players set #a4 station 1
summon minecraft:guardian -114 4 -223 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned -114 4 -223 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:guardian -114 4 -207 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned -114 4 -207 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
