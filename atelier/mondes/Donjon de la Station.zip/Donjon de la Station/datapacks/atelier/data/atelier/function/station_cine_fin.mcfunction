# [claude-build] Fin de la cinematique (ou arret force) : tous les joueurs sont rendus, la camera disparait.
execute as @a[tag=cine] run function atelier:station_cine_retour_joueur
kill @e[type=minecraft:armor_stand,tag=cine_cam]
kill @e[type=minecraft:marker,tag=cine_retour]
scoreboard players set #t cine 0
scoreboard players set #id cine 0
