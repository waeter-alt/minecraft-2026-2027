# [claude-build] Cinematique « bonde » : une image par tick (la camera), et ses evenements (sons, effets).
execute if score #t cine matches 1 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.856 12.000 -158.321 40.000 65.308
execute if score #t cine matches 2 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.853 11.990 -158.317 40.000 65.308
execute if score #t cine matches 3 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.844 11.960 -158.307 40.000 65.308
execute if score #t cine matches 4 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.829 11.911 -158.289 40.000 65.308
execute if score #t cine matches 5 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.809 11.843 -158.266 40.000 65.308
execute if score #t cine matches 6 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.784 11.757 -158.235 40.000 65.308
execute if score #t cine matches 7 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.753 11.653 -158.199 40.000 65.308
execute if score #t cine matches 8 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.717 11.532 -158.156 40.000 65.308
execute if score #t cine matches 9 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.677 11.394 -158.107 40.000 65.308
execute if score #t cine matches 10 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.631 11.240 -158.053 40.000 65.308
execute if score #t cine matches 11 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.581 11.071 -157.994 40.000 65.308
execute if score #t cine matches 12 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.527 10.886 -157.929 40.000 65.308
execute if score #t cine matches 13 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.468 10.687 -157.858 40.000 65.308
execute if score #t cine matches 14 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.405 10.474 -157.783 40.000 65.308
execute if score #t cine matches 15 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.338 10.247 -157.704 40.000 65.308
execute if score #t cine matches 16 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.267 10.008 -157.619 40.000 65.308
execute if score #t cine matches 17 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.193 9.756 -157.531 40.000 65.308
execute if score #t cine matches 18 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.115 9.492 -157.438 40.000 65.308
execute if score #t cine matches 19 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 12.033 9.217 -157.341 40.000 65.308
execute if score #t cine matches 20 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 11.949 8.931 -157.240 40.000 65.308
execute if score #t cine matches 21 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 11.861 8.634 -157.135 40.000 65.308
execute if score #t cine matches 22 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 11.771 8.328 -157.028 40.000 65.308
execute if score #t cine matches 23 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 11.677 8.012 -156.916 40.000 65.308
execute if score #t cine matches 24 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 11.581 7.688 -156.802 40.000 65.308
execute if score #t cine matches 25 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 11.483 7.356 -156.685 40.000 65.308
execute if score #t cine matches 26 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 11.383 7.015 -156.565 40.000 65.308
execute if score #t cine matches 27 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 11.280 6.668 -156.443 40.000 65.308
execute if score #t cine matches 28 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 11.175 6.314 -156.318 40.000 65.308
execute if score #t cine matches 29 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 11.069 5.954 -156.191 40.000 65.308
execute if score #t cine matches 30 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 10.961 5.588 -156.063 40.000 65.308
execute if score #t cine matches 31 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 10.851 5.217 -155.932 40.000 65.308
execute if score #t cine matches 32 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 10.740 4.842 -155.800 40.000 65.308
execute if score #t cine matches 33 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 10.628 4.463 -155.666 40.000 65.308
execute if score #t cine matches 34 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 10.515 4.080 -155.531 40.000 65.308
execute if score #t cine matches 35 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 10.401 3.694 -155.395 40.000 65.308
execute if score #t cine matches 36 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 10.286 3.306 -155.259 40.000 65.308
execute if score #t cine matches 37 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 10.171 2.916 -155.121 40.000 65.308
execute if score #t cine matches 38 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 10.055 2.524 -154.983 40.000 65.308
execute if score #t cine matches 39 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 9.939 2.132 -154.845 40.000 65.308
execute if score #t cine matches 40 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 9.823 1.739 -154.707 40.000 65.308
execute if score #t cine matches 41 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 9.707 1.347 -154.569 40.000 65.308
execute if score #t cine matches 42 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 9.592 0.955 -154.431 40.000 65.308
execute if score #t cine matches 43 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 9.476 0.565 -154.293 40.000 65.308
execute if score #t cine matches 44 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 9.361 0.176 -154.156 40.000 65.308
execute if score #t cine matches 45 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 9.247 -0.210 -154.020 40.000 65.308
execute if score #t cine matches 46 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 9.134 -0.594 -153.885 40.000 65.308
execute if score #t cine matches 47 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 9.022 -0.974 -153.751 40.000 65.308
execute if score #t cine matches 48 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 8.910 -1.350 -153.619 40.000 65.308
execute if score #t cine matches 49 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 8.800 -1.722 -153.488 40.000 65.308
execute if score #t cine matches 50 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 8.692 -2.089 -153.359 40.000 65.308
execute if score #t cine matches 51 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 8.585 -2.450 -153.231 40.000 65.308
execute if score #t cine matches 52 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 8.480 -2.806 -153.106 40.000 65.308
execute if score #t cine matches 53 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 8.377 -3.154 -152.983 40.000 65.308
execute if score #t cine matches 54 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 8.276 -3.496 -152.863 40.000 65.308
execute if score #t cine matches 55 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 8.177 -3.830 -152.745 40.000 65.308
execute if score #t cine matches 56 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 8.081 -4.156 -152.631 40.000 65.308
execute if score #t cine matches 57 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.987 -4.474 -152.519 40.000 65.308
execute if score #t cine matches 58 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.896 -4.782 -152.410 40.000 65.308
execute if score #t cine matches 59 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.808 -5.081 -152.305 40.000 65.308
execute if score #t cine matches 60 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.723 -5.369 -152.203 40.000 65.308
execute if score #t cine matches 61 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.641 -5.647 -152.106 40.000 65.308
execute if score #t cine matches 62 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.562 -5.913 -152.012 40.000 65.308
execute if score #t cine matches 63 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.487 -6.168 -151.922 40.000 65.308
execute if score #t cine matches 64 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.415 -6.410 -151.837 40.000 65.308
execute if score #t cine matches 65 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.347 -6.639 -151.756 40.000 65.308
execute if score #t cine matches 66 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.283 -6.855 -151.680 40.000 65.308
execute if score #t cine matches 67 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.224 -7.057 -151.609 40.000 65.308
execute if score #t cine matches 68 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.168 -7.245 -151.543 40.000 65.308
execute if score #t cine matches 69 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.117 -7.418 -151.482 40.000 65.308
execute if score #t cine matches 70 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.071 -7.575 -151.426 40.000 65.308
execute if score #t cine matches 71 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.027 -7.723 -151.374 40.000 65.308
execute if score #t cine matches 72 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.984 -7.868 -151.323 40.000 65.308
execute if score #t cine matches 73 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.942 -8.011 -151.273 40.000 65.308
execute if score #t cine matches 74 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.900 -8.152 -151.223 40.000 65.308
execute if score #t cine matches 75 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.859 -8.290 -151.175 40.000 65.308
execute if score #t cine matches 76 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.819 -8.425 -151.127 40.000 65.308
execute if score #t cine matches 77 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.780 -8.558 -151.080 40.000 65.308
execute if score #t cine matches 78 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.742 -8.689 -151.034 40.000 65.308
execute if score #t cine matches 79 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.704 -8.817 -150.989 40.000 65.308
execute if score #t cine matches 80 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.666 -8.943 -150.945 40.000 65.308
execute if score #t cine matches 81 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.630 -9.066 -150.901 40.000 65.308
execute if score #t cine matches 82 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.594 -9.187 -150.859 40.000 65.308
execute if score #t cine matches 83 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.559 -9.306 -150.817 40.000 65.308
execute if score #t cine matches 84 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.525 -9.422 -150.776 40.000 65.308
execute if score #t cine matches 85 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.491 -9.536 -150.736 40.000 65.308
execute if score #t cine matches 86 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.458 -9.648 -150.696 40.000 65.308
execute if score #t cine matches 87 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.425 -9.758 -150.658 40.000 65.308
execute if score #t cine matches 88 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.394 -9.866 -150.620 40.000 65.308
execute if score #t cine matches 89 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.363 -9.971 -150.583 40.000 65.308
execute if score #t cine matches 90 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.332 -10.074 -150.546 40.000 65.308
execute if score #t cine matches 91 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.302 -10.175 -150.511 40.000 65.308
execute if score #t cine matches 92 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.273 -10.274 -150.476 40.000 65.308
execute if score #t cine matches 93 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.244 -10.371 -150.442 40.000 65.308
execute if score #t cine matches 94 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.216 -10.465 -150.408 40.000 65.308
execute if score #t cine matches 95 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.189 -10.558 -150.376 40.000 65.308
execute if score #t cine matches 96 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.162 -10.649 -150.344 40.000 65.308
execute if score #t cine matches 97 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.136 -10.737 -150.313 40.000 65.308
execute if score #t cine matches 98 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.111 -10.824 -150.282 40.000 65.308
execute if score #t cine matches 99 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.086 -10.908 -150.252 40.000 65.308
execute if score #t cine matches 100 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.061 -10.991 -150.223 40.000 65.308
execute if score #t cine matches 101 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.037 -11.072 -150.195 40.000 65.308
execute if score #t cine matches 102 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.014 -11.151 -150.167 40.000 65.308
execute if score #t cine matches 103 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.991 -11.228 -150.140 40.000 65.308
execute if score #t cine matches 104 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.969 -11.303 -150.114 40.000 65.308
execute if score #t cine matches 105 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.947 -11.376 -150.088 40.000 65.308
execute if score #t cine matches 106 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.926 -11.447 -150.063 40.000 65.308
execute if score #t cine matches 107 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.906 -11.517 -150.038 40.000 65.308
execute if score #t cine matches 108 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.886 -11.585 -150.014 40.000 65.308
execute if score #t cine matches 109 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.866 -11.651 -149.991 40.000 65.308
execute if score #t cine matches 110 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.847 -11.715 -149.968 40.000 65.308
execute if score #t cine matches 111 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.829 -11.778 -149.946 40.000 65.308
execute if score #t cine matches 112 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.811 -11.839 -149.925 40.000 65.308
execute if score #t cine matches 113 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.793 -11.898 -149.904 40.000 65.308
execute if score #t cine matches 114 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.776 -11.956 -149.883 40.000 65.308
execute if score #t cine matches 115 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.759 -12.012 -149.864 40.000 65.308
execute if score #t cine matches 116 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.743 -12.066 -149.845 40.000 65.308
execute if score #t cine matches 117 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.728 -12.119 -149.826 40.000 65.308
execute if score #t cine matches 118 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.713 -12.171 -149.808 40.000 65.308
execute if score #t cine matches 119 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.698 -12.220 -149.790 40.000 65.308
execute if score #t cine matches 120 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.684 -12.269 -149.773 40.000 65.308
execute if score #t cine matches 121 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.670 -12.315 -149.757 40.000 65.308
execute if score #t cine matches 122 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.656 -12.361 -149.741 40.000 65.308
execute if score #t cine matches 123 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.643 -12.405 -149.726 40.000 65.308
execute if score #t cine matches 124 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.631 -12.447 -149.711 40.000 65.308
execute if score #t cine matches 125 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.619 -12.488 -149.696 40.000 65.308
execute if score #t cine matches 126 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.607 -12.528 -149.682 40.000 65.308
execute if score #t cine matches 127 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.596 -12.566 -149.669 40.000 65.308
execute if score #t cine matches 128 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.585 -12.603 -149.656 40.000 65.308
execute if score #t cine matches 129 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.574 -12.638 -149.643 40.000 65.308
execute if score #t cine matches 130 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.564 -12.673 -149.631 40.000 65.308
execute if score #t cine matches 131 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.554 -12.706 -149.619 40.000 65.308
execute if score #t cine matches 132 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.545 -12.737 -149.608 40.000 65.308
execute if score #t cine matches 133 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.536 -12.768 -149.598 40.000 65.308
execute if score #t cine matches 134 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.527 -12.797 -149.587 40.000 65.308
execute if score #t cine matches 135 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.519 -12.825 -149.577 40.000 65.308
execute if score #t cine matches 136 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.511 -12.852 -149.568 40.000 65.308
execute if score #t cine matches 137 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.503 -12.878 -149.559 40.000 65.308
execute if score #t cine matches 138 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.496 -12.903 -149.550 40.000 65.308
execute if score #t cine matches 139 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.489 -12.927 -149.542 40.000 65.308
execute if score #t cine matches 140 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.482 -12.949 -149.534 40.000 65.308
execute if score #t cine matches 141 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.476 -12.971 -149.526 40.000 65.308
execute if score #t cine matches 142 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.470 -12.991 -149.519 40.000 65.308
execute if score #t cine matches 143 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.464 -13.010 -149.512 40.000 65.308
execute if score #t cine matches 144 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.459 -13.029 -149.506 40.000 65.308
execute if score #t cine matches 145 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.454 -13.046 -149.500 40.000 65.308
execute if score #t cine matches 146 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.449 -13.063 -149.494 40.000 65.308
execute if score #t cine matches 147 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.444 -13.078 -149.488 40.000 65.308
execute if score #t cine matches 148 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.440 -13.093 -149.483 40.000 65.308
execute if score #t cine matches 149 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.436 -13.107 -149.478 40.000 65.308
execute if score #t cine matches 150 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.432 -13.120 -149.474 40.000 65.308
execute if score #t cine matches 151 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.428 -13.132 -149.469 40.000 65.308
execute if score #t cine matches 152 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.425 -13.143 -149.465 40.000 65.308
execute if score #t cine matches 153 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.422 -13.153 -149.462 40.000 65.308
execute if score #t cine matches 154 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.419 -13.163 -149.458 40.000 65.308
execute if score #t cine matches 155 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.417 -13.172 -149.455 40.000 65.308
execute if score #t cine matches 156 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.414 -13.180 -149.452 40.000 65.308
execute if score #t cine matches 157 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.412 -13.188 -149.450 40.000 65.308
execute if score #t cine matches 158 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.410 -13.194 -149.447 40.000 65.308
execute if score #t cine matches 159 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.408 -13.201 -149.445 40.000 65.308
execute if score #t cine matches 160 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.407 -13.206 -149.443 40.000 65.308
execute if score #t cine matches 161 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.405 -13.211 -149.442 40.000 65.308
execute if score #t cine matches 162 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.404 -13.215 -149.440 40.000 65.308
execute if score #t cine matches 163 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.403 -13.219 -149.439 40.000 65.308
execute if score #t cine matches 164 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.402 -13.222 -149.438 40.000 65.308
execute if score #t cine matches 165 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.401 -13.224 -149.437 40.000 65.308
execute if score #t cine matches 166 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.400 -13.227 -149.436 40.000 65.308
execute if score #t cine matches 167 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.400 -13.228 -149.435 40.000 65.308
execute if score #t cine matches 168 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.400 -13.229 -149.435 40.000 65.308
execute if score #t cine matches 169 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.399 -13.230 -149.435 40.000 65.308
execute if score #t cine matches 170 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.399 -13.230 -149.435 40.000 65.308
execute if score #t cine matches 2 run execute as @a[tag=cine] at @s run playsound minecraft:block.lever.click master @s ~ ~ ~ 1 0.6
execute if score #t cine matches 2 run execute as @a[tag=cine] at @s run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 40 run function atelier:station_bonde_ouvrir
execute if score #t cine matches 40 run execute positioned 0 -31.5 -143 run particle minecraft:bubble_column_up ~ ~1 ~ 2 3 2 0.3 200 force
execute if score #t cine matches 48 run particle minecraft:splash 0.00 -19.00 -149.00 1 0.2 1 0.3 40 force
execute if score #t cine matches 48 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 6.0 0.3 6.0 0.05 30 force
execute if score #t cine matches 48 run execute as @a[tag=cine] at @s run playsound minecraft:block.bubble_column.whirlpool_ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 56 run particle minecraft:splash 4.13 -19.00 -146.85 1 0.2 1 0.3 40 force
execute if score #t cine matches 56 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 5.7 0.3 5.7 0.05 30 force
execute if score #t cine matches 64 run particle minecraft:splash 5.29 -19.00 -142.63 1 0.2 1 0.3 40 force
execute if score #t cine matches 64 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 5.3 0.3 5.3 0.05 30 force
execute if score #t cine matches 72 run particle minecraft:splash 3.12 -19.00 -139.15 1 0.2 1 0.3 40 force
execute if score #t cine matches 72 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 5.0 0.3 5.0 0.05 30 force
execute if score #t cine matches 72 run execute as @a[tag=cine] at @s run playsound minecraft:block.bubble_column.whirlpool_ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 80 run particle minecraft:splash -0.64 -19.00 -138.44 1 0.2 1 0.3 40 force
execute if score #t cine matches 80 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 4.6 0.3 4.6 0.05 30 force
execute if score #t cine matches 88 run particle minecraft:splash -3.48 -19.00 -140.56 1 0.2 1 0.3 40 force
execute if score #t cine matches 88 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 4.2 0.3 4.2 0.05 30 force
execute if score #t cine matches 96 run particle minecraft:splash -3.81 -19.00 -143.81 1 0.2 1 0.3 40 force
execute if score #t cine matches 96 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 3.9 0.3 3.9 0.05 30 force
execute if score #t cine matches 96 run execute as @a[tag=cine] at @s run playsound minecraft:block.bubble_column.whirlpool_ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 104 run particle minecraft:splash -1.83 -19.00 -146.04 1 0.2 1 0.3 40 force
execute if score #t cine matches 104 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 3.6 0.3 3.6 0.05 30 force
execute if score #t cine matches 112 run particle minecraft:splash 0.88 -19.00 -146.08 1 0.2 1 0.3 40 force
execute if score #t cine matches 112 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 3.2 0.3 3.2 0.05 30 force
execute if score #t cine matches 120 run particle minecraft:splash 2.54 -19.00 -144.29 1 0.2 1 0.3 40 force
execute if score #t cine matches 120 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 2.9 0.3 2.9 0.05 30 force
execute if score #t cine matches 120 run execute as @a[tag=cine] at @s run playsound minecraft:block.bubble_column.whirlpool_ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 128 run particle minecraft:splash 2.35 -19.00 -142.14 1 0.2 1 0.3 40 force
execute if score #t cine matches 128 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 2.5 0.3 2.5 0.05 30 force
execute if score #t cine matches 136 run particle minecraft:splash 0.84 -19.00 -141.02 1 0.2 1 0.3 40 force
execute if score #t cine matches 136 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 2.2 0.3 2.2 0.05 30 force
execute if score #t cine matches 144 run particle minecraft:splash -0.73 -19.00 -141.36 1 0.2 1 0.3 40 force
execute if score #t cine matches 144 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 1.8 0.3 1.8 0.05 30 force
execute if score #t cine matches 144 run execute as @a[tag=cine] at @s run playsound minecraft:block.bubble_column.whirlpool_ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 150 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 0.6
execute if score #t cine matches 152 run particle minecraft:splash -1.42 -19.00 -142.51 1 0.2 1 0.3 40 force
execute if score #t cine matches 152 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 1.5 0.3 1.5 0.05 30 force
execute if score #t cine matches 160 run particle minecraft:splash -1.32 -19.00 -143.70 1 0.2 1 0.3 40 force
execute if score #t cine matches 160 run particle minecraft:bubble_pop 0.00 -20.00 -143.00 1.5 0.3 1.5 0.05 30 force
