# [claude-build] Un joueur entre : les monstres de « rotor » apparaissent (une seule fois).
scoreboard players set #rotor station 1
summon minecraft:elder_guardian 6 8 -204 {PersistenceRequired:1b,Tags:["station_emb","station_rotor"],CustomName:'"Gardien du rotor"'}
execute positioned 6 8 -204 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
