# [claude-build] Un joueur entre : les monstres de « rotor » apparaissent (une seule fois).
scoreboard players set #rotor station 1
summon donjon:scaphandrier 6 8 -204 {PersistenceRequired:1b,Tags:["station_emb","station_rotor"],active_effects:[{id:"minecraft:resistance",amplifier:4,duration:-1,show_particles:0b}],CustomName:'"Scaphandrier rouillé"'}
execute positioned 6 8 -204 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon donjon:cristal_marin 10.5 1 -213.5 {ShowBottom:0b,Tags:["station_rotor_cristal","station_emb"]}
summon donjon:cristal_marin 10.5 1 -193.5 {ShowBottom:0b,Tags:["station_rotor_cristal","station_emb"]}
summon donjon:cristal_marin -9.5 1 -193.5 {ShowBottom:0b,Tags:["station_rotor_cristal","station_emb"]}
summon donjon:cristal_marin -9.5 1 -213.5 {ShowBottom:0b,Tags:["station_rotor_cristal","station_emb"]}
execute positioned 10.5 2 -213.5 run particle minecraft:glow ~ ~ ~ 0.6 0.6 0.6 0.1 30 force
execute positioned 10.5 2 -193.5 run particle minecraft:glow ~ ~ ~ 0.6 0.6 0.6 0.1 30 force
execute positioned -9.5 2 -193.5 run particle minecraft:glow ~ ~ ~ 0.6 0.6 0.6 0.1 30 force
execute positioned -9.5 2 -213.5 run particle minecraft:glow ~ ~ ~ 0.6 0.6 0.6 0.1 30 force
