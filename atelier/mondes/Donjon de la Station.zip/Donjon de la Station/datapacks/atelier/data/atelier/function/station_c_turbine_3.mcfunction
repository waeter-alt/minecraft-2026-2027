# [claude-build] La turbine T3 est lancee : elle tourne et pousse l'eau vers le haut ; une vague de monstres arrive.
scoreboard players set #t3 station 1000
execute positioned 0 18 -204 run playsound minecraft:block.beacon.activate master @a[distance=..60] ~ ~ ~ 2 0.6
tellraw @a {"text":"La turbine T3 tourne.","color":"aqua"}
summon minecraft:drowned -8 17 -198 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:drowned 8 17 -210 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:drowned 6 17 -194 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:guardian -6 17 -212 {Tags:["station_emb"],PersistenceRequired:1b}
setblock 0 15 -204 create:creative_motor[facing=up]
setblock -3 24 -224 minecraft:air
setblock -3 25 -224 minecraft:air
setblock -3 26 -224 minecraft:air
setblock -3 27 -224 minecraft:air
setblock -2 24 -224 minecraft:air
setblock -2 25 -224 minecraft:air
setblock -2 26 -224 minecraft:air
setblock -2 27 -224 minecraft:air
setblock -1 24 -224 minecraft:air
setblock -1 25 -224 minecraft:air
setblock -1 26 -224 minecraft:air
setblock -1 27 -224 minecraft:air
setblock 0 24 -224 minecraft:air
setblock 0 25 -224 minecraft:air
setblock 0 26 -224 minecraft:air
setblock 0 27 -224 minecraft:air
setblock 1 24 -224 minecraft:air
setblock 1 25 -224 minecraft:air
setblock 1 26 -224 minecraft:air
setblock 1 27 -224 minecraft:air
setblock 2 24 -224 minecraft:air
setblock 2 25 -224 minecraft:air
setblock 2 26 -224 minecraft:air
setblock 2 27 -224 minecraft:air
setblock 3 24 -224 minecraft:air
setblock 3 25 -224 minecraft:air
setblock 3 26 -224 minecraft:air
setblock 3 27 -224 minecraft:air
tellraw @a {"text":"La grille de la salle de la pompe C se leve.","color":"gold"}
