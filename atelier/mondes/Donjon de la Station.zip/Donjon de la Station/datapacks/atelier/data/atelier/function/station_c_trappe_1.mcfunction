# [claude-build] La trappe 1 (la vanne dans le trou de la grille) s'ouvre : on peut monter a l'etage suivant.
scoreboard players set #g1 station 1
setblock -12 0 -206 minecraft:water
setblock -12 0 -205 minecraft:water
setblock -12 0 -204 minecraft:water
setblock -12 0 -203 minecraft:water
setblock -12 0 -202 minecraft:water
setblock -11 0 -206 minecraft:water
setblock -11 0 -205 minecraft:water
setblock -11 0 -204 minecraft:water
setblock -11 0 -203 minecraft:water
setblock -11 0 -202 minecraft:water
setblock -10 0 -206 minecraft:water
setblock -10 0 -205 minecraft:water
setblock -10 0 -204 minecraft:water
setblock -10 0 -203 minecraft:water
setblock -10 0 -202 minecraft:water
setblock -9 0 -206 minecraft:water
setblock -9 0 -205 minecraft:water
setblock -9 0 -204 minecraft:water
setblock -9 0 -203 minecraft:water
setblock -9 0 -202 minecraft:water
setblock -8 0 -206 minecraft:water
setblock -8 0 -205 minecraft:water
setblock -8 0 -204 minecraft:water
setblock -8 0 -203 minecraft:water
setblock -8 0 -202 minecraft:water
execute positioned -10 0 -204 run playsound minecraft:block.piston.extend master @a[distance=..60] ~ ~ ~ 3 0.6
execute positioned -10 0 -204 run particle minecraft:bubble_column_up ~ ~-1 ~ 2 0.5 2 0.2 60 force
