# [claude-build] Le levier general : la porte du Poste s'ouvre sur la Coursive ; la bonde de la Cuve s'ouvre en cinematique (ou tout de suite si une autre est en cours).
scoreboard players set #lg station 1
setblock 23 23 -174 minecraft:air
setblock 23 23 -173 minecraft:air
setblock 23 23 -172 minecraft:air
setblock 23 24 -174 minecraft:air
setblock 23 24 -173 minecraft:air
setblock 23 24 -172 minecraft:air
setblock 23 25 -174 minecraft:air
setblock 23 25 -173 minecraft:air
setblock 23 25 -172 minecraft:air
setblock 23 26 -174 minecraft:air
setblock 23 26 -173 minecraft:air
setblock 23 26 -172 minecraft:air
scoreboard players operation #libre cine = #t cine
execute if score #libre cine matches 0 run function atelier:station_cine_debut_bonde
execute unless score #libre cine matches 0 run function atelier:station_bonde_ouvrir
