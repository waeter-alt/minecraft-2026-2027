# [claude-build] La dalle de sortie : elle ramene a l'entree du donjon (le pavillon, en surface).
tp @s -1 47 0 180 0
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 1.2
