# [claude-build] Le tartre de la grille 1 se brise.
scoreboard players set #tar1 station 1
setblock -12 0 -206 minecraft:water
setblock -12 0 -205 minecraft:water
setblock -12 0 -204 minecraft:water
setblock -12 0 -203 minecraft:water
setblock -12 0 -202 minecraft:water
setblock -11 0 -206 minecraft:water
setblock -11 0 -205 minecraft:water
setblock -11 0 -204 minecraft:water
setblock -11 0 -203 minecraft:water
setblock -11 0 -202 minecraft:water
setblock -10 0 -206 minecraft:water
setblock -10 0 -205 minecraft:water
setblock -10 0 -204 minecraft:water
setblock -10 0 -203 minecraft:water
setblock -10 0 -202 minecraft:water
setblock -9 0 -206 minecraft:water
setblock -9 0 -205 minecraft:water
setblock -9 0 -204 minecraft:water
setblock -9 0 -203 minecraft:water
setblock -9 0 -202 minecraft:water
setblock -8 0 -206 minecraft:water
setblock -8 0 -205 minecraft:water
setblock -8 0 -204 minecraft:water
setblock -8 0 -203 minecraft:water
setblock -8 0 -202 minecraft:water
execute positioned -10 0 -204 run particle minecraft:block{block_state:{Name:"minecraft:dripstone_block"}} ~ ~ ~ 2 0.5 2 0.1 80
execute positioned -10 0 -204 run playsound minecraft:block.dripstone_block.break master @a[distance=..40] ~ ~ ~ 2 0.6
