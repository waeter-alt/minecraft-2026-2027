# [claude-build] La trappe 2 (la vanne dans le trou de la grille) s'ouvre : on peut monter a l'etage suivant.
scoreboard players set #g2 station 1
setblock -12 14 -206 minecraft:water
setblock -12 14 -205 minecraft:water
setblock -12 14 -204 minecraft:water
setblock -12 14 -203 minecraft:water
setblock -12 14 -202 minecraft:water
setblock -11 14 -206 minecraft:water
setblock -11 14 -205 minecraft:water
setblock -11 14 -204 minecraft:water
setblock -11 14 -203 minecraft:water
setblock -11 14 -202 minecraft:water
setblock -10 14 -206 minecraft:water
setblock -10 14 -205 minecraft:water
setblock -10 14 -204 minecraft:water
setblock -10 14 -203 minecraft:water
setblock -10 14 -202 minecraft:water
setblock -9 14 -206 minecraft:water
setblock -9 14 -205 minecraft:water
setblock -9 14 -204 minecraft:water
setblock -9 14 -203 minecraft:water
setblock -9 14 -202 minecraft:water
setblock -8 14 -206 minecraft:water
setblock -8 14 -205 minecraft:water
setblock -8 14 -204 minecraft:water
setblock -8 14 -203 minecraft:water
setblock -8 14 -202 minecraft:water
execute positioned -10 14 -204 run playsound minecraft:block.piston.extend master @a[distance=..60] ~ ~ ~ 3 0.6
execute positioned -10 14 -204 run particle minecraft:bubble_column_up ~ ~-1 ~ 2 0.5 2 0.2 60 force
