# [claude-build] Le Leviathan est vaincu : l'Exutoire s'ouvre, un courant ascendant ramene a la surface.
scoreboard players set #boss station 2
kill @e[tag=station_cristal]
title @a title {"text":"Le Léviathan est vaincu","color":"gold"}
schedule function atelier:station_sortie_scene 60t
