# [claude-build] Les cristaux des mers (mod donjon) apparaissent sur les piliers de l'anneau : tant qu'il en reste, ils soignent le Leviathan ; un coup en brise un.
summon donjon:cristal_marin 11.5 -41 -170.5 {ShowBottom:0b,Tags:["station_cristal","station_emb"]}
summon donjon:cristal_marin 21.5 -48 -151.5 {ShowBottom:0b,Tags:["station_cristal","station_emb"]}
summon donjon:cristal_marin 28.5 -42 -131.5 {ShowBottom:0b,Tags:["station_cristal","station_emb"]}
summon donjon:cristal_marin -10.5 -43 -114.5 {ShowBottom:0b,Tags:["station_cristal","station_emb"]}
summon donjon:cristal_marin -20.5 -48 -133.5 {ShowBottom:0b,Tags:["station_cristal","station_emb"]}
summon donjon:cristal_marin -27.5 -44 -153.5 {ShowBottom:0b,Tags:["station_cristal","station_emb"]}
execute positioned 11.5 -41 -170.5 run particle minecraft:glow ~ ~ ~ 0.6 0.6 0.6 0.1 30 force
execute positioned 21.5 -48 -151.5 run particle minecraft:glow ~ ~ ~ 0.6 0.6 0.6 0.1 30 force
execute positioned 28.5 -42 -131.5 run particle minecraft:glow ~ ~ ~ 0.6 0.6 0.6 0.1 30 force
execute positioned -10.5 -43 -114.5 run particle minecraft:glow ~ ~ ~ 0.6 0.6 0.6 0.1 30 force
execute positioned -20.5 -48 -133.5 run particle minecraft:glow ~ ~ ~ 0.6 0.6 0.6 0.1 30 force
execute positioned -27.5 -44 -153.5 run particle minecraft:glow ~ ~ ~ 0.6 0.6 0.6 0.1 30 force
playsound minecraft:block.amethyst_cluster.place master @a 10 -50 -153 4 0.6
