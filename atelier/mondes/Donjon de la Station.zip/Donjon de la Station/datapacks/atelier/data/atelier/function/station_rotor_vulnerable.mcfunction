# [claude-build] Les quatre cristaux sont brises : le Scaphandrier n'est plus protege.
scoreboard players set #rvn station 1
effect clear @e[tag=station_rotor] minecraft:resistance
effect give @e[tag=station_rotor] minecraft:glowing 40 0 true
execute as @e[tag=station_rotor] at @s run playsound minecraft:block.beacon.deactivate hostile @a[distance=..60] ~ ~ ~ 3 0.7
execute as @e[tag=station_rotor] at @s run particle minecraft:explosion ~ ~1 ~ 0.4 0.6 0.4 0.1 6
