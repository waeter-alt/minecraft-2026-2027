# [claude-build] Le volant 3 est tourne : un temoin du Sas s'allume (l'ordre est libre).
scoreboard players set #v3 station 1
scoreboard players add #temoins station 1
setblock 2 29 -81 minecraft:waxed_copper_bulb[lit=true,powered=false]
execute positioned 2 29 -81 run playsound minecraft:block.copper_bulb.turn_on master @a[distance=..80] ~ ~ ~ 2 0.8
execute positioned 42 33 -53 run playsound minecraft:block.iron_door.open master @a[distance=..20] ~ ~ ~ 1 0.5
execute as @a[x=42,y=33,z=-53,distance=..12] run title @s actionbar {"text":"Un témoin du Sas s'allume","color":"aqua"}
execute if score #temoins station matches 3 run function atelier:station_trois_volants
