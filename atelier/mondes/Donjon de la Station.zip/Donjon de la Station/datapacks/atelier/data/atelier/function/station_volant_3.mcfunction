# [claude-build] La valve 3 est tournee : un trait de lumiere part vers son voyant (au-dessus de la porte du Vestiaire) qu'il allume en arrivant.
scoreboard players set #v3 station 1
summon minecraft:marker 30.5 34.2 -59.5 {Tags:["station_trait_3"]}
execute positioned 30 33 -60 run playsound minecraft:block.beacon.power_select master @a[distance=..40] ~ ~ ~ 1.5 1.6
execute positioned 30 33 -60 run particle minecraft:electric_spark ~0.5 ~1.2 ~0.5 0.3 0.3 0.3 0.2 25 force
