# [claude-build] La valve 2 est tournee : un trait de lumiere part vers son voyant (au-dessus de la porte du Vestiaire) qu'il allume en arrivant.
scoreboard players set #v2 station 1
summon minecraft:marker 21.5 24.2 -49.5 {Tags:["station_trait_2"]}
execute positioned 21 23 -50 run playsound minecraft:block.beacon.power_select master @a[distance=..40] ~ ~ ~ 1.5 1.6
execute positioned 21 23 -50 run particle minecraft:electric_spark ~0.5 ~1.2 ~0.5 0.3 0.3 0.3 0.2 25 force
