# [claude-build] Pose de la station, etape 15 sur 20.
place template atelier:station_drain 25 -32 -131
schedule function atelier:station_pose_2_15 2t
