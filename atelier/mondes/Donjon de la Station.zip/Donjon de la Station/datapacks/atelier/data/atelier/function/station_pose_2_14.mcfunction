# [claude-build] Pose de la station, etape 15 sur 20.
place template atelier:station_a -120 -2 -236
schedule function atelier:station_pose_2_15 2t
