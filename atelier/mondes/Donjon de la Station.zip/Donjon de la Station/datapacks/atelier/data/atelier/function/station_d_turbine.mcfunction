# [claude-build] La turbine de la Cheminee tourne : un courant ascendant (colonne de bulles) monte jusqu'au bassin du haut.
scoreboard players set #td station 1000
setblock 39 1 -192 minecraft:soul_sand
setblock 39 1 -191 minecraft:soul_sand
setblock 39 1 -190 minecraft:soul_sand
setblock 40 1 -192 minecraft:soul_sand
setblock 40 1 -191 minecraft:soul_sand
setblock 40 1 -190 minecraft:soul_sand
setblock 41 1 -192 minecraft:soul_sand
setblock 41 1 -191 minecraft:soul_sand
setblock 41 1 -190 minecraft:soul_sand
setblock 40 3 -191 create:creative_motor[facing=up]
execute positioned 40 4 -191 run playsound minecraft:block.beacon.activate master @a[distance=..60] ~ ~ ~ 2 0.6
