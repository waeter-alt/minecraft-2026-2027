# [claude-build] Une pompe de plus : son temoin s'allume sur la Coursive ; la Cuve baisse d'un cran (cinematique, ou tout de suite si une autre est en cours) ; a la troisieme, la vanne D se leve.
scoreboard players add #pompes station 1
execute if score #pompes station matches 1 run setblock -2 29 -108 minecraft:waxed_copper_bulb[lit=true,powered=false]
execute if score #pompes station matches 2 run setblock 0 29 -108 minecraft:waxed_copper_bulb[lit=true,powered=false]
execute if score #pompes station matches 3 run setblock 2 29 -108 minecraft:waxed_copper_bulb[lit=true,powered=false]
function atelier:station_ecluses_fermer
scoreboard players operation #libre cine = #t cine
execute if score #pompes station matches 1 if score #libre cine matches 0 run function atelier:station_cine_debut_median
execute if score #pompes station matches 1 unless score #libre cine matches 0 run function atelier:station_baisse_median
execute if score #pompes station matches 2 if score #libre cine matches 0 run function atelier:station_cine_debut_bas
execute if score #pompes station matches 2 unless score #libre cine matches 0 run function atelier:station_baisse_bas
execute if score #pompes station matches 3 if score #libre cine matches 0 run function atelier:station_cine_debut_vanne_d
execute if score #pompes station matches 3 unless score #libre cine matches 0 run function atelier:station_vanne_d
