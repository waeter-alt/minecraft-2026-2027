# [claude-build] Les trois voyants sont allumes : la porte du Vestiaire s'ouvre.
data modify entity @e[type=donjon:porte_station,tag=station_porte_vestiaire,limit=1] Ouverte set value 1b
execute positioned -61.5 24 -53.5 run playsound minecraft:block.piston.extend master @a[distance=..60] ~ ~ ~ 3 0.5
execute positioned -61.5 24 -53.5 run playsound minecraft:block.iron_door.open master @a[distance=..60] ~ ~ ~ 2 0.5
schedule function atelier:station_vestiaire_barriere 40t
