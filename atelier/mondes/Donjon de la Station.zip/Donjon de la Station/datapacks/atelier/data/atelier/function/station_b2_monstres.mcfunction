# [claude-build] Un joueur entre : les monstres de « b2 » apparaissent (une seule fois).
scoreboard players set #b2 station 1
summon minecraft:drowned 75 -18 -153 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned 75 -18 -153 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:drowned 95 -18 -134 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned 95 -18 -134 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:drowned 85 -18 -123 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned 85 -18 -123 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:drowned 104 -18 -148 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned 104 -18 -148 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
