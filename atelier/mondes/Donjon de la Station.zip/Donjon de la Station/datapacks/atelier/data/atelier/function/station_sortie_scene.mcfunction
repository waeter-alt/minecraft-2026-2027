# [claude-build] Trois secondes apres la mort du boss : la cinematique montre la porte de sortie qui s'ouvre (ou elle s'ouvre tout de suite si une autre scene est en cours).
scoreboard players operation #libre cine = #t cine
execute if score #libre cine matches 0 run function atelier:station_cine_debut_sortie
execute unless score #libre cine matches 0 run function atelier:station_sortie_ouvrir
