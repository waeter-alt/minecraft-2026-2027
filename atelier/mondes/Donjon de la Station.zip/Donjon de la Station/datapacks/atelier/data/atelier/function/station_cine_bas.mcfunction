# [claude-build] Cinematique « bas » : une image par tick (la camera), et ses evenements (sons, effets).
execute if score #t cine matches 1 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.000 -165.000 -6.340 4.735
execute if score #t cine matches 2 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.002 -165.000 -6.340 4.735
execute if score #t cine matches 3 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.007 -165.000 -6.340 4.735
execute if score #t cine matches 4 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.015 -165.000 -6.340 4.735
execute if score #t cine matches 5 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.026 -165.000 -6.340 4.735
execute if score #t cine matches 6 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.041 -165.000 -6.340 4.735
execute if score #t cine matches 7 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.059 -165.000 -6.340 4.735
execute if score #t cine matches 8 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.080 -165.000 -6.340 4.735
execute if score #t cine matches 9 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.104 -165.000 -6.340 4.735
execute if score #t cine matches 10 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.131 -165.000 -6.340 4.735
execute if score #t cine matches 11 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.161 -165.000 -6.340 4.735
execute if score #t cine matches 12 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.195 -165.000 -6.340 4.735
execute if score #t cine matches 13 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.231 -165.000 -6.340 4.735
execute if score #t cine matches 14 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.269 -165.000 -6.340 4.735
execute if score #t cine matches 15 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.311 -165.000 -6.340 4.735
execute if score #t cine matches 16 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.356 -165.000 -6.340 4.735
execute if score #t cine matches 17 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.403 -165.000 -6.340 4.735
execute if score #t cine matches 18 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.453 -165.000 -6.340 4.735
execute if score #t cine matches 19 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.506 -165.000 -6.340 4.735
execute if score #t cine matches 20 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.561 -165.000 -6.340 4.735
execute if score #t cine matches 21 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.619 -165.000 -6.340 4.735
execute if score #t cine matches 22 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.680 -165.000 -6.340 4.735
execute if score #t cine matches 23 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.743 -165.000 -6.340 4.735
execute if score #t cine matches 24 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.808 -165.000 -6.340 4.735
execute if score #t cine matches 25 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.876 -165.000 -6.340 4.735
execute if score #t cine matches 26 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.947 -165.000 -6.340 4.735
execute if score #t cine matches 27 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -2.020 -165.000 -6.340 4.735
execute if score #t cine matches 28 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -2.095 -165.000 -6.340 4.735
execute if score #t cine matches 29 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -2.172 -165.000 -6.340 4.735
execute if score #t cine matches 30 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -2.252 -165.000 -6.340 4.735
execute if score #t cine matches 31 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -2.334 -165.000 -6.340 4.735
execute if score #t cine matches 32 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -2.418 -165.000 -6.340 4.735
execute if score #t cine matches 33 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -2.504 -165.000 -6.340 4.735
execute if score #t cine matches 34 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -2.592 -165.000 -6.340 4.735
execute if score #t cine matches 35 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -2.682 -165.000 -6.340 4.735
execute if score #t cine matches 36 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -2.775 -165.000 -6.340 4.735
execute if score #t cine matches 37 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -2.869 -165.000 -6.340 4.735
execute if score #t cine matches 38 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -2.965 -165.000 -6.340 4.735
execute if score #t cine matches 39 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -3.063 -165.000 -6.340 4.735
execute if score #t cine matches 40 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -3.163 -165.000 -6.340 4.735
execute if score #t cine matches 41 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -3.265 -165.000 -6.340 4.735
execute if score #t cine matches 42 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -3.368 -165.000 -6.340 4.735
execute if score #t cine matches 43 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -3.473 -165.000 -6.340 4.735
execute if score #t cine matches 44 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -3.580 -165.000 -6.340 4.735
execute if score #t cine matches 45 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -3.689 -165.000 -6.340 4.735
execute if score #t cine matches 46 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -3.799 -165.000 -6.340 4.735
execute if score #t cine matches 47 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -3.911 -165.000 -6.340 4.735
execute if score #t cine matches 48 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -4.024 -165.000 -6.340 4.735
execute if score #t cine matches 49 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -4.139 -165.000 -6.340 4.735
execute if score #t cine matches 50 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -4.255 -165.000 -6.340 4.735
execute if score #t cine matches 51 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -4.373 -165.000 -6.340 4.735
execute if score #t cine matches 52 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -4.492 -165.000 -6.340 4.735
execute if score #t cine matches 53 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -4.612 -165.000 -6.340 4.735
execute if score #t cine matches 54 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -4.734 -165.000 -6.340 4.735
execute if score #t cine matches 55 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -4.857 -165.000 -6.340 4.735
execute if score #t cine matches 56 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -4.981 -165.000 -6.340 4.735
execute if score #t cine matches 57 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -5.106 -165.000 -6.340 4.735
execute if score #t cine matches 58 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -5.233 -165.000 -6.340 4.735
execute if score #t cine matches 59 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -5.360 -165.000 -6.340 4.735
execute if score #t cine matches 60 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -5.489 -165.000 -6.340 4.735
execute if score #t cine matches 61 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -5.618 -165.000 -6.340 4.735
execute if score #t cine matches 62 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -5.749 -165.000 -6.340 4.735
execute if score #t cine matches 63 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -5.880 -165.000 -6.340 4.735
execute if score #t cine matches 64 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -6.013 -165.000 -6.340 4.735
execute if score #t cine matches 65 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -6.146 -165.000 -6.340 4.735
execute if score #t cine matches 66 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -6.280 -165.000 -6.340 4.735
execute if score #t cine matches 67 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -6.415 -165.000 -6.340 4.735
execute if score #t cine matches 68 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -6.550 -165.000 -6.340 4.735
execute if score #t cine matches 69 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -6.687 -165.000 -6.340 4.735
execute if score #t cine matches 70 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -6.824 -165.000 -6.340 4.735
execute if score #t cine matches 71 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -6.961 -165.000 -6.340 4.735
execute if score #t cine matches 72 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -7.099 -165.000 -6.340 4.735
execute if score #t cine matches 73 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -7.238 -165.000 -6.340 4.735
execute if score #t cine matches 74 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -7.377 -165.000 -6.340 4.735
execute if score #t cine matches 75 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -7.517 -165.000 -6.340 4.735
execute if score #t cine matches 76 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -7.657 -165.000 -6.340 4.735
execute if score #t cine matches 77 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -7.797 -165.000 -6.340 4.735
execute if score #t cine matches 78 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -7.938 -165.000 -6.340 4.735
execute if score #t cine matches 79 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -8.079 -165.000 -6.340 4.735
execute if score #t cine matches 80 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -8.220 -165.000 -6.340 4.735
execute if score #t cine matches 81 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -8.362 -165.000 -6.340 4.735
execute if score #t cine matches 82 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -8.503 -165.000 -6.340 4.735
execute if score #t cine matches 83 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -8.645 -165.000 -6.340 4.735
execute if score #t cine matches 84 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -8.787 -165.000 -6.340 4.735
execute if score #t cine matches 85 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -8.929 -165.000 -6.340 4.735
execute if score #t cine matches 86 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -9.071 -165.000 -6.340 4.735
execute if score #t cine matches 87 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -9.213 -165.000 -6.340 4.735
execute if score #t cine matches 88 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -9.355 -165.000 -6.340 4.735
execute if score #t cine matches 89 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -9.497 -165.000 -6.340 4.735
execute if score #t cine matches 90 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -9.638 -165.000 -6.340 4.735
execute if score #t cine matches 91 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -9.780 -165.000 -6.340 4.735
execute if score #t cine matches 92 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -9.921 -165.000 -6.340 4.735
execute if score #t cine matches 93 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -10.062 -165.000 -6.340 4.735
execute if score #t cine matches 94 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -10.203 -165.000 -6.340 4.735
execute if score #t cine matches 95 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -10.343 -165.000 -6.340 4.735
execute if score #t cine matches 96 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -10.483 -165.000 -6.340 4.735
execute if score #t cine matches 97 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -10.623 -165.000 -6.340 4.735
execute if score #t cine matches 98 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -10.762 -165.000 -6.340 4.735
execute if score #t cine matches 99 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -10.901 -165.000 -6.340 4.735
execute if score #t cine matches 100 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -11.039 -165.000 -6.340 4.735
execute if score #t cine matches 101 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -11.176 -165.000 -6.340 4.735
execute if score #t cine matches 102 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -11.313 -165.000 -6.340 4.735
execute if score #t cine matches 103 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -11.450 -165.000 -6.340 4.735
execute if score #t cine matches 104 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -11.585 -165.000 -6.340 4.735
execute if score #t cine matches 105 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -11.720 -165.000 -6.340 4.735
execute if score #t cine matches 106 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -11.854 -165.000 -6.340 4.735
execute if score #t cine matches 107 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -11.987 -165.000 -6.340 4.735
execute if score #t cine matches 108 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -12.120 -165.000 -6.340 4.735
execute if score #t cine matches 109 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -12.251 -165.000 -6.340 4.735
execute if score #t cine matches 110 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -12.382 -165.000 -6.340 4.735
execute if score #t cine matches 111 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -12.511 -165.000 -6.340 4.735
execute if score #t cine matches 112 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -12.640 -165.000 -6.340 4.735
execute if score #t cine matches 113 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -12.767 -165.000 -6.340 4.735
execute if score #t cine matches 114 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -12.894 -165.000 -6.340 4.735
execute if score #t cine matches 115 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -13.019 -165.000 -6.340 4.735
execute if score #t cine matches 116 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -13.143 -165.000 -6.340 4.735
execute if score #t cine matches 117 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -13.266 -165.000 -6.340 4.735
execute if score #t cine matches 118 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -13.388 -165.000 -6.340 4.735
execute if score #t cine matches 119 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -13.508 -165.000 -6.340 4.735
execute if score #t cine matches 120 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -13.627 -165.000 -6.340 4.735
execute if score #t cine matches 121 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -13.745 -165.000 -6.340 4.735
execute if score #t cine matches 122 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -13.861 -165.000 -6.340 4.735
execute if score #t cine matches 123 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -13.976 -165.000 -6.340 4.735
execute if score #t cine matches 124 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -14.089 -165.000 -6.340 4.735
execute if score #t cine matches 125 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -14.201 -165.000 -6.340 4.735
execute if score #t cine matches 126 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -14.311 -165.000 -6.340 4.735
execute if score #t cine matches 127 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -14.420 -165.000 -6.340 4.735
execute if score #t cine matches 128 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -14.527 -165.000 -6.340 4.735
execute if score #t cine matches 129 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -14.632 -165.000 -6.340 4.735
execute if score #t cine matches 130 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -14.735 -165.000 -6.340 4.735
execute if score #t cine matches 131 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -14.837 -165.000 -6.340 4.735
execute if score #t cine matches 132 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -14.937 -165.000 -6.340 4.735
execute if score #t cine matches 133 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -15.035 -165.000 -6.340 4.735
execute if score #t cine matches 134 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -15.131 -165.000 -6.340 4.735
execute if score #t cine matches 135 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -15.225 -165.000 -6.340 4.735
execute if score #t cine matches 136 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -15.318 -165.000 -6.340 4.735
execute if score #t cine matches 137 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -15.408 -165.000 -6.340 4.735
execute if score #t cine matches 138 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -15.496 -165.000 -6.340 4.735
execute if score #t cine matches 139 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -15.582 -165.000 -6.340 4.735
execute if score #t cine matches 140 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -15.666 -165.000 -6.340 4.735
execute if score #t cine matches 141 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -15.748 -165.000 -6.340 4.735
execute if score #t cine matches 142 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -15.828 -165.000 -6.340 4.735
execute if score #t cine matches 143 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -15.905 -165.000 -6.340 4.735
execute if score #t cine matches 144 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -15.980 -165.000 -6.340 4.735
execute if score #t cine matches 145 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.053 -165.000 -6.340 4.735
execute if score #t cine matches 146 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.124 -165.000 -6.340 4.735
execute if score #t cine matches 147 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.192 -165.000 -6.340 4.735
execute if score #t cine matches 148 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.257 -165.000 -6.340 4.735
execute if score #t cine matches 149 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.320 -165.000 -6.340 4.735
execute if score #t cine matches 150 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.381 -165.000 -6.340 4.735
execute if score #t cine matches 151 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.439 -165.000 -6.340 4.735
execute if score #t cine matches 152 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.494 -165.000 -6.340 4.735
execute if score #t cine matches 153 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.547 -165.000 -6.340 4.735
execute if score #t cine matches 154 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.597 -165.000 -6.340 4.735
execute if score #t cine matches 155 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.644 -165.000 -6.340 4.735
execute if score #t cine matches 156 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.689 -165.000 -6.340 4.735
execute if score #t cine matches 157 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.731 -165.000 -6.340 4.735
execute if score #t cine matches 158 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.769 -165.000 -6.340 4.735
execute if score #t cine matches 159 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.805 -165.000 -6.340 4.735
execute if score #t cine matches 160 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.839 -165.000 -6.340 4.735
execute if score #t cine matches 161 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.869 -165.000 -6.340 4.735
execute if score #t cine matches 162 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.896 -165.000 -6.340 4.735
execute if score #t cine matches 163 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.920 -165.000 -6.340 4.735
execute if score #t cine matches 164 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.941 -165.000 -6.340 4.735
execute if score #t cine matches 165 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.959 -165.000 -6.340 4.735
execute if score #t cine matches 166 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.974 -165.000 -6.340 4.735
execute if score #t cine matches 167 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.985 -165.000 -6.340 4.735
execute if score #t cine matches 168 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.993 -165.000 -6.340 4.735
execute if score #t cine matches 169 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -16.998 -165.000 -6.340 4.735
execute if score #t cine matches 170 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -17.000 -165.000 -6.340 4.735
execute if score #t cine matches 2 run title @a[tag=cine] actionbar {"text":"La pompe tourne : la Cuve baisse…","color":"gray"}
execute if score #t cine matches 2 run execute as @a[tag=cine] at @s run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 10 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 27 run function atelier:station_vide_58
execute if score #t cine matches 35 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 39 run function atelier:station_vide_57
execute if score #t cine matches 48 run function atelier:station_vide_56
execute if score #t cine matches 57 run function atelier:station_vide_55
execute if score #t cine matches 60 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 64 run function atelier:station_vide_54
execute if score #t cine matches 72 run function atelier:station_vide_53
execute if score #t cine matches 79 run function atelier:station_vide_52
execute if score #t cine matches 85 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 86 run function atelier:station_vide_51
execute if score #t cine matches 93 run function atelier:station_vide_50
execute if score #t cine matches 100 run function atelier:station_vide_49
execute if score #t cine matches 108 run function atelier:station_vide_48
execute if score #t cine matches 110 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 115 run function atelier:station_vide_47
execute if score #t cine matches 124 run function atelier:station_vide_46
execute if score #t cine matches 133 run function atelier:station_vide_45
execute if score #t cine matches 135 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 145 run function atelier:station_vide_44
execute if score #t cine matches 166 run scoreboard players set #niv station 42
execute if score #t cine matches 166 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 0.8
execute if score #t cine matches 166 run title @a[tag=cine] actionbar {"text":"Niveau BAS","color":"aqua"}
execute if score #t cine matches 170 run function atelier:station_vide_43
