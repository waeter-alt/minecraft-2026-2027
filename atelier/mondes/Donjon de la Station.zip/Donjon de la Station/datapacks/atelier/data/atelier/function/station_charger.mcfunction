# [claude-build] A chaque chargement : les objectifs du donjon et des cinematiques, pas d'apparition de monstres.
scoreboard objectives add station dummy
scoreboard objectives add cine dummy
scoreboard objectives add cine_mode dummy
execute unless score #t cine matches 0.. run scoreboard players set #t cine 0
gamerule doMobSpawning false
bossbar add atelier:station "Station : pompes 0/3"
bossbar set atelier:station max 3
bossbar set atelier:station color blue
bossbar set atelier:station style notched_6
execute unless score #niv station matches -2147483648.. run scoreboard players set #niv station 0
execute unless score #pompes station matches -2147483648.. run scoreboard players set #pompes station 0
execute unless score #pA station matches -2147483648.. run scoreboard players set #pA station 0
execute unless score #pB station matches -2147483648.. run scoreboard players set #pB station 0
execute unless score #pC station matches -2147483648.. run scoreboard players set #pC station 0
execute unless score #a3 station matches -2147483648.. run scoreboard players set #a3 station 0
execute unless score #a4 station matches -2147483648.. run scoreboard players set #a4 station 0
execute unless score #b2 station matches -2147483648.. run scoreboard players set #b2 station 0
execute unless score #b3 station matches -2147483648.. run scoreboard players set #b3 station 0
execute unless score #rotor station matches -2147483648.. run scoreboard players set #rotor station 0
execute unless score #pl1 station matches -2147483648.. run scoreboard players set #pl1 station 0
execute unless score #pl2 station matches -2147483648.. run scoreboard players set #pl2 station 0
execute unless score #pl3 station matches -2147483648.. run scoreboard players set #pl3 station 0
execute unless score #vap station matches -2147483648.. run scoreboard players set #vap station 0
execute unless score #g1 station matches -2147483648.. run scoreboard players set #g1 station 0
execute unless score #g2 station matches -2147483648.. run scoreboard players set #g2 station 0
execute unless score #c1a station matches -2147483648.. run scoreboard players set #c1a station 0
execute unless score #c1b station matches -2147483648.. run scoreboard players set #c1b station 0
execute unless score #c1t station matches -2147483648.. run scoreboard players set #c1t station 0
execute unless score #w1 station matches -2147483648.. run scoreboard players set #w1 station 0
execute unless score #w3 station matches -2147483648.. run scoreboard players set #w3 station 0
execute unless score #d station matches -2147483648.. run scoreboard players set #d station 0
execute unless score #dvu station matches -2147483648.. run scoreboard players set #dvu station 0
execute unless score #lg station matches -2147483648.. run scoreboard players set #lg station 0
execute unless score #boss station matches -2147483648.. run scoreboard players set #boss station 0
execute unless score #rvn station matches -2147483648.. run scoreboard players set #rvn station 0
execute unless score #v1 station matches -2147483648.. run scoreboard players set #v1 station 0
execute unless score #v2 station matches -2147483648.. run scoreboard players set #v2 station 0
execute unless score #v3 station matches -2147483648.. run scoreboard players set #v3 station 0
execute unless score #temoins station matches -2147483648.. run scoreboard players set #temoins station 0
execute unless score #emb station matches -2147483648.. run scoreboard players set #emb station 0
execute unless score #eau station matches -2147483648.. run scoreboard players set #eau station 0
execute unless score #tic station matches -2147483648.. run scoreboard players set #tic station 0
execute unless score #obj station matches -2147483648.. run scoreboard players set #obj station 0
execute unless score #vest station matches -2147483648.. run scoreboard players set #vest station 0
execute unless score #cape station matches -2147483648.. run scoreboard players set #cape station 0
execute unless score #sasp station matches -2147483648.. run scoreboard players set #sasp station 0
