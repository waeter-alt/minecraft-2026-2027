# [claude-build] A chaque chargement : les objectifs du donjon et des cinematiques, pas d'apparition de monstres.
scoreboard objectives add station dummy
scoreboard objectives add cine dummy
scoreboard objectives add cine_mode dummy
execute unless score #t cine matches 0.. run scoreboard players set #t cine 0
gamerule doMobSpawning false
execute unless score #niv station matches -2147483648.. run scoreboard players set #niv station 0
execute unless score #pompes station matches -2147483648.. run scoreboard players set #pompes station 0
execute unless score #ecA station matches -2147483648.. run scoreboard players set #ecA station 0
execute unless score #ecB station matches -2147483648.. run scoreboard players set #ecB station 0
execute unless score #ecC station matches -2147483648.. run scoreboard players set #ecC station 0
execute unless score #galA station matches -2147483648.. run scoreboard players set #galA station 0
execute unless score #cache station matches -2147483648.. run scoreboard players set #cache station 0
execute unless score #pA station matches -2147483648.. run scoreboard players set #pA station 0
execute unless score #pB station matches -2147483648.. run scoreboard players set #pB station 0
execute unless score #pC station matches -2147483648.. run scoreboard players set #pC station 0
execute unless score #a3 station matches -2147483648.. run scoreboard players set #a3 station 0
execute unless score #a4 station matches -2147483648.. run scoreboard players set #a4 station 0
execute unless score #b2 station matches -2147483648.. run scoreboard players set #b2 station 0
execute unless score #b3 station matches -2147483648.. run scoreboard players set #b3 station 0
execute unless score #rotor station matches -2147483648.. run scoreboard players set #rotor station 0
execute unless score #pl1 station matches -2147483648.. run scoreboard players set #pl1 station 0
execute unless score #pl2 station matches -2147483648.. run scoreboard players set #pl2 station 0
execute unless score #pl3 station matches -2147483648.. run scoreboard players set #pl3 station 0
execute unless score #vap station matches -2147483648.. run scoreboard players set #vap station 0
execute unless score #t1 station matches -2147483648.. run scoreboard players set #t1 station 0
execute unless score #t2 station matches -2147483648.. run scoreboard players set #t2 station 0
execute unless score #t3 station matches -2147483648.. run scoreboard players set #t3 station 0
execute unless score #tar1 station matches -2147483648.. run scoreboard players set #tar1 station 0
execute unless score #tar2 station matches -2147483648.. run scoreboard players set #tar2 station 0
execute unless score #d station matches -2147483648.. run scoreboard players set #d station 0
execute unless score #galD station matches -2147483648.. run scoreboard players set #galD station 0
execute unless score #tard station matches -2147483648.. run scoreboard players set #tard station 0
execute unless score #td station matches -2147483648.. run scoreboard players set #td station 0
execute unless score #lg station matches -2147483648.. run scoreboard players set #lg station 0
execute unless score #boss station matches -2147483648.. run scoreboard players set #boss station 0
