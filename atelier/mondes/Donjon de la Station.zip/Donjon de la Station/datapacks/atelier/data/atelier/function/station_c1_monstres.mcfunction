# [claude-build] Un joueur entre : les monstres de « c1 » apparaissent (une seule fois).
scoreboard players set #w1 station 1
summon minecraft:drowned -8 -8 -198 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned -8 -8 -198 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:drowned 8 -8 -210 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned 8 -8 -210 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:drowned 6 -8 -194 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned 6 -8 -194 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:guardian -6 -6 -212 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned -6 -6 -212 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
