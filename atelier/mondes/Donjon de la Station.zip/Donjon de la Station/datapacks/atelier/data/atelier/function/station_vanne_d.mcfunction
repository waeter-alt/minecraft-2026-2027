# [claude-build] La vanne D se leve : la Cheminee est ouverte.
scoreboard players set #d station 1
setblock 17 -31 -168 minecraft:water
setblock 17 -30 -168 minecraft:water
setblock 17 -29 -168 minecraft:water
setblock 17 -28 -168 minecraft:water
setblock 17 -27 -168 minecraft:water
setblock 17 -26 -168 minecraft:water
setblock 18 -31 -168 minecraft:water
setblock 18 -30 -168 minecraft:water
setblock 18 -29 -168 minecraft:water
setblock 18 -28 -168 minecraft:water
setblock 18 -27 -168 minecraft:water
setblock 18 -26 -168 minecraft:water
setblock 19 -31 -167 minecraft:water
setblock 19 -30 -167 minecraft:water
setblock 19 -29 -167 minecraft:water
setblock 19 -28 -167 minecraft:water
setblock 19 -27 -167 minecraft:water
setblock 19 -26 -167 minecraft:water
setblock 20 -31 -167 minecraft:water
setblock 20 -30 -167 minecraft:water
setblock 20 -29 -167 minecraft:water
setblock 20 -28 -167 minecraft:water
setblock 20 -27 -167 minecraft:water
setblock 20 -26 -167 minecraft:water
setblock 20 -31 -166 minecraft:water
setblock 20 -30 -166 minecraft:water
setblock 20 -29 -166 minecraft:water
setblock 20 -28 -166 minecraft:water
setblock 20 -27 -166 minecraft:water
setblock 20 -26 -166 minecraft:water
setblock 21 -31 -166 minecraft:water
setblock 21 -30 -166 minecraft:water
setblock 21 -29 -166 minecraft:water
setblock 21 -28 -166 minecraft:water
setblock 21 -27 -166 minecraft:water
setblock 21 -26 -166 minecraft:water
setblock 21 -31 -165 minecraft:water
setblock 21 -30 -165 minecraft:water
setblock 21 -29 -165 minecraft:water
setblock 21 -28 -165 minecraft:water
setblock 21 -27 -165 minecraft:water
setblock 21 -26 -165 minecraft:water
execute positioned 17 -31 -168 run playsound minecraft:block.piston.contract master @a[distance=..80] ~ ~ ~ 3 0.5
tellraw @a {"text":"Au fond de la Cuve, au nord-est, la vanne D se leve.","color":"gold"}
title @a title {"text":"Va au fond de la Cuve","color":"gold"}
title @a subtitle {"text":"la vanne D est ouverte, au nord-est : la Cheminée","color":"aqua"}
