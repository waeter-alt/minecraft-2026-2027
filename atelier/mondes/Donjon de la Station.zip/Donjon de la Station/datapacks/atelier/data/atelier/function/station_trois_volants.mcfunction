# [claude-build] Les trois volants sont tournes : la vanne du Sas se leve et un casier s'ouvre au Vestiaire, en cinematique (ou tout de suite si une autre est en cours).
scoreboard players operation #libre cine = #t cine
execute if score #libre cine matches 0 run function atelier:station_cine_debut_sas
execute unless score #libre cine matches 0 run function atelier:station_sas_ouvrir
execute unless score #libre cine matches 0 run function atelier:station_casier
