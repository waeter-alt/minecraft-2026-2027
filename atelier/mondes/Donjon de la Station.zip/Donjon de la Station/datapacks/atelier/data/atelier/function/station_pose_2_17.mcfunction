# [claude-build] Pose de la station, etape 18 sur 21.
place template atelier:station_c -19 -15 -237
schedule function atelier:station_pose_2_18 2t
