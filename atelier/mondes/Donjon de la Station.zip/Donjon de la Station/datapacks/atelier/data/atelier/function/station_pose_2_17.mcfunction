# [claude-build] Pose de la station, etape 18 sur 20.
place template atelier:station_cheminee 18 -32 -203
schedule function atelier:station_pose_2_18 2t
