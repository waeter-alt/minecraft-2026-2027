# [claude-build] Cinematique « eau » : une image par tick (la camera), et ses evenements (sons, effets).
execute if score #t cine matches 1 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -28.000 -121.000 173.660 4.735
execute if score #t cine matches 2 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.998 -121.000 173.660 4.735
execute if score #t cine matches 3 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.994 -121.000 173.660 4.735
execute if score #t cine matches 4 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.987 -121.000 173.660 4.735
execute if score #t cine matches 5 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.976 -121.000 173.660 4.735
execute if score #t cine matches 6 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.963 -121.000 173.660 4.735
execute if score #t cine matches 7 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.946 -121.000 173.660 4.735
execute if score #t cine matches 8 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.927 -121.000 173.660 4.735
execute if score #t cine matches 9 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.905 -121.000 173.660 4.735
execute if score #t cine matches 10 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.880 -121.000 173.660 4.735
execute if score #t cine matches 11 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.852 -121.000 173.660 4.735
execute if score #t cine matches 12 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.822 -121.000 173.660 4.735
execute if score #t cine matches 13 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.788 -121.000 173.660 4.735
execute if score #t cine matches 14 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.752 -121.000 173.660 4.735
execute if score #t cine matches 15 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.713 -121.000 173.660 4.735
execute if score #t cine matches 16 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.672 -121.000 173.660 4.735
execute if score #t cine matches 17 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.627 -121.000 173.660 4.735
execute if score #t cine matches 18 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.580 -121.000 173.660 4.735
execute if score #t cine matches 19 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.530 -121.000 173.660 4.735
execute if score #t cine matches 20 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.478 -121.000 173.660 4.735
execute if score #t cine matches 21 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.423 -121.000 173.660 4.735
execute if score #t cine matches 22 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.365 -121.000 173.660 4.735
execute if score #t cine matches 23 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.305 -121.000 173.660 4.735
execute if score #t cine matches 24 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.242 -121.000 173.660 4.735
execute if score #t cine matches 25 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.177 -121.000 173.660 4.735
execute if score #t cine matches 26 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.109 -121.000 173.660 4.735
execute if score #t cine matches 27 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -27.038 -121.000 173.660 4.735
execute if score #t cine matches 28 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -26.965 -121.000 173.660 4.735
execute if score #t cine matches 29 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -26.890 -121.000 173.660 4.735
execute if score #t cine matches 30 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -26.812 -121.000 173.660 4.735
execute if score #t cine matches 31 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -26.732 -121.000 173.660 4.735
execute if score #t cine matches 32 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -26.649 -121.000 173.660 4.735
execute if score #t cine matches 33 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -26.564 -121.000 173.660 4.735
execute if score #t cine matches 34 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -26.477 -121.000 173.660 4.735
execute if score #t cine matches 35 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -26.387 -121.000 173.660 4.735
execute if score #t cine matches 36 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -26.295 -121.000 173.660 4.735
execute if score #t cine matches 37 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -26.200 -121.000 173.660 4.735
execute if score #t cine matches 38 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -26.103 -121.000 173.660 4.735
execute if score #t cine matches 39 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -26.004 -121.000 173.660 4.735
execute if score #t cine matches 40 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -25.903 -121.000 173.660 4.735
execute if score #t cine matches 41 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -25.799 -121.000 173.660 4.735
execute if score #t cine matches 42 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -25.694 -121.000 173.660 4.735
execute if score #t cine matches 43 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -25.586 -121.000 173.660 4.735
execute if score #t cine matches 44 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -25.476 -121.000 173.660 4.735
execute if score #t cine matches 45 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -25.363 -121.000 173.660 4.735
execute if score #t cine matches 46 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -25.249 -121.000 173.660 4.735
execute if score #t cine matches 47 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -25.132 -121.000 173.660 4.735
execute if score #t cine matches 48 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -25.014 -121.000 173.660 4.735
execute if score #t cine matches 49 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -24.893 -121.000 173.660 4.735
execute if score #t cine matches 50 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -24.770 -121.000 173.660 4.735
execute if score #t cine matches 51 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -24.646 -121.000 173.660 4.735
execute if score #t cine matches 52 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -24.519 -121.000 173.660 4.735
execute if score #t cine matches 53 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -24.390 -121.000 173.660 4.735
execute if score #t cine matches 54 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -24.260 -121.000 173.660 4.735
execute if score #t cine matches 55 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -24.127 -121.000 173.660 4.735
execute if score #t cine matches 56 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -23.992 -121.000 173.660 4.735
execute if score #t cine matches 57 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -23.856 -121.000 173.660 4.735
execute if score #t cine matches 58 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -23.717 -121.000 173.660 4.735
execute if score #t cine matches 59 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -23.577 -121.000 173.660 4.735
execute if score #t cine matches 60 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -23.435 -121.000 173.660 4.735
execute if score #t cine matches 61 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -23.291 -121.000 173.660 4.735
execute if score #t cine matches 62 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -23.145 -121.000 173.660 4.735
execute if score #t cine matches 63 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -22.998 -121.000 173.660 4.735
execute if score #t cine matches 64 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -22.848 -121.000 173.660 4.735
execute if score #t cine matches 65 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -22.697 -121.000 173.660 4.735
execute if score #t cine matches 66 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -22.545 -121.000 173.660 4.735
execute if score #t cine matches 67 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -22.390 -121.000 173.660 4.735
execute if score #t cine matches 68 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -22.234 -121.000 173.660 4.735
execute if score #t cine matches 69 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -22.076 -121.000 173.660 4.735
execute if score #t cine matches 70 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -21.917 -121.000 173.660 4.735
execute if score #t cine matches 71 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -21.756 -121.000 173.660 4.735
execute if score #t cine matches 72 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -21.593 -121.000 173.660 4.735
execute if score #t cine matches 73 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -21.429 -121.000 173.660 4.735
execute if score #t cine matches 74 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -21.263 -121.000 173.660 4.735
execute if score #t cine matches 75 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -21.095 -121.000 173.660 4.735
execute if score #t cine matches 76 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -20.926 -121.000 173.660 4.735
execute if score #t cine matches 77 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -20.756 -121.000 173.660 4.735
execute if score #t cine matches 78 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -20.584 -121.000 173.660 4.735
execute if score #t cine matches 79 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -20.411 -121.000 173.660 4.735
execute if score #t cine matches 80 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -20.236 -121.000 173.660 4.735
execute if score #t cine matches 81 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -20.060 -121.000 173.660 4.735
execute if score #t cine matches 82 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -19.882 -121.000 173.660 4.735
execute if score #t cine matches 83 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -19.703 -121.000 173.660 4.735
execute if score #t cine matches 84 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -19.522 -121.000 173.660 4.735
execute if score #t cine matches 85 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -19.341 -121.000 173.660 4.735
execute if score #t cine matches 86 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -19.158 -121.000 173.660 4.735
execute if score #t cine matches 87 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -18.973 -121.000 173.660 4.735
execute if score #t cine matches 88 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -18.788 -121.000 173.660 4.735
execute if score #t cine matches 89 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -18.601 -121.000 173.660 4.735
execute if score #t cine matches 90 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -18.412 -121.000 173.660 4.735
execute if score #t cine matches 91 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -18.223 -121.000 173.660 4.735
execute if score #t cine matches 92 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -18.032 -121.000 173.660 4.735
execute if score #t cine matches 93 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -17.841 -121.000 173.660 4.735
execute if score #t cine matches 94 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -17.648 -121.000 173.660 4.735
execute if score #t cine matches 95 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -17.454 -121.000 173.660 4.735
execute if score #t cine matches 96 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -17.258 -121.000 173.660 4.735
execute if score #t cine matches 97 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -17.062 -121.000 173.660 4.735
execute if score #t cine matches 98 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -16.865 -121.000 173.660 4.735
execute if score #t cine matches 99 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -16.666 -121.000 173.660 4.735
execute if score #t cine matches 100 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -16.467 -121.000 173.660 4.735
execute if score #t cine matches 101 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -16.266 -121.000 173.660 4.735
execute if score #t cine matches 102 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -16.065 -121.000 173.660 4.735
execute if score #t cine matches 103 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -15.862 -121.000 173.660 4.735
execute if score #t cine matches 104 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -15.659 -121.000 173.660 4.735
execute if score #t cine matches 105 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -15.455 -121.000 173.660 4.735
execute if score #t cine matches 106 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -15.249 -121.000 173.660 4.735
execute if score #t cine matches 107 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -15.043 -121.000 173.660 4.735
execute if score #t cine matches 108 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -14.836 -121.000 173.660 4.735
execute if score #t cine matches 109 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -14.628 -121.000 173.660 4.735
execute if score #t cine matches 110 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -14.419 -121.000 173.660 4.735
execute if score #t cine matches 111 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -14.210 -121.000 173.660 4.735
execute if score #t cine matches 112 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -13.999 -121.000 173.660 4.735
execute if score #t cine matches 113 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -13.788 -121.000 173.660 4.735
execute if score #t cine matches 114 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -13.576 -121.000 173.660 4.735
execute if score #t cine matches 115 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -13.364 -121.000 173.660 4.735
execute if score #t cine matches 116 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -13.150 -121.000 173.660 4.735
execute if score #t cine matches 117 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -12.936 -121.000 173.660 4.735
execute if score #t cine matches 118 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -12.721 -121.000 173.660 4.735
execute if score #t cine matches 119 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -12.506 -121.000 173.660 4.735
execute if score #t cine matches 120 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -12.290 -121.000 173.660 4.735
execute if score #t cine matches 121 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -12.073 -121.000 173.660 4.735
execute if score #t cine matches 122 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -11.856 -121.000 173.660 4.735
execute if score #t cine matches 123 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -11.638 -121.000 173.660 4.735
execute if score #t cine matches 124 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -11.420 -121.000 173.660 4.735
execute if score #t cine matches 125 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -11.201 -121.000 173.660 4.735
execute if score #t cine matches 126 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -10.981 -121.000 173.660 4.735
execute if score #t cine matches 127 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -10.761 -121.000 173.660 4.735
execute if score #t cine matches 128 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -10.541 -121.000 173.660 4.735
execute if score #t cine matches 129 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -10.320 -121.000 173.660 4.735
execute if score #t cine matches 130 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -10.099 -121.000 173.660 4.735
execute if score #t cine matches 131 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -9.877 -121.000 173.660 4.735
execute if score #t cine matches 132 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -9.655 -121.000 173.660 4.735
execute if score #t cine matches 133 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -9.433 -121.000 173.660 4.735
execute if score #t cine matches 134 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -9.210 -121.000 173.660 4.735
execute if score #t cine matches 135 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -8.987 -121.000 173.660 4.735
execute if score #t cine matches 136 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -8.763 -121.000 173.660 4.735
execute if score #t cine matches 137 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -8.539 -121.000 173.660 4.735
execute if score #t cine matches 138 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -8.315 -121.000 173.660 4.735
execute if score #t cine matches 139 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -8.091 -121.000 173.660 4.735
execute if score #t cine matches 140 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -7.867 -121.000 173.660 4.735
execute if score #t cine matches 141 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -7.642 -121.000 173.660 4.735
execute if score #t cine matches 142 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -7.417 -121.000 173.660 4.735
execute if score #t cine matches 143 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -7.192 -121.000 173.660 4.735
execute if score #t cine matches 144 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -6.966 -121.000 173.660 4.735
execute if score #t cine matches 145 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -6.741 -121.000 173.660 4.735
execute if score #t cine matches 146 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -6.516 -121.000 173.660 4.735
execute if score #t cine matches 147 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -6.290 -121.000 173.660 4.735
execute if score #t cine matches 148 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -6.064 -121.000 173.660 4.735
execute if score #t cine matches 149 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -5.839 -121.000 173.660 4.735
execute if score #t cine matches 150 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -5.613 -121.000 173.660 4.735
execute if score #t cine matches 151 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -5.387 -121.000 173.660 4.735
execute if score #t cine matches 152 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -5.161 -121.000 173.660 4.735
execute if score #t cine matches 153 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -4.936 -121.000 173.660 4.735
execute if score #t cine matches 154 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -4.710 -121.000 173.660 4.735
execute if score #t cine matches 155 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -4.484 -121.000 173.660 4.735
execute if score #t cine matches 156 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -4.259 -121.000 173.660 4.735
execute if score #t cine matches 157 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -4.034 -121.000 173.660 4.735
execute if score #t cine matches 158 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -3.808 -121.000 173.660 4.735
execute if score #t cine matches 159 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -3.583 -121.000 173.660 4.735
execute if score #t cine matches 160 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -3.358 -121.000 173.660 4.735
execute if score #t cine matches 161 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -3.133 -121.000 173.660 4.735
execute if score #t cine matches 162 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -2.909 -121.000 173.660 4.735
execute if score #t cine matches 163 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -2.685 -121.000 173.660 4.735
execute if score #t cine matches 164 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -2.461 -121.000 173.660 4.735
execute if score #t cine matches 165 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -2.237 -121.000 173.660 4.735
execute if score #t cine matches 166 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -2.013 -121.000 173.660 4.735
execute if score #t cine matches 167 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -1.790 -121.000 173.660 4.735
execute if score #t cine matches 168 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -1.567 -121.000 173.660 4.735
execute if score #t cine matches 169 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -1.345 -121.000 173.660 4.735
execute if score #t cine matches 170 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -1.123 -121.000 173.660 4.735
execute if score #t cine matches 171 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -0.901 -121.000 173.660 4.735
execute if score #t cine matches 172 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -0.680 -121.000 173.660 4.735
execute if score #t cine matches 173 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -0.459 -121.000 173.660 4.735
execute if score #t cine matches 174 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -0.239 -121.000 173.660 4.735
execute if score #t cine matches 175 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 -0.019 -121.000 173.660 4.735
execute if score #t cine matches 176 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 0.201 -121.000 173.660 4.735
execute if score #t cine matches 177 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 0.420 -121.000 173.660 4.735
execute if score #t cine matches 178 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 0.638 -121.000 173.660 4.735
execute if score #t cine matches 179 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 0.856 -121.000 173.660 4.735
execute if score #t cine matches 180 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 1.073 -121.000 173.660 4.735
execute if score #t cine matches 181 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 1.290 -121.000 173.660 4.735
execute if score #t cine matches 182 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 1.506 -121.000 173.660 4.735
execute if score #t cine matches 183 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 1.721 -121.000 173.660 4.735
execute if score #t cine matches 184 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 1.936 -121.000 173.660 4.735
execute if score #t cine matches 185 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 2.150 -121.000 173.660 4.735
execute if score #t cine matches 186 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 2.364 -121.000 173.660 4.735
execute if score #t cine matches 187 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 2.576 -121.000 173.660 4.735
execute if score #t cine matches 188 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 2.788 -121.000 173.660 4.735
execute if score #t cine matches 189 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 2.999 -121.000 173.660 4.735
execute if score #t cine matches 190 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 3.210 -121.000 173.660 4.735
execute if score #t cine matches 191 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 3.419 -121.000 173.660 4.735
execute if score #t cine matches 192 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 3.628 -121.000 173.660 4.735
execute if score #t cine matches 193 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 3.836 -121.000 173.660 4.735
execute if score #t cine matches 194 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 4.043 -121.000 173.660 4.735
execute if score #t cine matches 195 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 4.249 -121.000 173.660 4.735
execute if score #t cine matches 196 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 4.455 -121.000 173.660 4.735
execute if score #t cine matches 197 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 4.659 -121.000 173.660 4.735
execute if score #t cine matches 198 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 4.862 -121.000 173.660 4.735
execute if score #t cine matches 199 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 5.065 -121.000 173.660 4.735
execute if score #t cine matches 200 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 5.266 -121.000 173.660 4.735
execute if score #t cine matches 201 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 5.467 -121.000 173.660 4.735
execute if score #t cine matches 202 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 5.666 -121.000 173.660 4.735
execute if score #t cine matches 203 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 5.865 -121.000 173.660 4.735
execute if score #t cine matches 204 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 6.062 -121.000 173.660 4.735
execute if score #t cine matches 205 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 6.258 -121.000 173.660 4.735
execute if score #t cine matches 206 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 6.454 -121.000 173.660 4.735
execute if score #t cine matches 207 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 6.648 -121.000 173.660 4.735
execute if score #t cine matches 208 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 6.841 -121.000 173.660 4.735
execute if score #t cine matches 209 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 7.032 -121.000 173.660 4.735
execute if score #t cine matches 210 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 7.223 -121.000 173.660 4.735
execute if score #t cine matches 211 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 7.412 -121.000 173.660 4.735
execute if score #t cine matches 212 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 7.601 -121.000 173.660 4.735
execute if score #t cine matches 213 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 7.788 -121.000 173.660 4.735
execute if score #t cine matches 214 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 7.973 -121.000 173.660 4.735
execute if score #t cine matches 215 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 8.158 -121.000 173.660 4.735
execute if score #t cine matches 216 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 8.341 -121.000 173.660 4.735
execute if score #t cine matches 217 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 8.522 -121.000 173.660 4.735
execute if score #t cine matches 218 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 8.703 -121.000 173.660 4.735
execute if score #t cine matches 219 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 8.882 -121.000 173.660 4.735
execute if score #t cine matches 220 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 9.060 -121.000 173.660 4.735
execute if score #t cine matches 221 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 9.236 -121.000 173.660 4.735
execute if score #t cine matches 222 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 9.411 -121.000 173.660 4.735
execute if score #t cine matches 223 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 9.584 -121.000 173.660 4.735
execute if score #t cine matches 224 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 9.756 -121.000 173.660 4.735
execute if score #t cine matches 225 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 9.926 -121.000 173.660 4.735
execute if score #t cine matches 226 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 10.095 -121.000 173.660 4.735
execute if score #t cine matches 227 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 10.263 -121.000 173.660 4.735
execute if score #t cine matches 228 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 10.429 -121.000 173.660 4.735
execute if score #t cine matches 229 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 10.593 -121.000 173.660 4.735
execute if score #t cine matches 230 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 10.756 -121.000 173.660 4.735
execute if score #t cine matches 231 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 10.917 -121.000 173.660 4.735
execute if score #t cine matches 232 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 11.076 -121.000 173.660 4.735
execute if score #t cine matches 233 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 11.234 -121.000 173.660 4.735
execute if score #t cine matches 234 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 11.390 -121.000 173.660 4.735
execute if score #t cine matches 235 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 11.545 -121.000 173.660 4.735
execute if score #t cine matches 236 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 11.697 -121.000 173.660 4.735
execute if score #t cine matches 237 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 11.848 -121.000 173.660 4.735
execute if score #t cine matches 238 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 11.998 -121.000 173.660 4.735
execute if score #t cine matches 239 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 12.145 -121.000 173.660 4.735
execute if score #t cine matches 240 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 12.291 -121.000 173.660 4.735
execute if score #t cine matches 241 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 12.435 -121.000 173.660 4.735
execute if score #t cine matches 242 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 12.577 -121.000 173.660 4.735
execute if score #t cine matches 243 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 12.717 -121.000 173.660 4.735
execute if score #t cine matches 244 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 12.856 -121.000 173.660 4.735
execute if score #t cine matches 245 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 12.992 -121.000 173.660 4.735
execute if score #t cine matches 246 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 13.127 -121.000 173.660 4.735
execute if score #t cine matches 247 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 13.260 -121.000 173.660 4.735
execute if score #t cine matches 248 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 13.390 -121.000 173.660 4.735
execute if score #t cine matches 249 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 13.519 -121.000 173.660 4.735
execute if score #t cine matches 250 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 13.646 -121.000 173.660 4.735
execute if score #t cine matches 251 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 13.770 -121.000 173.660 4.735
execute if score #t cine matches 252 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 13.893 -121.000 173.660 4.735
execute if score #t cine matches 253 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 14.014 -121.000 173.660 4.735
execute if score #t cine matches 254 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 14.132 -121.000 173.660 4.735
execute if score #t cine matches 255 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 14.249 -121.000 173.660 4.735
execute if score #t cine matches 256 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 14.363 -121.000 173.660 4.735
execute if score #t cine matches 257 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 14.476 -121.000 173.660 4.735
execute if score #t cine matches 258 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 14.586 -121.000 173.660 4.735
execute if score #t cine matches 259 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 14.694 -121.000 173.660 4.735
execute if score #t cine matches 260 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 14.799 -121.000 173.660 4.735
execute if score #t cine matches 261 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 14.903 -121.000 173.660 4.735
execute if score #t cine matches 262 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 15.004 -121.000 173.660 4.735
execute if score #t cine matches 263 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 15.103 -121.000 173.660 4.735
execute if score #t cine matches 264 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 15.200 -121.000 173.660 4.735
execute if score #t cine matches 265 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 15.295 -121.000 173.660 4.735
execute if score #t cine matches 266 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 15.387 -121.000 173.660 4.735
execute if score #t cine matches 267 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 15.477 -121.000 173.660 4.735
execute if score #t cine matches 268 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 15.564 -121.000 173.660 4.735
execute if score #t cine matches 269 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 15.649 -121.000 173.660 4.735
execute if score #t cine matches 270 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 15.732 -121.000 173.660 4.735
execute if score #t cine matches 271 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 15.812 -121.000 173.660 4.735
execute if score #t cine matches 272 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 15.890 -121.000 173.660 4.735
execute if score #t cine matches 273 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 15.965 -121.000 173.660 4.735
execute if score #t cine matches 274 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.038 -121.000 173.660 4.735
execute if score #t cine matches 275 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.109 -121.000 173.660 4.735
execute if score #t cine matches 276 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.177 -121.000 173.660 4.735
execute if score #t cine matches 277 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.242 -121.000 173.660 4.735
execute if score #t cine matches 278 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.305 -121.000 173.660 4.735
execute if score #t cine matches 279 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.365 -121.000 173.660 4.735
execute if score #t cine matches 280 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.423 -121.000 173.660 4.735
execute if score #t cine matches 281 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.478 -121.000 173.660 4.735
execute if score #t cine matches 282 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.530 -121.000 173.660 4.735
execute if score #t cine matches 283 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.580 -121.000 173.660 4.735
execute if score #t cine matches 284 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.627 -121.000 173.660 4.735
execute if score #t cine matches 285 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.672 -121.000 173.660 4.735
execute if score #t cine matches 286 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.713 -121.000 173.660 4.735
execute if score #t cine matches 287 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.752 -121.000 173.660 4.735
execute if score #t cine matches 288 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.788 -121.000 173.660 4.735
execute if score #t cine matches 289 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.822 -121.000 173.660 4.735
execute if score #t cine matches 290 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.852 -121.000 173.660 4.735
execute if score #t cine matches 291 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.880 -121.000 173.660 4.735
execute if score #t cine matches 292 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.905 -121.000 173.660 4.735
execute if score #t cine matches 293 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.927 -121.000 173.660 4.735
execute if score #t cine matches 294 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.946 -121.000 173.660 4.735
execute if score #t cine matches 295 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.963 -121.000 173.660 4.735
execute if score #t cine matches 296 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.976 -121.000 173.660 4.735
execute if score #t cine matches 297 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.987 -121.000 173.660 4.735
execute if score #t cine matches 298 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.994 -121.000 173.660 4.735
execute if score #t cine matches 299 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 16.998 -121.000 173.660 4.735
execute if score #t cine matches 300 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 17.000 -121.000 173.660 4.735
execute if score #t cine matches 1 run function atelier:station_eau_31
execute if score #t cine matches 2 run title @a[tag=cine] actionbar {"text":"La station se met en route…","color":"gray"}
execute if score #t cine matches 2 run execute as @a[tag=cine] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 2 run execute as @a[tag=cine] at @s run playsound minecraft:block.piston.extend master @s ~ ~ ~ 1 0.4
execute if score #t cine matches 10 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 15 run execute positioned 0 26 -143 run particle minecraft:bubble_column_up ~ ~-40 ~ 12 2 12 0.1 200 force
execute if score #t cine matches 20 run function atelier:station_eau_32
execute if score #t cine matches 34 run function atelier:station_eau_33
execute if score #t cine matches 40 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 44 run function atelier:station_eau_34
execute if score #t cine matches 45 run execute positioned 0 26 -143 run particle minecraft:bubble_column_up ~ ~-40 ~ 12 2 12 0.1 200 force
execute if score #t cine matches 53 run function atelier:station_eau_35
execute if score #t cine matches 60 run function atelier:station_eau_36
execute if score #t cine matches 67 run function atelier:station_eau_37
execute if score #t cine matches 70 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 73 run function atelier:station_eau_38
execute if score #t cine matches 75 run execute positioned 0 26 -143 run particle minecraft:bubble_column_up ~ ~-40 ~ 12 2 12 0.1 200 force
execute if score #t cine matches 79 run function atelier:station_eau_39
execute if score #t cine matches 85 run function atelier:station_eau_40
execute if score #t cine matches 90 run function atelier:station_eau_41
execute if score #t cine matches 95 run function atelier:station_eau_42
execute if score #t cine matches 100 run function atelier:station_eau_43
execute if score #t cine matches 100 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 105 run function atelier:station_eau_44
execute if score #t cine matches 105 run execute positioned 0 26 -143 run particle minecraft:bubble_column_up ~ ~-40 ~ 12 2 12 0.1 200 force
execute if score #t cine matches 110 run function atelier:station_eau_45
execute if score #t cine matches 115 run function atelier:station_eau_46
execute if score #t cine matches 120 run function atelier:station_eau_47
execute if score #t cine matches 124 run function atelier:station_eau_48
execute if score #t cine matches 129 run function atelier:station_eau_49
execute if score #t cine matches 130 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 133 run function atelier:station_eau_50
execute if score #t cine matches 135 run execute positioned 0 26 -143 run particle minecraft:bubble_column_up ~ ~-40 ~ 12 2 12 0.1 200 force
execute if score #t cine matches 138 run function atelier:station_eau_51
execute if score #t cine matches 142 run function atelier:station_eau_52
execute if score #t cine matches 147 run function atelier:station_eau_53
execute if score #t cine matches 151 run function atelier:station_eau_54
execute if score #t cine matches 155 run function atelier:station_eau_55
execute if score #t cine matches 160 run function atelier:station_eau_56
execute if score #t cine matches 160 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 164 run function atelier:station_eau_57
execute if score #t cine matches 165 run execute positioned 0 26 -143 run particle minecraft:bubble_column_up ~ ~-40 ~ 12 2 12 0.1 200 force
execute if score #t cine matches 169 run function atelier:station_eau_58
execute if score #t cine matches 173 run function atelier:station_eau_59
execute if score #t cine matches 178 run function atelier:station_eau_60
execute if score #t cine matches 182 run function atelier:station_eau_61
execute if score #t cine matches 187 run function atelier:station_eau_62
execute if score #t cine matches 190 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 192 run function atelier:station_eau_63
execute if score #t cine matches 195 run execute positioned 0 26 -143 run particle minecraft:bubble_column_up ~ ~-40 ~ 12 2 12 0.1 200 force
execute if score #t cine matches 197 run function atelier:station_eau_64
execute if score #t cine matches 202 run function atelier:station_eau_65
execute if score #t cine matches 207 run function atelier:station_eau_66
execute if score #t cine matches 212 run function atelier:station_eau_67
execute if score #t cine matches 217 run function atelier:station_eau_68
execute if score #t cine matches 220 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 223 run function atelier:station_eau_69
execute if score #t cine matches 225 run execute positioned 0 26 -143 run particle minecraft:bubble_column_up ~ ~-40 ~ 12 2 12 0.1 200 force
execute if score #t cine matches 229 run function atelier:station_eau_70
execute if score #t cine matches 235 run function atelier:station_eau_71
execute if score #t cine matches 242 run function atelier:station_eau_72
execute if score #t cine matches 249 run function atelier:station_eau_73
execute if score #t cine matches 250 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 255 run execute positioned 0 26 -143 run particle minecraft:bubble_column_up ~ ~-40 ~ 12 2 12 0.1 200 force
execute if score #t cine matches 258 run function atelier:station_eau_74
execute if score #t cine matches 268 run function atelier:station_eau_75
execute if score #t cine matches 280 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.7
execute if score #t cine matches 282 run function atelier:station_eau_76
execute if score #t cine matches 285 run execute positioned 0 26 -143 run particle minecraft:bubble_column_up ~ ~-40 ~ 12 2 12 0.1 200 force
execute if score #t cine matches 286 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.0
execute if score #t cine matches 286 run title @a[tag=cine] actionbar {"text":"La Grande Cuve est pleine. Plonge !","color":"aqua"}
execute if score #t cine matches 290 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.26
execute if score #t cine matches 294 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
execute if score #t cine matches 296 run scoreboard players set #niv station 76
execute if score #t cine matches 296 run function atelier:station_bouches_ouvrir
