# [claude-build] Le volant du bassin de 50 m est grippe tant que l'embuscade n'est pas vaincue.
execute positioned 21 23 -50 run title @a[distance=..8] actionbar {"text":"Le volant est grippé : le bassin n'est pas sûr","color":"gray"}
