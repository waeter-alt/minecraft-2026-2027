# [claude-build] Le volant du bassin de 50 m ne repond pas tant que l'embuscade n'est pas vaincue : il revient en place.
setblock 27 23 -42 minecraft:lever[face=floor,facing=north,powered=false]
execute positioned 27 23 -42 run title @a[distance=..8] actionbar {"text":"Le volant est grippé : le bassin n'est pas sûr","color":"gray"}
