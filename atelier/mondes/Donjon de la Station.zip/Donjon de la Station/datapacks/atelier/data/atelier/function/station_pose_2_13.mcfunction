# [claude-build] Pose de la station, etape 14 sur 20.
place template atelier:station_hall -107 10 -107
schedule function atelier:station_pose_2_14 2t
