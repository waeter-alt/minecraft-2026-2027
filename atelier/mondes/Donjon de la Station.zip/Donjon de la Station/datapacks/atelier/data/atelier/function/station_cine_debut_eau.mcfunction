# [claude-build] Lance la cinematique « eau » : la camera, puis les joueurs proches (en spectateur, par les yeux de la camera).
scoreboard players set #id cine 12
scoreboard players set #t cine 1
scoreboard players set #nb cine 0
summon minecraft:armor_stand 4.000 -28.000 -121.000 {Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["cine_cam"],Rotation:[173.660f,4.735f]}
execute positioned 0 26 -143 as @a[distance=..50,gamemode=!spectator] at @s run function atelier:station_cine_joueur
