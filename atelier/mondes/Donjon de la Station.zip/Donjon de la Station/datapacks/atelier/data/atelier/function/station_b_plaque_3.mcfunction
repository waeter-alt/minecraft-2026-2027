# [claude-build] Plaque lestee 3 : un joueur se tient debout dessus (au fond, pas en nageant).
scoreboard players set #pl3 station 1
# ouvre la colonne de bulles vers la halle haute
setblock 88 -11 -144 minecraft:water
setblock 88 -11 -143 minecraft:water
setblock 88 -11 -142 minecraft:water
setblock 89 -11 -144 minecraft:water
setblock 89 -11 -143 minecraft:water
setblock 89 -11 -142 minecraft:water
setblock 90 -11 -144 minecraft:water
setblock 90 -11 -143 minecraft:water
setblock 90 -11 -142 minecraft:water
setblock 88 -23 -144 minecraft:soul_sand
setblock 88 -23 -143 minecraft:soul_sand
setblock 88 -23 -142 minecraft:soul_sand
setblock 89 -23 -144 minecraft:soul_sand
setblock 89 -23 -143 minecraft:soul_sand
setblock 89 -23 -142 minecraft:soul_sand
setblock 90 -23 -144 minecraft:soul_sand
setblock 90 -23 -143 minecraft:soul_sand
setblock 90 -23 -142 minecraft:soul_sand
tellraw @a {"text":"Une colonne de bulles monte vers la halle haute.","color":"gold"}
execute positioned 102 -22 -128 run particle minecraft:wax_on ~ ~0.2 ~ 1 0.1 1 0.1 30
execute positioned 102 -22 -128 run playsound minecraft:block.copper_bulb.turn_on master @a[distance=..40] ~ ~ ~ 2 0.7
