# [claude-build] Le Leviathan (mod grappin). A part : si l'entite manque, seule cette fonction est refusee au chargement.
summon donjon:leviathan 10 -50 -153 {Tags:["station_boss","station_emb"],PersistenceRequired:1b}
