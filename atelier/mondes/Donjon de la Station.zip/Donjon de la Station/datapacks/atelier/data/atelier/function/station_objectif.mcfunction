# [claude-build] L'objectif du moment, en barre d'action, et la barre des pompes, pour qui est dans la station (toutes les 2 s).
scoreboard players set #obj station 0
bossbar set atelier:station players @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239]
execute if score #temoins station matches ..2 run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar [{"text":"Hall : tourne les 3 volants (","color":"aqua"},{"score":{"name":"#temoins","objective":"station"},"color":"white"},{"text":"/3) — clic droit maintenu","color":"aqua"}]
execute if score #temoins station matches 3 if score #eau station matches 0 run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"Prends la Cape lestée au Vestiaire (à l'ouest), puis passe le Sas (au nord)","color":"aqua"}
execute if score #eau station matches 1 unless score #niv station matches 1.. run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"La Grande Cuve se remplit…","color":"aqua"}
execute if score #niv station matches 1.. if score #pompes station matches ..2 run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar [{"text":"Plonge : bouches A (ouest), B (est), C (nord). Pompes ","color":"aqua"},{"score":{"name":"#pompes","objective":"station"},"color":"white"},{"text":"/3","color":"aqua"}]
execute if score #pompes station matches 3 if score #lg station matches 0 run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"La vanne D est ouverte : la Cheminée, au fond nord-est de la Cuve","color":"gold"}
execute if score #lg station matches 1 if score #boss station matches 0 run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"Saute du plongeoir dans le tourbillon","color":"gold"}
execute if score #boss station matches 1 run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"Abats le Léviathan","color":"red"}
execute if score #boss station matches 2 run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"L'Exutoire est ouvert, au sud du Réservoir","color":"gold"}
execute if score #pA station matches 0 run title @a[x=-118,y=-2,z=-235,dx=86,dy=14,dz=96] actionbar {"text":"Filtration : la pompe A est au bout, à l'ouest, après la salle des lits.","color":"yellow"}
execute if score #pB station matches 0 run title @a[x=31,y=-32,z=-168,dx=77,dy=42,dz=51] actionbar {"text":"Chaufferie : marche au fond contre le courant, 3 plaques, puis la pompe B au grappin, à l'est de la halle haute.","color":"yellow"}
execute if score #pC station matches 0 run title @a[x=-20,y=-15,z=-236,dx=40,dy=48,dz=62] actionbar {"text":"Turbines : nage contre chaque turbine pour la lancer ; la pompe C est tout en haut.","color":"yellow"}
