# [claude-build] L'objectif du moment, en barre d'action, et la barre des pompes, pour qui est dans la station (toutes les 2 s).
scoreboard players set #obj station 0
bossbar set atelier:station players @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239]
execute if score #temoins station matches ..2 run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar [{"text":"Hall : tourne les 3 valves (","color":"aqua"},{"score":{"name":"#temoins","objective":"station"},"color":"white"},{"text":"/3)","color":"aqua"}]
execute if score #temoins station matches 3 if score #cape station matches 0 run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"Prends la Cape lestée au Vestiaire","color":"aqua"}
execute if score #cape station matches 1 if score #eau station matches 0 run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"Tire le levier qui est apparu au Vestiaire","color":"aqua"}
execute if score #eau station matches 1 unless score #niv station matches 1.. run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"La Grande Cuve se remplit…","color":"aqua"}
execute if score #pompes station matches 3 if score #lg station matches 0 run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"La vanne D est ouverte : la Cheminée, au fond de la Cuve","color":"gold"}
execute if score #lg station matches 1 if score #boss station matches 0 run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"Saute du plongeoir dans le tourbillon","color":"gold"}
execute if score #boss station matches 1 if entity @e[tag=station_cristal] run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"Brise les cristaux : ils soignent le Léviathan","color":"aqua"}
execute if score #boss station matches 1 unless entity @e[tag=station_cristal] run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"Abats le Léviathan","color":"red"}
execute if score #boss station matches 2 run title @a[x=-120,y=-62,z=-238,dx=239,dy=116,dz=239] actionbar {"text":"L'Exutoire est ouvert, près du Réservoir","color":"gold"}
