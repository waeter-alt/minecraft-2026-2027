# [claude-build] La fente de la chambre cachee : ses deux vannes s'ouvrent pour 2,5 s.
scoreboard players set #cache station 50
setblock -68 0 -194 minecraft:water
setblock -68 1 -194 minecraft:water
setblock -68 0 -192 minecraft:water
setblock -68 1 -192 minecraft:water
