# [claude-build] Pose de la station, etape 19 sur 20.
place template atelier:station_reservoir -45 -62 -188
schedule function atelier:station_pose_2_19 2t
