# [claude-build] Pose de la station, etape 19 sur 20.
place template atelier:station_cheminee 18 -32 -203
schedule function atelier:station_pose_2_19 2t
