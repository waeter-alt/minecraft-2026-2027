# [claude-build] La vanne D se leve : sa rangee 36 disparait (de bas en haut).
setblock 17 -26 -168 minecraft:water
setblock 18 -26 -168 minecraft:water
setblock 19 -26 -167 minecraft:water
setblock 20 -26 -167 minecraft:water
setblock 20 -26 -166 minecraft:water
setblock 21 -26 -166 minecraft:water
setblock 21 -26 -165 minecraft:water
execute positioned 20 -26 -167 run particle minecraft:bubble_column_up ~0.5 ~ ~0.5 1.2 0.3 1.2 0.2 40 force
execute positioned 20 -26 -167 run playsound minecraft:block.piston.contract master @a[distance=..120] ~ ~ ~ 2 0.90
