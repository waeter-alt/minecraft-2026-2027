# [claude-build] Pose de la station, etape 16 sur 20.
place template atelier:station_b 31 -32 -169
schedule function atelier:station_pose_2_16 2t
