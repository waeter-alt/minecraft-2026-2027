# [claude-build] Pose de la station, etape 16 sur 21.
place template atelier:station_a -120 -2 -236
schedule function atelier:station_pose_2_16 2t
