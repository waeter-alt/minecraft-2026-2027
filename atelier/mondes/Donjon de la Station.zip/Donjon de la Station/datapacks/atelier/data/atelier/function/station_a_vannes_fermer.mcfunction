# [claude-build] Les quatre vannes de la galerie se referment.
scoreboard players set #galA station 0
fill -45 2 -156 -43 4 -156 minecraft:iron_bars[waterlogged=true]
fill -45 2 -168 -43 4 -168 minecraft:iron_bars[waterlogged=true]
fill -45 2 -180 -43 4 -180 minecraft:iron_bars[waterlogged=true]
fill -45 2 -192 -43 4 -192 minecraft:iron_bars[waterlogged=true]
execute positioned -45 2 -156 run playsound minecraft:block.piston.extend master @a[distance=..60] ~ ~ ~ 2 0.6
