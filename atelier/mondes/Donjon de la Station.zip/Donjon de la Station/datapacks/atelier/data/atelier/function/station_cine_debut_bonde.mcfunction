# [claude-build] Lance la cinematique « bonde » : la camera, puis les joueurs proches (en spectateur, par les yeux de la camera).
scoreboard players set #id cine 11
scoreboard players set #t cine 1
scoreboard players set #nb cine 0
summon minecraft:armor_stand 12.856 12.000 -158.321 {Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["cine_cam"],Rotation:[40.000f,65.308f]}
execute positioned 0 22 -143 as @a[distance=..400,gamemode=!spectator] at @s run function atelier:station_cine_joueur
