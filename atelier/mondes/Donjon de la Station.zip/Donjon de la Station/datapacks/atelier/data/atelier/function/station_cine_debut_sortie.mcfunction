# [claude-build] Lance la cinematique « sortie » : la camera, puis les joueurs proches (en spectateur, par les yeux de la camera).
scoreboard players set #id cine 15
scoreboard players set #t cine 1
scoreboard players set #nb cine 0
summon minecraft:armor_stand 3.500 -55.000 -117.500 {Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b,Invulnerable:1b,Tags:["cine_cam"],Rotation:[8.531f,11.188f]}
execute positioned 10 -50 -153 as @a[distance=..120,gamemode=!spectator] at @s run function atelier:station_cine_joueur
