# [claude-build] La vanne D se leve : sa rangee 31 disparait (de bas en haut).
setblock 17 -31 -168 minecraft:water
setblock 18 -31 -168 minecraft:water
setblock 19 -31 -167 minecraft:water
setblock 20 -31 -167 minecraft:water
setblock 20 -31 -166 minecraft:water
setblock 21 -31 -166 minecraft:water
setblock 21 -31 -165 minecraft:water
execute positioned 20 -31 -167 run particle minecraft:bubble_column_up ~0.5 ~ ~0.5 1.2 0.3 1.2 0.2 40 force
execute positioned 20 -31 -167 run playsound minecraft:block.piston.contract master @a[distance=..120] ~ ~ ~ 2 0.50
