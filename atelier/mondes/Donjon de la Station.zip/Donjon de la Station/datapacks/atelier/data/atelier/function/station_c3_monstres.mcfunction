# [claude-build] Un joueur entre : les monstres de « c3 » apparaissent (une seule fois).
scoreboard players set #w3 station 1
summon minecraft:drowned -8 17 -198 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned -8 17 -198 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:drowned 8 17 -210 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned 8 17 -210 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:drowned 6 17 -194 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned 6 17 -194 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:guardian -6 17 -212 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned -6 17 -212 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
