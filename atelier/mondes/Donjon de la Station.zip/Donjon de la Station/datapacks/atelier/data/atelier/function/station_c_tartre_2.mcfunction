# [claude-build] Le tartre de la grille 2 se brise.
scoreboard players set #tar2 station 1
setblock -12 14 -206 minecraft:water
setblock -12 14 -205 minecraft:water
setblock -12 14 -204 minecraft:water
setblock -12 14 -203 minecraft:water
setblock -12 14 -202 minecraft:water
setblock -11 14 -206 minecraft:water
setblock -11 14 -205 minecraft:water
setblock -11 14 -204 minecraft:water
setblock -11 14 -203 minecraft:water
setblock -11 14 -202 minecraft:water
setblock -10 14 -206 minecraft:water
setblock -10 14 -205 minecraft:water
setblock -10 14 -204 minecraft:water
setblock -10 14 -203 minecraft:water
setblock -10 14 -202 minecraft:water
setblock -9 14 -206 minecraft:water
setblock -9 14 -205 minecraft:water
setblock -9 14 -204 minecraft:water
setblock -9 14 -203 minecraft:water
setblock -9 14 -202 minecraft:water
setblock -8 14 -206 minecraft:water
setblock -8 14 -205 minecraft:water
setblock -8 14 -204 minecraft:water
setblock -8 14 -203 minecraft:water
setblock -8 14 -202 minecraft:water
execute positioned -10 14 -204 run particle minecraft:block{block_state:{Name:"minecraft:dripstone_block"}} ~ ~ ~ 2 0.5 2 0.1 80
execute positioned -10 14 -204 run playsound minecraft:block.dripstone_block.break master @a[distance=..40] ~ ~ ~ 2 0.6
