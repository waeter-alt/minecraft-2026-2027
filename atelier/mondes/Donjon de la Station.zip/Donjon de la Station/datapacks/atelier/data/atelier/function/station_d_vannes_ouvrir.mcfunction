# [claude-build] Cheminee, galerie : les trois vannes s'ouvrent pour 3,0 s.
scoreboard players set #galD station 60
setblock 23 -31 -173 minecraft:water
setblock 23 -30 -173 minecraft:water
setblock 23 -29 -173 minecraft:water
setblock 24 -31 -172 minecraft:water
setblock 24 -30 -172 minecraft:water
setblock 24 -29 -172 minecraft:water
setblock 27 -31 -177 minecraft:water
setblock 27 -30 -177 minecraft:water
setblock 27 -29 -177 minecraft:water
setblock 28 -31 -177 minecraft:water
setblock 28 -30 -177 minecraft:water
setblock 28 -29 -177 minecraft:water
setblock 28 -31 -176 minecraft:water
setblock 28 -30 -176 minecraft:water
setblock 28 -29 -176 minecraft:water
setblock 30 -31 -182 minecraft:water
setblock 30 -30 -182 minecraft:water
setblock 30 -29 -182 minecraft:water
setblock 31 -31 -182 minecraft:water
setblock 31 -30 -182 minecraft:water
setblock 31 -29 -182 minecraft:water
setblock 32 -31 -181 minecraft:water
setblock 32 -30 -181 minecraft:water
setblock 32 -29 -181 minecraft:water
execute positioned 23 -31 -173 run playsound minecraft:block.piston.contract master @a[distance=..40] ~ ~ ~ 2 0.6
