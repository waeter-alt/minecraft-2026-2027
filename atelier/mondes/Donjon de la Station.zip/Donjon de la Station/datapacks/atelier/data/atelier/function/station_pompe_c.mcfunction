# [claude-build] Le volant C est tourne : la pompe C repart.
scoreboard players set #pC station 1
execute positioned -6 24 -233 run particle minecraft:bubble_column_up ~ ~2 ~ 1 2 1 0.2 100
execute positioned -6 24 -233 run playsound minecraft:block.beacon.power_select master @a[distance=..80] ~ ~ ~ 2 0.6
tellraw @a {"text":"La pompe C (Turbines) tourne.","color":"aqua"}
function atelier:station_pompe_faite
