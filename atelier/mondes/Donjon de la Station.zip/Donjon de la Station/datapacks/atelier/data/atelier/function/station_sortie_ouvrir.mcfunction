# [claude-build] L'Exutoire s'ouvre, au sud du Reservoir : la vanne disparait, le sable des ames fait monter le courant jusqu'a la salle de sortie.
setblock -2 -61 -98 minecraft:water
setblock -2 -60 -98 minecraft:water
setblock -2 -59 -98 minecraft:water
setblock -2 -58 -98 minecraft:water
setblock -1 -61 -98 minecraft:water
setblock -1 -60 -98 minecraft:water
setblock -1 -59 -98 minecraft:water
setblock -1 -58 -98 minecraft:water
setblock 0 -61 -98 minecraft:water
setblock 0 -60 -98 minecraft:water
setblock 0 -59 -98 minecraft:water
setblock 0 -58 -98 minecraft:water
setblock 1 -61 -98 minecraft:water
setblock 1 -60 -98 minecraft:water
setblock 1 -59 -98 minecraft:water
setblock 1 -58 -98 minecraft:water
setblock 2 -61 -98 minecraft:water
setblock 2 -60 -98 minecraft:water
setblock 2 -59 -98 minecraft:water
setblock 2 -58 -98 minecraft:water
setblock -1 -62 -96 minecraft:soul_sand
setblock -1 -62 -95 minecraft:soul_sand
setblock -1 -62 -94 minecraft:soul_sand
setblock 0 -62 -96 minecraft:soul_sand
setblock 0 -62 -95 minecraft:soul_sand
setblock 0 -62 -94 minecraft:soul_sand
setblock 1 -62 -96 minecraft:soul_sand
setblock 1 -62 -95 minecraft:soul_sand
setblock 1 -62 -94 minecraft:soul_sand
execute positioned 0.5 -59 -97.5 run particle minecraft:bubble_column_up ~ ~-1 ~ 2 1 1 0.2 120 force
execute positioned 0.5 -59 -97.5 run particle minecraft:end_rod ~ ~ ~ 2 1.5 0.5 0.03 60 force
playsound minecraft:block.piston.extend master @a 0.5 -59 -97.5 4 0.5
playsound minecraft:block.beacon.activate master @a 0.5 -59 -97.5 3 1.2
