# [claude-build] Pose de la station, etape 13 sur 20.
place template atelier:station_cuve -36 -32 -179
schedule function atelier:station_pose_2_13 2t
