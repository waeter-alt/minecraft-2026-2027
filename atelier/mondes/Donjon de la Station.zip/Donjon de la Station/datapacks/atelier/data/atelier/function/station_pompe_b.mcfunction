# [claude-build] Le volant B est tourne : la pompe B repart ; l'echelle de sortie vers les chaudieres s'ouvre.
scoreboard players set #pB station 1
setblock 70 -11 -166 minecraft:air
execute positioned 107 2 -141 run particle minecraft:large_smoke ~ ~2 ~ 0.5 2 0.5 0.05 60
execute positioned 107 2 -141 run playsound minecraft:block.beacon.power_select master @a[distance=..80] ~ ~ ~ 2 0.6
tellraw @a {"text":"La pompe B (Chaufferie) tourne. Une echelle redescend vers les chaudieres.","color":"aqua"}
function atelier:station_pompe_faite
