# [claude-build] La Cuve passe d'un coup au niveau median (58).
function atelier:station_vide_76
function atelier:station_vide_75
function atelier:station_vide_74
function atelier:station_vide_73
function atelier:station_vide_72
function atelier:station_vide_71
function atelier:station_vide_70
function atelier:station_vide_69
function atelier:station_vide_68
function atelier:station_vide_67
function atelier:station_vide_66
function atelier:station_vide_65
function atelier:station_vide_64
function atelier:station_vide_63
function atelier:station_vide_62
function atelier:station_vide_61
function atelier:station_vide_60
function atelier:station_vide_59
scoreboard players set #niv station 58
tellraw @a {"text":"La Grande Cuve baisse : niveau MEDIAN.","color":"aqua"}
