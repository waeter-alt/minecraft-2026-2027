# [claude-build] La vanne D est levee : la Cheminee est ouverte (fin de la cinematique).
scoreboard players set #d station 1
tellraw @a {"text":"Au fond de la Cuve, au nord-est, la vanne D est ouverte.","color":"gold"}
