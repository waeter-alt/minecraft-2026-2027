# [claude-build] La turbine T1 est lancee : elle tourne et pousse l'eau vers le haut ; une vague de monstres arrive.
scoreboard players set #t1 station 1000
execute positioned 0 -10 -204 run playsound minecraft:block.beacon.activate master @a[distance=..60] ~ ~ ~ 2 0.6
tellraw @a {"text":"La turbine T1 tourne.","color":"aqua"}
summon minecraft:drowned -8 -8 -198 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:drowned 8 -8 -210 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:drowned 6 -8 -194 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:guardian -6 -6 -212 {Tags:["station_emb"],PersistenceRequired:1b}
setblock 0 -14 -204 create:creative_motor[facing=up]
setblock -11 -15 -205 minecraft:soul_sand
setblock -11 -15 -204 minecraft:soul_sand
setblock -11 -15 -203 minecraft:soul_sand
setblock -10 -15 -205 minecraft:soul_sand
setblock -10 -15 -204 minecraft:soul_sand
setblock -10 -15 -203 minecraft:soul_sand
setblock -9 -15 -205 minecraft:soul_sand
setblock -9 -15 -204 minecraft:soul_sand
setblock -9 -15 -203 minecraft:soul_sand
