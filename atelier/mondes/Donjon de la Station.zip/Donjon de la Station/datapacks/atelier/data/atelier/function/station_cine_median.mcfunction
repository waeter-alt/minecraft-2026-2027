# [claude-build] Cinematique « median » : une image par tick (la camera), et ses evenements (sons, effets).
execute if score #t cine matches 1 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 17.000 -165.000 -6.340 4.735
execute if score #t cine matches 2 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.998 -165.000 -6.340 4.735
execute if score #t cine matches 3 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.992 -165.000 -6.340 4.735
execute if score #t cine matches 4 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.983 -165.000 -6.340 4.735
execute if score #t cine matches 5 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.970 -165.000 -6.340 4.735
execute if score #t cine matches 6 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.954 -165.000 -6.340 4.735
execute if score #t cine matches 7 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.934 -165.000 -6.340 4.735
execute if score #t cine matches 8 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.910 -165.000 -6.340 4.735
execute if score #t cine matches 9 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.883 -165.000 -6.340 4.735
execute if score #t cine matches 10 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.852 -165.000 -6.340 4.735
execute if score #t cine matches 11 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.818 -165.000 -6.340 4.735
execute if score #t cine matches 12 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.781 -165.000 -6.340 4.735
execute if score #t cine matches 13 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.741 -165.000 -6.340 4.735
execute if score #t cine matches 14 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.697 -165.000 -6.340 4.735
execute if score #t cine matches 15 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.650 -165.000 -6.340 4.735
execute if score #t cine matches 16 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.600 -165.000 -6.340 4.735
execute if score #t cine matches 17 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.547 -165.000 -6.340 4.735
execute if score #t cine matches 18 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.490 -165.000 -6.340 4.735
execute if score #t cine matches 19 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.431 -165.000 -6.340 4.735
execute if score #t cine matches 20 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.369 -165.000 -6.340 4.735
execute if score #t cine matches 21 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.303 -165.000 -6.340 4.735
execute if score #t cine matches 22 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.235 -165.000 -6.340 4.735
execute if score #t cine matches 23 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.164 -165.000 -6.340 4.735
execute if score #t cine matches 24 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.091 -165.000 -6.340 4.735
execute if score #t cine matches 25 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 16.014 -165.000 -6.340 4.735
execute if score #t cine matches 26 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 15.935 -165.000 -6.340 4.735
execute if score #t cine matches 27 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 15.853 -165.000 -6.340 4.735
execute if score #t cine matches 28 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 15.768 -165.000 -6.340 4.735
execute if score #t cine matches 29 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 15.681 -165.000 -6.340 4.735
execute if score #t cine matches 30 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 15.592 -165.000 -6.340 4.735
execute if score #t cine matches 31 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 15.500 -165.000 -6.340 4.735
execute if score #t cine matches 32 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 15.405 -165.000 -6.340 4.735
execute if score #t cine matches 33 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 15.308 -165.000 -6.340 4.735
execute if score #t cine matches 34 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 15.209 -165.000 -6.340 4.735
execute if score #t cine matches 35 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 15.108 -165.000 -6.340 4.735
execute if score #t cine matches 36 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 15.004 -165.000 -6.340 4.735
execute if score #t cine matches 37 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 14.898 -165.000 -6.340 4.735
execute if score #t cine matches 38 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 14.789 -165.000 -6.340 4.735
execute if score #t cine matches 39 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 14.679 -165.000 -6.340 4.735
execute if score #t cine matches 40 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 14.567 -165.000 -6.340 4.735
execute if score #t cine matches 41 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 14.452 -165.000 -6.340 4.735
execute if score #t cine matches 42 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 14.336 -165.000 -6.340 4.735
execute if score #t cine matches 43 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 14.217 -165.000 -6.340 4.735
execute if score #t cine matches 44 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 14.097 -165.000 -6.340 4.735
execute if score #t cine matches 45 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 13.975 -165.000 -6.340 4.735
execute if score #t cine matches 46 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 13.851 -165.000 -6.340 4.735
execute if score #t cine matches 47 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 13.725 -165.000 -6.340 4.735
execute if score #t cine matches 48 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 13.598 -165.000 -6.340 4.735
execute if score #t cine matches 49 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 13.469 -165.000 -6.340 4.735
execute if score #t cine matches 50 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 13.338 -165.000 -6.340 4.735
execute if score #t cine matches 51 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 13.206 -165.000 -6.340 4.735
execute if score #t cine matches 52 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 13.072 -165.000 -6.340 4.735
execute if score #t cine matches 53 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 12.936 -165.000 -6.340 4.735
execute if score #t cine matches 54 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 12.799 -165.000 -6.340 4.735
execute if score #t cine matches 55 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 12.661 -165.000 -6.340 4.735
execute if score #t cine matches 56 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 12.522 -165.000 -6.340 4.735
execute if score #t cine matches 57 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 12.381 -165.000 -6.340 4.735
execute if score #t cine matches 58 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 12.238 -165.000 -6.340 4.735
execute if score #t cine matches 59 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 12.095 -165.000 -6.340 4.735
execute if score #t cine matches 60 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 11.950 -165.000 -6.340 4.735
execute if score #t cine matches 61 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 11.805 -165.000 -6.340 4.735
execute if score #t cine matches 62 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 11.658 -165.000 -6.340 4.735
execute if score #t cine matches 63 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 11.510 -165.000 -6.340 4.735
execute if score #t cine matches 64 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 11.361 -165.000 -6.340 4.735
execute if score #t cine matches 65 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 11.211 -165.000 -6.340 4.735
execute if score #t cine matches 66 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 11.060 -165.000 -6.340 4.735
execute if score #t cine matches 67 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 10.908 -165.000 -6.340 4.735
execute if score #t cine matches 68 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 10.756 -165.000 -6.340 4.735
execute if score #t cine matches 69 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 10.603 -165.000 -6.340 4.735
execute if score #t cine matches 70 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 10.449 -165.000 -6.340 4.735
execute if score #t cine matches 71 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 10.294 -165.000 -6.340 4.735
execute if score #t cine matches 72 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 10.138 -165.000 -6.340 4.735
execute if score #t cine matches 73 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 9.982 -165.000 -6.340 4.735
execute if score #t cine matches 74 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 9.826 -165.000 -6.340 4.735
execute if score #t cine matches 75 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 9.669 -165.000 -6.340 4.735
execute if score #t cine matches 76 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 9.511 -165.000 -6.340 4.735
execute if score #t cine matches 77 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 9.353 -165.000 -6.340 4.735
execute if score #t cine matches 78 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 9.195 -165.000 -6.340 4.735
execute if score #t cine matches 79 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 9.036 -165.000 -6.340 4.735
execute if score #t cine matches 80 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 8.877 -165.000 -6.340 4.735
execute if score #t cine matches 81 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 8.718 -165.000 -6.340 4.735
execute if score #t cine matches 82 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 8.559 -165.000 -6.340 4.735
execute if score #t cine matches 83 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 8.399 -165.000 -6.340 4.735
execute if score #t cine matches 84 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 8.240 -165.000 -6.340 4.735
execute if score #t cine matches 85 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 8.080 -165.000 -6.340 4.735
execute if score #t cine matches 86 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 7.920 -165.000 -6.340 4.735
execute if score #t cine matches 87 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 7.760 -165.000 -6.340 4.735
execute if score #t cine matches 88 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 7.601 -165.000 -6.340 4.735
execute if score #t cine matches 89 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 7.441 -165.000 -6.340 4.735
execute if score #t cine matches 90 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 7.282 -165.000 -6.340 4.735
execute if score #t cine matches 91 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 7.123 -165.000 -6.340 4.735
execute if score #t cine matches 92 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 6.964 -165.000 -6.340 4.735
execute if score #t cine matches 93 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 6.805 -165.000 -6.340 4.735
execute if score #t cine matches 94 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 6.647 -165.000 -6.340 4.735
execute if score #t cine matches 95 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 6.489 -165.000 -6.340 4.735
execute if score #t cine matches 96 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 6.331 -165.000 -6.340 4.735
execute if score #t cine matches 97 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 6.174 -165.000 -6.340 4.735
execute if score #t cine matches 98 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 6.018 -165.000 -6.340 4.735
execute if score #t cine matches 99 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 5.862 -165.000 -6.340 4.735
execute if score #t cine matches 100 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 5.706 -165.000 -6.340 4.735
execute if score #t cine matches 101 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 5.551 -165.000 -6.340 4.735
execute if score #t cine matches 102 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 5.397 -165.000 -6.340 4.735
execute if score #t cine matches 103 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 5.244 -165.000 -6.340 4.735
execute if score #t cine matches 104 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 5.092 -165.000 -6.340 4.735
execute if score #t cine matches 105 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 4.940 -165.000 -6.340 4.735
execute if score #t cine matches 106 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 4.789 -165.000 -6.340 4.735
execute if score #t cine matches 107 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 4.639 -165.000 -6.340 4.735
execute if score #t cine matches 108 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 4.490 -165.000 -6.340 4.735
execute if score #t cine matches 109 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 4.342 -165.000 -6.340 4.735
execute if score #t cine matches 110 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 4.195 -165.000 -6.340 4.735
execute if score #t cine matches 111 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 4.050 -165.000 -6.340 4.735
execute if score #t cine matches 112 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 3.905 -165.000 -6.340 4.735
execute if score #t cine matches 113 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 3.762 -165.000 -6.340 4.735
execute if score #t cine matches 114 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 3.619 -165.000 -6.340 4.735
execute if score #t cine matches 115 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 3.478 -165.000 -6.340 4.735
execute if score #t cine matches 116 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 3.339 -165.000 -6.340 4.735
execute if score #t cine matches 117 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 3.201 -165.000 -6.340 4.735
execute if score #t cine matches 118 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 3.064 -165.000 -6.340 4.735
execute if score #t cine matches 119 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 2.928 -165.000 -6.340 4.735
execute if score #t cine matches 120 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 2.794 -165.000 -6.340 4.735
execute if score #t cine matches 121 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 2.662 -165.000 -6.340 4.735
execute if score #t cine matches 122 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 2.531 -165.000 -6.340 4.735
execute if score #t cine matches 123 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 2.402 -165.000 -6.340 4.735
execute if score #t cine matches 124 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 2.275 -165.000 -6.340 4.735
execute if score #t cine matches 125 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 2.149 -165.000 -6.340 4.735
execute if score #t cine matches 126 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 2.025 -165.000 -6.340 4.735
execute if score #t cine matches 127 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 1.903 -165.000 -6.340 4.735
execute if score #t cine matches 128 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 1.783 -165.000 -6.340 4.735
execute if score #t cine matches 129 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 1.664 -165.000 -6.340 4.735
execute if score #t cine matches 130 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 1.548 -165.000 -6.340 4.735
execute if score #t cine matches 131 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 1.433 -165.000 -6.340 4.735
execute if score #t cine matches 132 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 1.321 -165.000 -6.340 4.735
execute if score #t cine matches 133 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 1.211 -165.000 -6.340 4.735
execute if score #t cine matches 134 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 1.102 -165.000 -6.340 4.735
execute if score #t cine matches 135 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 0.996 -165.000 -6.340 4.735
execute if score #t cine matches 136 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 0.892 -165.000 -6.340 4.735
execute if score #t cine matches 137 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 0.791 -165.000 -6.340 4.735
execute if score #t cine matches 138 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 0.692 -165.000 -6.340 4.735
execute if score #t cine matches 139 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 0.595 -165.000 -6.340 4.735
execute if score #t cine matches 140 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 0.500 -165.000 -6.340 4.735
execute if score #t cine matches 141 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 0.408 -165.000 -6.340 4.735
execute if score #t cine matches 142 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 0.319 -165.000 -6.340 4.735
execute if score #t cine matches 143 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 0.232 -165.000 -6.340 4.735
execute if score #t cine matches 144 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 0.147 -165.000 -6.340 4.735
execute if score #t cine matches 145 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 0.065 -165.000 -6.340 4.735
execute if score #t cine matches 146 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.014 -165.000 -6.340 4.735
execute if score #t cine matches 147 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.091 -165.000 -6.340 4.735
execute if score #t cine matches 148 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.164 -165.000 -6.340 4.735
execute if score #t cine matches 149 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.235 -165.000 -6.340 4.735
execute if score #t cine matches 150 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.303 -165.000 -6.340 4.735
execute if score #t cine matches 151 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.369 -165.000 -6.340 4.735
execute if score #t cine matches 152 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.431 -165.000 -6.340 4.735
execute if score #t cine matches 153 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.490 -165.000 -6.340 4.735
execute if score #t cine matches 154 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.547 -165.000 -6.340 4.735
execute if score #t cine matches 155 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.600 -165.000 -6.340 4.735
execute if score #t cine matches 156 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.650 -165.000 -6.340 4.735
execute if score #t cine matches 157 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.697 -165.000 -6.340 4.735
execute if score #t cine matches 158 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.741 -165.000 -6.340 4.735
execute if score #t cine matches 159 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.781 -165.000 -6.340 4.735
execute if score #t cine matches 160 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.818 -165.000 -6.340 4.735
execute if score #t cine matches 161 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.852 -165.000 -6.340 4.735
execute if score #t cine matches 162 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.883 -165.000 -6.340 4.735
execute if score #t cine matches 163 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.910 -165.000 -6.340 4.735
execute if score #t cine matches 164 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.934 -165.000 -6.340 4.735
execute if score #t cine matches 165 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.954 -165.000 -6.340 4.735
execute if score #t cine matches 166 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.970 -165.000 -6.340 4.735
execute if score #t cine matches 167 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.983 -165.000 -6.340 4.735
execute if score #t cine matches 168 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.992 -165.000 -6.340 4.735
execute if score #t cine matches 169 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -0.998 -165.000 -6.340 4.735
execute if score #t cine matches 170 run tp @e[type=minecraft:armor_stand,tag=cine_cam] -4.000 -1.000 -165.000 -6.340 4.735
execute if score #t cine matches 2 run title @a[tag=cine] actionbar {"text":"La pompe tourne : la Cuve baisse…","color":"gray"}
execute if score #t cine matches 2 run execute as @a[tag=cine] at @s run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 10 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 26 run function atelier:station_vide_76
execute if score #t cine matches 35 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 37 run function atelier:station_vide_75
execute if score #t cine matches 45 run function atelier:station_vide_74
execute if score #t cine matches 53 run function atelier:station_vide_73
execute if score #t cine matches 60 run function atelier:station_vide_72
execute if score #t cine matches 60 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 67 run function atelier:station_vide_71
execute if score #t cine matches 73 run function atelier:station_vide_70
execute if score #t cine matches 80 run function atelier:station_vide_69
execute if score #t cine matches 85 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 86 run function atelier:station_vide_68
execute if score #t cine matches 92 run function atelier:station_vide_67
execute if score #t cine matches 99 run function atelier:station_vide_66
execute if score #t cine matches 105 run function atelier:station_vide_65
execute if score #t cine matches 110 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 112 run function atelier:station_vide_64
execute if score #t cine matches 119 run function atelier:station_vide_63
execute if score #t cine matches 127 run function atelier:station_vide_62
execute if score #t cine matches 135 run function atelier:station_vide_61
execute if score #t cine matches 135 run execute as @a[tag=cine] at @s run playsound minecraft:block.water.ambient master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 146 run function atelier:station_vide_60
execute if score #t cine matches 166 run scoreboard players set #niv station 58
execute if score #t cine matches 166 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 0.8
execute if score #t cine matches 166 run title @a[tag=cine] actionbar {"text":"Niveau MEDIAN","color":"aqua"}
execute if score #t cine matches 170 run function atelier:station_vide_59
