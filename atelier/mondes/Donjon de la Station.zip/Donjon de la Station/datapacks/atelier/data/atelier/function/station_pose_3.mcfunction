# [claude-build] Decharge le gabarit et annonce.
forceload remove -120 -238 119 1
tellraw @a [{"text":"La Station est prête. Entrée : ","color":"green"},{"text":"[/tp @s -1 47 0 0 0]","color":"aqua","underlined":true,"clickEvent":{"action":"run_command","value":"/tp @s -1 47 0 0 0"},"hoverEvent":{"action":"show_text","contents":"Cliquer pour y aller"}}]
