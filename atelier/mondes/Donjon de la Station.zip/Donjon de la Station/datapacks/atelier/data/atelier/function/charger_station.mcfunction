# [claude-build] Pose automatique, une seule fois (drapeau #station).
scoreboard objectives add atelier dummy
execute unless score #station atelier matches 1 run schedule function atelier:station_pose 100t
scoreboard players set #station atelier 1
