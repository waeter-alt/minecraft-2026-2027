# [claude-build] Chaque tick : les cinematiques, les volants, l'embuscade, la mise en eau, le bruit du Drain.
execute if score #t cine matches 1.. run function atelier:station_cine_cadre
execute unless score #t cine matches 1.. as @a[tag=cine] run function atelier:station_cine_retour_joueur
execute if score #v1 station matches 0 store result score #hv1 station run data get block -43 23 -58 InUse
execute if score #v1 station matches 0 if score #hv1 station matches 1.. run scoreboard players add #cv1 station 1
execute if score #v1 station matches 0 if score #hv1 station matches 1.. positioned -43 23 -58 run particle minecraft:crit ~0.5 ~0.8 ~0.5 0.3 0.2 0.3 0.05 2
execute if score #v1 station matches 0 if score #cv1 station matches 30.. run function atelier:station_volant_1
execute if score #v3 station matches 0 store result score #hv3 station run data get block 30 33 -60 InUse
execute if score #v3 station matches 0 if score #hv3 station matches 1.. run scoreboard players add #cv3 station 1
execute if score #v3 station matches 0 if score #hv3 station matches 1.. positioned 30 33 -60 run particle minecraft:crit ~0.5 ~0.8 ~0.5 0.3 0.2 0.3 0.05 2
execute if score #v3 station matches 0 if score #cv3 station matches 30.. run function atelier:station_volant_3
execute if score #v2 station matches 0 store result score #hv2 station run data get block 21 23 -50 InUse
execute if score #v2 station matches 0 if score #hv2 station matches 1.. if score #emb station matches 2 run scoreboard players add #cv2 station 1
execute if score #v2 station matches 0 if score #hv2 station matches 1.. if score #emb station matches 2 positioned 21 23 -50 run particle minecraft:crit ~0.5 ~0.8 ~0.5 0.3 0.2 0.3 0.05 2
execute if score #v2 station matches 0 if score #cv2 station matches 30.. run function atelier:station_volant_2
execute if score #v2 station matches 0 if score #hv2 station matches 1.. unless score #emb station matches 2 run function atelier:station_volant_2_refus
scoreboard players add #obj station 1
execute if score #obj station matches 40.. run function atelier:station_objectif
execute if score #emb station matches 0 positioned -30 20 -68 if entity @a[gamemode=!spectator,dx=49,dy=2,dz=15] run function atelier:station_embuscade
execute if score #emb station matches 1 unless entity @e[tag=station_emb] run function atelier:station_embuscade_fin
execute if score #eau station matches 0 positioned -35 -31 -178 if entity @a[gamemode=!spectator,dx=70,dy=64,dz=70] run function atelier:station_mise_en_eau
scoreboard players add #tic station 1
execute if score #tic station matches 50.. positioned 53 22 -76 run playsound minecraft:block.water.ambient ambient @a[distance=..48] ~ ~ ~ 1.6 0.6
execute if score #tic station matches 50.. run scoreboard players set #tic station 0
execute positioned 52 -27 -79 as @a[dx=3,dy=46,dz=3,gamemode=!spectator] at @s if block ~ ~-0.6 ~ minecraft:water if block ~0 ~0.8 ~0 minecraft:water run tp @s ~0 ~0.8 ~0
execute positioned 52 -31 -130 as @a[dx=3,dy=3,dz=54,gamemode=!spectator] at @s if block ~ ~-0.6 ~ minecraft:water if block ~0 ~0 ~0.8 minecraft:water run tp @s ~0 ~0 ~0.8
execute positioned 20 -31 -130 as @a[dx=31,dy=3,dz=3,gamemode=!spectator] at @s if block ~ ~-0.6 ~ minecraft:water if block ~0.8 ~0 ~0 minecraft:water run tp @s ~0.8 ~0 ~0
execute if score #niv station matches 1.. if score #pA station matches 0 positioned -105 0 -215 run particle minecraft:end_rod ~0.5 ~1.5 ~0.5 0.15 2 0.15 0.01 3 force @a[distance=..96]
execute if score #niv station matches 1.. if score #pB station matches 0 positioned 106 2 -142 run particle minecraft:end_rod ~0.5 ~1.5 ~0.5 0.15 2 0.15 0.01 3 force @a[distance=..96]
execute if score #niv station matches 1.. if score #pC station matches 0 positioned 0 24 -232 run particle minecraft:end_rod ~0.5 ~1.5 ~0.5 0.15 2 0.15 0.01 3 force @a[distance=..96]
execute if score #a3 station matches 0 positioned -98 -1 -235 if entity @a[dx=54,dy=13,dz=39,gamemode=!spectator] run function atelier:station_a3_monstres
execute if score #a4 station matches 0 positioned -118 -1 -226 if entity @a[dx=18,dy=11,dz=22,gamemode=!spectator] run function atelier:station_a4_monstres
execute if score #pA station matches 0 store result score #hpA station run data get block -105 0 -215 InUse
execute if score #pA station matches 0 if score #hpA station matches 1.. run scoreboard players add #cpA station 1
execute if score #pA station matches 0 if score #hpA station matches 1.. positioned -105 0 -215 run particle minecraft:crit ~0.5 ~0.8 ~0.5 0.3 0.2 0.3 0.05 2
execute if score #pA station matches 0 if score #cpA station matches 30.. run function atelier:station_pompe_a
execute positioned 41 -31 -145 as @a[dx=27,dy=13,dz=4,gamemode=!spectator] at @s if block ~ ~-0.6 ~ minecraft:water if block ~-0.5 ~0 ~0 minecraft:water run tp @s ~-0.5 ~0 ~0
execute if score #b2 station matches 0 positioned 69 -22 -168 if entity @a[dx=39,dy=10,dz=51,gamemode=!spectator] run function atelier:station_b2_monstres
execute if score #b3 station matches 0 positioned 69 -4 -168 if entity @a[dx=39,dy=14,dz=51,gamemode=!spectator] run function atelier:station_b3_monstres
execute if score #pl1 station matches 0 positioned 79 -22 -144 as @a[dx=2,dy=0,dz=2,gamemode=!spectator] at @s unless block ~ ~-0.6 ~ minecraft:water run function atelier:station_b_plaque_1
execute if score #pl2 station matches 0 positioned 91 -22 -159 as @a[dx=2,dy=0,dz=2,gamemode=!spectator] at @s unless block ~ ~-0.6 ~ minecraft:water run function atelier:station_b_plaque_2
execute if score #pl3 station matches 0 positioned 101 -22 -129 as @a[dx=2,dy=0,dz=2,gamemode=!spectator] at @s unless block ~ ~-0.6 ~ minecraft:water run function atelier:station_b_plaque_3
execute if score #pl1 station matches 0 positioned 92 -20 -156 if entity @a[distance=..20] run particle minecraft:bubble_column_up ~ ~ ~ 1 2 0.2 0.3 6
execute if score #pl2 station matches 0 positioned 102 -20 -130 if entity @a[distance=..20] run particle minecraft:bubble_column_up ~ ~ ~ 1 2 0.2 0.3 6
execute if score #b3 station matches 1 run scoreboard players add #vap station 1
execute if score #vap station matches 80.. run scoreboard players set #vap station 0
execute if score #b3 station matches 1 if score #vap station matches 0..19 positioned 86 2 -142 run particle minecraft:cloud ~ ~0.5 ~ 1.8 1 1 0.02 12
execute if score #vap station matches 0 positioned 86 2 -142 run playsound minecraft:block.fire.extinguish master @a[distance=..30] ~ ~ ~ 1.5 0.6
execute if score #vap station matches 5 positioned 85 2 -143 as @a[dx=3,dy=1,dz=2,gamemode=!spectator] run damage @s 2 minecraft:hot_floor
execute if score #vap station matches 15 positioned 85 2 -143 as @a[dx=3,dy=1,dz=2,gamemode=!spectator] run damage @s 2 minecraft:hot_floor
execute if score #b3 station matches 1 if score #vap station matches 0..19 positioned 96 2 -142 run particle minecraft:cloud ~ ~0.5 ~ 1.3 1 1 0.02 12
execute if score #vap station matches 0 positioned 96 2 -142 run playsound minecraft:block.fire.extinguish master @a[distance=..30] ~ ~ ~ 1.5 0.6
execute if score #vap station matches 5 positioned 95 2 -143 as @a[dx=2,dy=1,dz=2,gamemode=!spectator] run damage @s 2 minecraft:hot_floor
execute if score #vap station matches 15 positioned 95 2 -143 as @a[dx=2,dy=1,dz=2,gamemode=!spectator] run damage @s 2 minecraft:hot_floor
execute if score #pB station matches 0 store result score #hpB station run data get block 106 2 -142 InUse
execute if score #pB station matches 0 if score #hpB station matches 1.. run scoreboard players add #cpB station 1
execute if score #pB station matches 0 if score #hpB station matches 1.. positioned 106 2 -142 run particle minecraft:crit ~0.5 ~0.8 ~0.5 0.3 0.2 0.3 0.05 2
execute if score #pB station matches 0 if score #cpB station matches 30.. run function atelier:station_pompe_b
execute if score #t1 station matches ..39 positioned 0 -10 -204 if entity @a[distance=..4.5,predicate=atelier:nage] run scoreboard players add #t1 station 1
execute if score #t1 station matches 1..39 positioned 0 -10 -204 unless entity @a[distance=..4.5,predicate=atelier:nage] run scoreboard players remove #t1 station 1
execute if score #t1 station matches 1..39 positioned 0 -10 -204 run particle minecraft:bubble ~ ~ ~ 2 0.3 2 0.1 4
execute if score #t1 station matches 40 run function atelier:station_c_turbine_1
execute if score #t1 station matches 1000 positioned 0 -10 -204 run particle minecraft:bubble_column_up ~ ~ ~ 3 0.4 3 0.2 6
execute if score #t2 station matches ..39 positioned 0 6 -204 if entity @a[distance=..4.5,predicate=atelier:nage] run scoreboard players add #t2 station 1
execute if score #t2 station matches 1..39 positioned 0 6 -204 unless entity @a[distance=..4.5,predicate=atelier:nage] run scoreboard players remove #t2 station 1
execute if score #t2 station matches 1..39 positioned 0 6 -204 run particle minecraft:bubble ~ ~ ~ 2 0.3 2 0.1 4
execute if score #t2 station matches 40 run function atelier:station_c_turbine_2
execute if score #t2 station matches 1000 positioned 0 6 -204 run particle minecraft:bubble_column_up ~ ~ ~ 3 0.4 3 0.2 6
execute if score #t3 station matches ..39 positioned 0 18 -204 if entity @a[distance=..4.5,predicate=atelier:nage] run scoreboard players add #t3 station 1
execute if score #t3 station matches 1..39 positioned 0 18 -204 unless entity @a[distance=..4.5,predicate=atelier:nage] run scoreboard players remove #t3 station 1
execute if score #t3 station matches 1..39 positioned 0 18 -204 run particle minecraft:bubble ~ ~ ~ 2 0.3 2 0.1 4
execute if score #t3 station matches 40 run function atelier:station_c_turbine_3
execute if score #t3 station matches 1000 positioned 0 18 -204 run particle minecraft:bubble_column_up ~ ~ ~ 3 0.4 3 0.2 6
execute if score #tar1 station matches 0 if score #t1 station matches 1000 positioned -10 -1 -204 if entity @a[distance=..4,predicate=atelier:nage] run function atelier:station_c_tartre_1
execute if score #tar2 station matches 0 if score #t2 station matches 1000 unless entity @e[tag=station_rotor] positioned -10 13 -204 if entity @a[distance=..4,predicate=atelier:nage] run function atelier:station_c_tartre_2
execute if score #rotor station matches 0 positioned -18 1 -222 if entity @a[dx=36,dy=12,dz=36,gamemode=!spectator] run function atelier:station_rotor_monstres
execute as @e[type=minecraft:elder_guardian,tag=station_rotor] at @s run function atelier:station_rotor_remplacer
execute if score #pC station matches 0 store result score #hpC station run data get block 0 24 -232 InUse
execute if score #pC station matches 0 if score #hpC station matches 1.. run scoreboard players add #cpC station 1
execute if score #pC station matches 0 if score #hpC station matches 1.. positioned 0 24 -232 run particle minecraft:crit ~0.5 ~0.8 ~0.5 0.3 0.2 0.3 0.05 2
execute if score #pC station matches 0 if score #cpC station matches 30.. run function atelier:station_pompe_c
execute if score #d station matches 1 if score #dvu station matches 0 positioned 20 -28 -167 run particle minecraft:end_rod ~0.5 ~1 ~0.5 0.3 5 0.3 0.02 6 force @a[distance=..120]
execute if score #d station matches 1 if score #dvu station matches 0 positioned 20 -28 -167 if entity @a[distance=..5,gamemode=!spectator] run scoreboard players set #dvu station 1
execute positioned 32 -31 -199 as @a[dx=16,dy=27,dz=16,gamemode=!spectator] at @s if block ~ ~-0.6 ~ minecraft:water if block ~0 ~-0.3 ~0 minecraft:water run tp @s ~0 ~-0.3 ~0
execute if score #tard station matches 0 positioned 40 -1 -191 if entity @a[distance=..4,predicate=atelier:nage] run function atelier:station_d_tartre
execute if score #tard station matches 1 if score #td station matches ..39 positioned 40 4 -191 if entity @a[distance=..4,predicate=atelier:nage] run scoreboard players add #td station 1
execute if score #td station matches 1..39 positioned 40 4 -191 unless entity @a[distance=..4,predicate=atelier:nage] run scoreboard players remove #td station 1
execute if score #td station matches 40 run function atelier:station_d_turbine
execute if score #td station matches 1000 positioned 40 4 -191 run particle minecraft:bubble_column_up ~ ~ ~ 2 0.4 2 0.2 6
execute if score #lg station matches 0 if block 27 23 -192 minecraft:lever[powered=true] run function atelier:station_levier_general
execute if score #lg station matches 1 positioned 0 -20 -143 run particle minecraft:bubble_column_up ~ ~-4 ~ 4 4 4 0.3 20
execute if score #boss station matches 0 positioned -44 -61 -187 if entity @a[dx=88,dy=23,dz=88,gamemode=!spectator] run function atelier:station_boss_debut
execute if score #boss station matches 1 unless entity @e[tag=station_boss] run function atelier:station_boss_vaincu
execute if score #boss station matches 2 positioned -20 47 -94 if entity @a[distance=..8] run function atelier:station_victoire
