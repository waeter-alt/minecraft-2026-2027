# [claude-build] Chaque tick : les cinematiques, les valves et leurs traits de lumiere, l'embuscade, le Vestiaire, le levier du Sas, la mise en eau, le bruit du Drain.
execute if score #t cine matches 1.. run function atelier:station_cine_cadre
execute unless score #t cine matches 1.. as @a[tag=cine] run function atelier:station_cine_retour_joueur
execute if score #v1 station matches 0 if block -43 23 -58 donjon:valve_station[tournee=true] run function atelier:station_volant_1
execute if score #v2 station matches 0 if block 21 23 -50 donjon:valve_station[tournee=true] run function atelier:station_volant_2
execute if score #v3 station matches 0 if block 30 33 -60 donjon:valve_station[tournee=true] run function atelier:station_volant_3
execute as @e[type=minecraft:marker,tag=station_trait_1] at @s facing -60.5 29.5 -54.5 run function atelier:station_trait_1
execute as @e[type=minecraft:marker,tag=station_trait_2] at @s facing -60.5 29.5 -53.5 run function atelier:station_trait_2
execute as @e[type=minecraft:marker,tag=station_trait_3] at @s facing -60.5 29.5 -52.5 run function atelier:station_trait_3
scoreboard players add #obj station 1
execute if score #obj station matches 40.. run function atelier:station_objectif
execute if score #emb station matches 0 positioned -30 20 -68 if entity @a[gamemode=!spectator,dx=49,dy=2,dz=15] run function atelier:station_embuscade
execute if score #emb station matches 1 unless entity @e[tag=station_emb] run function atelier:station_embuscade_fin
execute if score #vest station matches 0 if score #temoins station matches 3 positioned -106 23 -75 if entity @a[gamemode=!spectator,dx=41,dy=2,dz=43] run function atelier:station_vestiaire_entree
execute if score #vest station matches 1 if score #cape station matches 0 unless data block -92 23 -44 Items[{id:"donjon:cape_lestee"}] run function atelier:station_cape_prise
execute if score #cape station matches 1 if score #sasp station matches 0 if block -65 24 -51 donjon:levier_station[powered=true] run function atelier:station_levier_sas
execute if score #eau station matches 0 positioned -35 -31 -178 if entity @a[gamemode=!spectator,dx=70,dy=64,dz=70] run function atelier:station_mise_en_eau
execute if score #niv station matches 1.. if score #pA station matches 0 positioned -105 0 -215 run particle minecraft:end_rod ~0.5 ~1.5 ~0.5 0.15 2 0.15 0.01 3 force @a[distance=..96]
execute if score #niv station matches 1.. if score #pB station matches 0 positioned 106 2 -142 run particle minecraft:end_rod ~0.5 ~1.5 ~0.5 0.15 2 0.15 0.01 3 force @a[distance=..96]
execute if score #niv station matches 1.. if score #pC station matches 0 positioned 0 24 -232 run particle minecraft:end_rod ~0.5 ~1.5 ~0.5 0.15 2 0.15 0.01 3 force @a[distance=..96]
execute if score #a3 station matches 0 positioned -98 -1 -235 if entity @a[dx=54,dy=13,dz=39,gamemode=!spectator] run function atelier:station_a3_monstres
execute if score #a4 station matches 0 positioned -118 -1 -226 if entity @a[dx=18,dy=11,dz=22,gamemode=!spectator] run function atelier:station_a4_monstres
execute if score #pA station matches 0 if block -105 0 -215 donjon:valve_station[tournee=true] run function atelier:station_pompe_a
execute if score #b2 station matches 0 positioned 69 -22 -168 if entity @a[dx=39,dy=10,dz=51,gamemode=!spectator] run function atelier:station_b2_monstres
execute if score #b3 station matches 0 positioned 69 -4 -168 if entity @a[dx=39,dy=14,dz=51,gamemode=!spectator] run function atelier:station_b3_monstres
execute if score #pl1 station matches 0 positioned 79 -22 -144 as @a[dx=2,dy=0,dz=2,gamemode=!spectator] at @s unless block ~ ~-0.6 ~ minecraft:water run function atelier:station_b_plaque_1
execute if score #pl2 station matches 0 positioned 91 -22 -159 as @a[dx=2,dy=0,dz=2,gamemode=!spectator] at @s unless block ~ ~-0.6 ~ minecraft:water run function atelier:station_b_plaque_2
execute if score #pl3 station matches 0 positioned 101 -22 -129 as @a[dx=2,dy=0,dz=2,gamemode=!spectator] at @s unless block ~ ~-0.6 ~ minecraft:water run function atelier:station_b_plaque_3
execute if score #pl1 station matches 0 positioned 92 -20 -156 if entity @a[distance=..20] run particle minecraft:bubble_column_up ~ ~ ~ 1 2 0.2 0.3 6
execute if score #pl2 station matches 0 positioned 102 -20 -130 if entity @a[distance=..20] run particle minecraft:bubble_column_up ~ ~ ~ 1 2 0.2 0.3 6
execute if score #b3 station matches 1 run scoreboard players add #vap station 1
execute if score #vap station matches 80.. run scoreboard players set #vap station 0
execute if score #b3 station matches 1 if score #vap station matches 0..19 positioned 86 2 -142 run particle minecraft:cloud ~ ~0.5 ~ 1.8 1 1 0.02 12
execute if score #vap station matches 0 positioned 86 2 -142 run playsound minecraft:block.fire.extinguish master @a[distance=..30] ~ ~ ~ 1.5 0.6
execute if score #vap station matches 5 positioned 85 2 -143 as @a[dx=3,dy=1,dz=2,gamemode=!spectator] run damage @s 2 minecraft:hot_floor
execute if score #vap station matches 15 positioned 85 2 -143 as @a[dx=3,dy=1,dz=2,gamemode=!spectator] run damage @s 2 minecraft:hot_floor
execute if score #b3 station matches 1 if score #vap station matches 0..19 positioned 96 2 -142 run particle minecraft:cloud ~ ~0.5 ~ 1.3 1 1 0.02 12
execute if score #vap station matches 0 positioned 96 2 -142 run playsound minecraft:block.fire.extinguish master @a[distance=..30] ~ ~ ~ 1.5 0.6
execute if score #vap station matches 5 positioned 95 2 -143 as @a[dx=2,dy=1,dz=2,gamemode=!spectator] run damage @s 2 minecraft:hot_floor
execute if score #vap station matches 15 positioned 95 2 -143 as @a[dx=2,dy=1,dz=2,gamemode=!spectator] run damage @s 2 minecraft:hot_floor
execute if score #pB station matches 0 if block 106 2 -142 donjon:valve_station[tournee=true] run function atelier:station_pompe_b
execute if score #w1 station matches 0 positioned -18 -13 -222 if entity @a[dx=36,dy=12,dz=36,gamemode=!spectator] run function atelier:station_c1_monstres
execute if score #w3 station matches 0 positioned -18 15 -222 if entity @a[dx=36,dy=8,dz=36,gamemode=!spectator] run function atelier:station_c3_monstres
execute if score #g1 station matches 0 if score #c1a station matches 0 if block -15 -14 -204 donjon:valve_station[tournee=true] run function atelier:station_c_v1a
execute if score #g1 station matches 0 if score #c1a station matches 1 positioned -15 -14 -204 run particle minecraft:end_rod ~0.5 ~1.3 ~0.5 0.1 0.3 0.1 0.01 1
execute if score #g1 station matches 0 if score #c1b station matches 0 if block 15 -14 -204 donjon:valve_station[tournee=true] run function atelier:station_c_v1b
execute if score #g1 station matches 0 if score #c1b station matches 1 positioned 15 -14 -204 run particle minecraft:end_rod ~0.5 ~1.3 ~0.5 0.1 0.3 0.1 0.01 1
execute if score #g1 station matches 0 if score #c1t station matches 1.. run scoreboard players remove #c1t station 1
execute if score #g1 station matches 0 if score #c1t station matches 0 if score #c1a station matches 1 run function atelier:station_c_v1_retombe
execute if score #g1 station matches 0 if score #c1t station matches 0 if score #c1b station matches 1 run function atelier:station_c_v1_retombe
execute if score #rotor station matches 1 if score #g2 station matches 0 positioned 0 7 -204 if entity @a[distance=..40] unless entity @e[tag=station_rotor] run function atelier:station_c_boss_mort
execute if score #rotor station matches 0 positioned -18 1 -222 if entity @a[dx=36,dy=12,dz=36,gamemode=!spectator] run function atelier:station_rotor_monstres
execute if score #rotor station matches 1 if score #rvn station matches 0 positioned 0 7 -204 if entity @a[distance=..40] unless entity @e[tag=station_rotor_cristal] run function atelier:station_rotor_vulnerable
execute if score #rotor station matches 1 if score #rvn station matches 0 as @e[tag=station_rotor] at @s run particle minecraft:enchanted_hit ~ ~1 ~ 0.5 0.9 0.5 0.1 3
execute as @e[type=minecraft:elder_guardian,tag=station_rotor] at @s run function atelier:station_rotor_remplacer
execute if score #pC station matches 0 if block 0 24 -232 donjon:valve_station[tournee=true] run function atelier:station_pompe_c
execute if score #d station matches 1 if score #dvu station matches 0 positioned 20 -28 -167 run particle minecraft:end_rod ~0.5 ~1 ~0.5 0.3 5 0.3 0.02 6 force @a[distance=..120]
execute if score #d station matches 1 if score #dvu station matches 0 positioned 20 -28 -167 if entity @a[distance=..5,gamemode=!spectator] run scoreboard players set #dvu station 1
execute if score #lg station matches 0 if block 27 23 -192 donjon:levier_station[powered=true] run function atelier:station_levier_general
execute if score #lg station matches 1 positioned 0 -20 -143 run particle minecraft:bubble_column_up ~ ~-4 ~ 4 4 4 0.3 20
execute if score #boss station matches 0 positioned -44 -61 -187 if entity @a[dx=88,dy=23,dz=88,gamemode=!spectator] run function atelier:station_boss_debut
execute if score #boss station matches 1 unless entity @e[tag=station_boss] run function atelier:station_boss_vaincu
execute if score #boss station matches 2 positioned 0 -35 -89 if entity @a[distance=..10] run function atelier:station_victoire
execute if score #boss station matches 2.. positioned 0 -35 -86 run particle minecraft:end_rod ~0.5 ~0.5 ~0.5 0.8 1 0.8 0.01 3
execute if score #boss station matches 2.. positioned -1 -35 -87 as @a[dx=2,dy=1,dz=2,gamemode=!spectator] run function atelier:station_sortie
