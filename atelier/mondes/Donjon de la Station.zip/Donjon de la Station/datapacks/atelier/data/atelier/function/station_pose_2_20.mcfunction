# [claude-build] Pose de la station, etape 21 sur 21.
place template atelier:station_retouches -119 -18 -208
kill @e[type=item]
function atelier:station_reset
schedule function atelier:station_pose_3 100t
