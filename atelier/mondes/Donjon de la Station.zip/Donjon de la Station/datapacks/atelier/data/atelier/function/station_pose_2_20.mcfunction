# [claude-build] Pose de la station, etape 21 sur 21.
place template atelier:station_retouches 87 -17 -160
kill @e[type=item]
function atelier:station_reset
schedule function atelier:station_pose_3 100t
