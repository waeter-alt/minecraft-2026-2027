# [claude-build] Le Scaphandrier est vaincu : la trappe 2 s'ouvre, et la grille de la salle de la pompe se leve.
function atelier:station_c_trappe_2
setblock -3 24 -224 minecraft:air
setblock -3 25 -224 minecraft:air
setblock -3 26 -224 minecraft:air
setblock -3 27 -224 minecraft:air
setblock -2 24 -224 minecraft:air
setblock -2 25 -224 minecraft:air
setblock -2 26 -224 minecraft:air
setblock -2 27 -224 minecraft:air
setblock -1 24 -224 minecraft:air
setblock -1 25 -224 minecraft:air
setblock -1 26 -224 minecraft:air
setblock -1 27 -224 minecraft:air
setblock 0 24 -224 minecraft:air
setblock 0 25 -224 minecraft:air
setblock 0 26 -224 minecraft:air
setblock 0 27 -224 minecraft:air
setblock 1 24 -224 minecraft:air
setblock 1 25 -224 minecraft:air
setblock 1 26 -224 minecraft:air
setblock 1 27 -224 minecraft:air
setblock 2 24 -224 minecraft:air
setblock 2 25 -224 minecraft:air
setblock 2 26 -224 minecraft:air
setblock 2 27 -224 minecraft:air
setblock 3 24 -224 minecraft:air
setblock 3 25 -224 minecraft:air
setblock 3 26 -224 minecraft:air
setblock 3 27 -224 minecraft:air
execute positioned -3 24 -224 run playsound minecraft:block.iron_door.open master @a[distance=..60] ~ ~ ~ 2 0.7
