# [claude-build] La turbine T2 est lancee : elle tourne et pousse l'eau vers le haut ; une vague de monstres arrive.
scoreboard players set #t2 station 1000
execute positioned 0 6 -204 run playsound minecraft:block.beacon.activate master @a[distance=..60] ~ ~ ~ 2 0.6
tellraw @a {"text":"La turbine T2 tourne.","color":"aqua"}
summon minecraft:drowned -8 6 -198 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:drowned 8 6 -210 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:drowned 6 8 -194 {Tags:["station_emb"],PersistenceRequired:1b}
summon minecraft:guardian -6 8 -212 {Tags:["station_emb"],PersistenceRequired:1b}
setblock 0 1 -204 create:creative_motor[facing=up]
