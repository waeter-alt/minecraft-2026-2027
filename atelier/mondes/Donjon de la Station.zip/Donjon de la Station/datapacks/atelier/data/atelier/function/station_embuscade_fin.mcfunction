# [claude-build] Les monstres du bassin sont tous vaincus : un coffre apparait au fond de la piscine, qui est vide (a remplir par Luca).
scoreboard players set #emb station 2
setblock -5 20 -60 minecraft:chest[facing=north,type=single,waterlogged=false]
execute positioned -5 20 -60 run particle minecraft:end_rod ~0.5 ~0.6 ~0.5 0.3 0.8 0.3 0.05 40 force
execute positioned -5 20 -60 run playsound minecraft:block.beacon.activate master @a[distance=..70] ~ ~ ~ 2 1.3
