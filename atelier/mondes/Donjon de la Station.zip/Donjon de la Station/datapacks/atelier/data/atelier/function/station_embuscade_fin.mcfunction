# [claude-build] L'embuscade est vaincue : le volant du bassin repond.
scoreboard players set #emb station 2
execute positioned 21 23 -50 run title @a[distance=..70] actionbar {"text":"Le bassin est libre : le volant répond","color":"aqua"}
