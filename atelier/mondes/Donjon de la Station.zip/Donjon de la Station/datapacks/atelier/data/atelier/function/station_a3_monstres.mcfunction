# [claude-build] Un joueur entre : les monstres de « a3 » apparaissent (une seule fois).
scoreboard players set #a3 station 1
summon minecraft:guardian -80 4 -228 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned -80 4 -228 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:guardian -68 4 -202 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned -68 4 -202 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:guardian -54 4 -226 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned -54 4 -226 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:guardian -84 8 -200 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned -84 8 -200 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:drowned -94 1 -218 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned -94 1 -218 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
summon minecraft:drowned -50 1 -208 {Tags:["station_emb"],PersistenceRequired:1b}
execute positioned -50 1 -208 run particle minecraft:bubble_pop ~ ~0.5 ~ 0.5 0.5 0.5 0.05 20
