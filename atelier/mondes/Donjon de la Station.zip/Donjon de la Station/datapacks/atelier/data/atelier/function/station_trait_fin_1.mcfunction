# [claude-build] Le trait de la valve 1 touche son voyant : il s'allume ; le troisieme ouvre la porte du Vestiaire.
tag @s add arrive
scoreboard players add #temoins station 1
setblock -61 29 -55 minecraft:waxed_copper_bulb[lit=true,powered=false]
execute positioned -60.5 29.5 -54.5 run playsound minecraft:block.copper_bulb.turn_on master @a[distance=..80] ~ ~ ~ 2 0.8
execute positioned -60.5 29.5 -54.5 run playsound minecraft:block.note_block.chime master @a[distance=..60] ~ ~ ~ 2 0.95
execute positioned -60.5 29.5 -54.5 run particle minecraft:end_rod ~ ~ ~ 0.3 0.3 0.3 0.1 25 force
execute if score #temoins station matches 3 run function atelier:station_vestiaire_ouvrir
kill @s
