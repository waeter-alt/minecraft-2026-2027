# [claude-build] Pose de la station, etape 12 sur 20.
fill 97 47 -238 119 59 -208 minecraft:air
fill 97 47 -207 119 59 -177 minecraft:air
fill 97 47 -176 119 59 -146 minecraft:air
fill 97 47 -145 119 59 -115 minecraft:air
fill 97 47 -114 119 59 -84 minecraft:air
fill 97 47 -83 119 59 -53 minecraft:air
fill 97 47 -52 119 59 -22 minecraft:air
fill 97 47 -21 119 59 1 minecraft:air
schedule function atelier:station_pose_2_12 2t
