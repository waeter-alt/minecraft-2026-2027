# [claude-build] Pose de la station, etape 12 sur 21.
fill 97 47 -238 119 49 -208 minecraft:air
fill 97 47 -207 119 49 -177 minecraft:air
fill 97 47 -176 119 49 -146 minecraft:air
fill 97 47 -145 119 49 -115 minecraft:air
fill 97 47 -114 119 49 -84 minecraft:air
fill 97 47 -83 119 49 -53 minecraft:air
fill 97 47 -52 119 49 -22 minecraft:air
fill 97 47 -21 119 49 1 minecraft:air
schedule function atelier:station_pose_2_12 2t
