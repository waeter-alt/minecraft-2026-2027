# [claude-build] Cinematique « sas » : une image par tick (la camera), et ses evenements (sons, effets).
execute if score #t cine matches 1 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.500 29.500 -56.500 163.740 10.204
execute if score #t cine matches 2 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.498 29.499 -56.507 163.740 10.204
execute if score #t cine matches 3 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.492 29.495 -56.529 163.740 10.204
execute if score #t cine matches 4 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.481 29.488 -56.564 163.740 10.204
execute if score #t cine matches 5 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.467 29.479 -56.611 163.740 10.204
execute if score #t cine matches 6 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.450 29.468 -56.672 163.740 10.204
execute if score #t cine matches 7 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.429 29.454 -56.744 163.740 10.204
execute if score #t cine matches 8 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.404 29.439 -56.828 163.740 10.204
execute if score #t cine matches 9 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.377 29.421 -56.922 163.740 10.204
execute if score #t cine matches 10 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.346 29.401 -57.026 163.740 10.204
execute if score #t cine matches 11 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.313 29.380 -57.140 163.740 10.204
execute if score #t cine matches 12 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.277 29.357 -57.263 163.740 10.204
execute if score #t cine matches 13 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.239 29.332 -57.395 163.740 10.204
execute if score #t cine matches 14 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.198 29.306 -57.535 163.740 10.204
execute if score #t cine matches 15 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.155 29.278 -57.682 163.740 10.204
execute if score #t cine matches 16 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.111 29.250 -57.835 163.740 10.204
execute if score #t cine matches 17 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.064 29.220 -57.995 163.740 10.204
execute if score #t cine matches 18 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 7.016 29.189 -58.161 163.740 10.204
execute if score #t cine matches 19 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.966 29.157 -58.332 163.740 10.204
execute if score #t cine matches 20 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.915 29.124 -58.507 163.740 10.204
execute if score #t cine matches 21 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.862 29.090 -58.686 163.740 10.204
execute if score #t cine matches 22 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.809 29.056 -58.869 163.740 10.204
execute if score #t cine matches 23 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.755 29.021 -59.055 163.740 10.204
execute if score #t cine matches 24 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.700 28.986 -59.242 163.740 10.204
execute if score #t cine matches 25 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.645 28.950 -59.432 163.740 10.204
execute if score #t cine matches 26 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.589 28.914 -59.623 163.740 10.204
execute if score #t cine matches 27 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.533 28.879 -59.814 163.740 10.204
execute if score #t cine matches 28 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.478 28.843 -60.006 163.740 10.204
execute if score #t cine matches 29 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.422 28.807 -60.197 163.740 10.204
execute if score #t cine matches 30 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.366 28.771 -60.386 163.740 10.204
execute if score #t cine matches 31 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.312 28.736 -60.575 163.740 10.204
execute if score #t cine matches 32 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.257 28.701 -60.761 163.740 10.204
execute if score #t cine matches 33 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.204 28.667 -60.944 163.740 10.204
execute if score #t cine matches 34 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.151 28.633 -61.124 163.740 10.204
execute if score #t cine matches 35 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.100 28.600 -61.300 163.740 10.204
execute if score #t cine matches 36 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 6.048 28.567 -61.477 163.740 10.204
execute if score #t cine matches 37 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.995 28.533 -61.660 163.740 10.204
execute if score #t cine matches 38 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.940 28.497 -61.848 163.740 10.204
execute if score #t cine matches 39 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.884 28.461 -62.042 163.740 10.204
execute if score #t cine matches 40 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.826 28.424 -62.240 163.740 10.204
execute if score #t cine matches 41 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.767 28.386 -62.442 163.740 10.204
execute if score #t cine matches 42 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.707 28.347 -62.649 163.740 10.204
execute if score #t cine matches 43 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.645 28.308 -62.859 163.740 10.204
execute if score #t cine matches 44 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.583 28.268 -63.072 163.740 10.204
execute if score #t cine matches 45 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.520 28.227 -63.288 163.740 10.204
execute if score #t cine matches 46 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.456 28.186 -63.507 163.740 10.204
execute if score #t cine matches 47 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.392 28.145 -63.727 163.740 10.204
execute if score #t cine matches 48 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.327 28.103 -63.950 163.740 10.204
execute if score #t cine matches 49 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.262 28.061 -64.173 163.740 10.204
execute if score #t cine matches 50 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.196 28.019 -64.398 163.740 10.204
execute if score #t cine matches 51 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.131 27.977 -64.623 163.740 10.204
execute if score #t cine matches 52 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 5.065 27.935 -64.848 163.740 10.204
execute if score #t cine matches 53 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.999 27.892 -65.073 163.740 10.204
execute if score #t cine matches 54 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.934 27.850 -65.298 163.740 10.204
execute if score #t cine matches 55 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.869 27.808 -65.521 163.740 10.204
execute if score #t cine matches 56 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.804 27.767 -65.744 163.740 10.204
execute if score #t cine matches 57 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.740 27.726 -65.964 163.740 10.204
execute if score #t cine matches 58 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.676 27.685 -66.182 163.740 10.204
execute if score #t cine matches 59 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.613 27.644 -66.398 163.740 10.204
execute if score #t cine matches 60 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.551 27.604 -66.611 163.740 10.204
execute if score #t cine matches 61 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.490 27.565 -66.821 163.740 10.204
execute if score #t cine matches 62 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.430 27.526 -67.027 163.740 10.204
execute if score #t cine matches 63 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.371 27.488 -67.229 163.740 10.204
execute if score #t cine matches 64 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.313 27.451 -67.427 163.740 10.204
execute if score #t cine matches 65 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.257 27.415 -67.620 163.740 10.204
execute if score #t cine matches 66 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.202 27.380 -67.808 163.740 10.204
execute if score #t cine matches 67 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.149 27.346 -67.990 163.740 10.204
execute if score #t cine matches 68 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.097 27.313 -68.166 163.740 10.204
execute if score #t cine matches 69 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.048 27.281 -68.337 163.740 10.204
execute if score #t cine matches 70 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 4.000 27.250 -68.500 163.740 10.204
execute if score #t cine matches 71 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.953 27.220 -68.661 163.740 10.204
execute if score #t cine matches 72 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.906 27.189 -68.824 163.740 10.204
execute if score #t cine matches 73 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.858 27.159 -68.988 163.740 10.204
execute if score #t cine matches 74 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.810 27.128 -69.153 163.740 10.204
execute if score #t cine matches 75 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.761 27.096 -69.319 163.740 10.204
execute if score #t cine matches 76 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.713 27.065 -69.485 163.740 10.204
execute if score #t cine matches 77 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.664 27.034 -69.652 163.740 10.204
execute if score #t cine matches 78 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.615 27.003 -69.818 163.740 10.204
execute if score #t cine matches 79 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.567 26.972 -69.985 163.740 10.204
execute if score #t cine matches 80 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.519 26.941 -70.150 163.740 10.204
execute if score #t cine matches 81 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.471 26.910 -70.314 163.740 10.204
execute if score #t cine matches 82 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.423 26.879 -70.478 163.740 10.204
execute if score #t cine matches 83 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.376 26.849 -70.639 163.740 10.204
execute if score #t cine matches 84 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.330 26.819 -70.799 163.740 10.204
execute if score #t cine matches 85 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.284 26.789 -70.956 163.740 10.204
execute if score #t cine matches 86 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.238 26.760 -71.111 163.740 10.204
execute if score #t cine matches 87 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.194 26.732 -71.263 163.740 10.204
execute if score #t cine matches 88 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.151 26.704 -71.412 163.740 10.204
execute if score #t cine matches 89 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.108 26.677 -71.558 163.740 10.204
execute if score #t cine matches 90 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.067 26.650 -71.700 163.740 10.204
execute if score #t cine matches 91 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 3.026 26.624 -71.838 163.740 10.204
execute if score #t cine matches 92 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.987 26.599 -71.972 163.740 10.204
execute if score #t cine matches 93 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.950 26.575 -72.101 163.740 10.204
execute if score #t cine matches 94 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.914 26.552 -72.225 163.740 10.204
execute if score #t cine matches 95 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.879 26.529 -72.344 163.740 10.204
execute if score #t cine matches 96 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.846 26.508 -72.457 163.740 10.204
execute if score #t cine matches 97 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.814 26.488 -72.565 163.740 10.204
execute if score #t cine matches 98 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.785 26.469 -72.666 163.740 10.204
execute if score #t cine matches 99 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.757 26.451 -72.762 163.740 10.204
execute if score #t cine matches 100 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.731 26.434 -72.850 163.740 10.204
execute if score #t cine matches 101 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.707 26.419 -72.931 163.740 10.204
execute if score #t cine matches 102 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.686 26.405 -73.006 163.740 10.204
execute if score #t cine matches 103 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.666 26.393 -73.072 163.740 10.204
execute if score #t cine matches 104 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.649 26.382 -73.131 163.740 10.204
execute if score #t cine matches 105 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.635 26.372 -73.181 163.740 10.204
execute if score #t cine matches 106 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.622 26.364 -73.223 163.740 10.204
execute if score #t cine matches 107 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.613 26.358 -73.256 163.740 10.204
execute if score #t cine matches 108 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.606 26.354 -73.280 163.740 10.204
execute if score #t cine matches 109 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.601 26.351 -73.295 163.740 10.204
execute if score #t cine matches 110 run tp @e[type=minecraft:armor_stand,tag=cine_cam] 2.600 26.350 -73.300 163.740 10.204
execute if score #t cine matches 2 run title @a[tag=cine] actionbar {"text":"…","color":"gray"}
execute if score #t cine matches 12 run execute as @a[tag=cine] at @s run playsound minecraft:block.copper_grate.step master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 12 run execute as @a[tag=cine] at @s run playsound minecraft:block.chain.place master @s ~ ~ ~ 1 0.5
execute if score #t cine matches 25 run function atelier:station_sas_ouvrir
execute if score #t cine matches 25 run function atelier:station_casier
execute if score #t cine matches 25 run execute as @a[tag=cine] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 1 1.2
execute if score #t cine matches 34 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 0.75
execute if score #t cine matches 38 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 0.94
execute if score #t cine matches 42 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.12
execute if score #t cine matches 47 run execute as @a[tag=cine] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
execute if score #t cine matches 62 run title @a[tag=cine] actionbar {"text":"Au Vestiaire, un casier s'est ouvert","color":"gold"}
