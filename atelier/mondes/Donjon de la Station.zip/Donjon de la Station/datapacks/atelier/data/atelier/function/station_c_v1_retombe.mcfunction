# [claude-build] Dix secondes sans que l'autre valve soit tournee : la premiere retombe.
scoreboard players set #c1a station 0
scoreboard players set #c1b station 0
setblock -15 -14 -204 donjon:valve_station[couleur=rouge,tournee=false,waterlogged=true]
setblock 15 -14 -204 donjon:valve_station[couleur=bleu,tournee=false,waterlogged=true]
execute positioned -15 -14 -204 run playsound minecraft:block.piston.contract master @a[distance=..60] ~ ~ ~ 2 0.6
execute positioned 15 -14 -204 run playsound minecraft:block.piston.contract master @a[distance=..60] ~ ~ ~ 2 0.6
